import { ethers } from "hardhat";
import { Contract, ContractFactory } from "ethers";
import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import { expect } from "chai";
import { setBalance } from "@nomicfoundation/hardhat-network-helpers";

describe("WinWin test", function () {
  let owner: SignerWithAddress,
    user1: SignerWithAddress,
    user2: SignerWithAddress;
  let WinWin: ContractFactory;
  let winToken: Contract;
  let winDecimals: number;

  it("1) Setting initial supply", async function () {
    [owner, user1, user2] = await ethers.getSigners();

    // Set Ether balances
    const initialBalance = ethers.utils.parseEther("100000"); // Set initial balance to 1000 ETH

    await setBalance(owner.address, initialBalance);
    await setBalance(user1.address, initialBalance);
    await setBalance(user2.address, initialBalance);

    WinWin = await ethers.getContractFactory("WinToken");
    let tokenSupply = 5000000000;
    winToken = await WinWin.deploy(tokenSupply);
    winDecimals = await winToken.decimals();

    //checking if total supply is equal to the initial amount supplied during deployment.
    expect(await winToken.totalSupply()).to.equal(
      BigInt(tokenSupply) * BigInt(10 ** winDecimals)
    );
  });

  it("2) Checking decimal value.", async function () {
    let decimalValue = 18;

    expect(await winToken.decimals()).to.equal(decimalValue);
  });

  it("3) Checking name of the token.", async function () {
    let name = "WIN";

    expect(await winToken.name()).to.equal(name);
  });

  it("4) Checking symbol of the token.", async function () {
    let symbol = "WIN";

    expect(await winToken.symbol()).to.equal(symbol);
  });

  it("5) Transfer fails as amount sent to the 'zero address'.", async function () {
    let amount = BigInt(5) * BigInt(10 ** winDecimals);

    await expect(
      winToken.transfer(ethers.constants.AddressZero, amount)
    ).to.be.revertedWith("ERC20: transfer to the zero address");
  });

  it("6) Transfer fails due to insufficient balance.", async function () {
    //trying to send more tokens than owner minted
    let amount = BigInt(50000000000) * BigInt(10 ** winDecimals);

    await expect(winToken.transfer(user1.address, amount)).to.be.revertedWith(
      "ERC20: transfer amount exceeds balance"
    );
  });

  it("7) Successful 'transfer'", async function () {
    let pastUser1Balance = await winToken.balanceOf(user1.address);
    let transferAmount = BigInt(2) * BigInt(10 ** winDecimals);
    await winToken.transfer(user1.address, transferAmount);

    expect(await winToken.balanceOf(user1.address)).to.equal(
      BigInt(pastUser1Balance) + BigInt(transferAmount)
    );
  });

  it("8) 'transferFrom' fails due to insufficient allowance.", async function () {
    let transferFromAmount = BigInt(1) * BigInt(10 ** winDecimals);

    await expect(
      winToken
        .connect(user2)
        .transferFrom(owner.address, user1.address, transferFromAmount)
    ).to.be.revertedWith("ERC20: insufficient allowance");
  });

  it("9) Successful 'approve'.", async function () {
    let pastAllowance = await winToken.allowance(owner.address, user2.address);
    let approveAmount = BigInt(3) * BigInt(10 ** winDecimals);
    await winToken.approve(user2.address, approveAmount);

    expect(await winToken.allowance(owner.address, user2.address)).to.equal(
      BigInt(pastAllowance) + BigInt(approveAmount)
    );
  });

  it("10) Fails as it is approving to the 'zero address'.", async function () {
    let approveAmount = BigInt(3) * BigInt(10 ** winDecimals);

    await expect(
      winToken.approve(ethers.constants.AddressZero, approveAmount)
    ).to.be.revertedWith("ERC20: approve to the zero address");
  });

  it("11) Successfully Increasing allowance.", async function () {
    let pastAllowance = await winToken.allowance(owner.address, user2.address);
    let increaseApprovalAmount = BigInt(1) * BigInt(10 ** winDecimals);

    await winToken.increaseAllowance(user2.address, increaseApprovalAmount);

    expect(await winToken.allowance(owner.address, user2.address)).to.equal(
      BigInt(pastAllowance) + BigInt(increaseApprovalAmount)
    );
  });

  it("12) Fails as tried to decreasing allowance more that actual allowance.", async function () {
    let decreaseApprovalAmount = BigInt(6) * BigInt(10 ** winDecimals);

    await expect(
      winToken.decreaseAllowance(user2.address, decreaseApprovalAmount)
    ).to.be.revertedWith("ERC20: decreased allowance below zero");
  });

  it("13) Successfully decreasing allowance.", async function () {
    let pastAllowance = await winToken.allowance(owner.address, user2.address);
    let decreaseApprovalAmount = BigInt(1) * BigInt(10 ** winDecimals);

    await winToken.decreaseAllowance(user2.address, decreaseApprovalAmount);

    expect(await winToken.allowance(owner.address, user2.address)).to.equal(
      BigInt(pastAllowance) - BigInt(decreaseApprovalAmount)
    );
  });

  it("14) Successfully implementing 'transferFrom'", async function () {
    let user1Balance = await winToken.balanceOf(user1.address);
    let transferFromAmount = BigInt(1) * BigInt(10 ** winDecimals);
    await winToken
      .connect(user2)
      .transferFrom(owner.address, user1.address, transferFromAmount);

    expect(await winToken.balanceOf(user1.address)).to.equal(
      BigInt(user1Balance) + BigInt(transferFromAmount)
    );
  });
});
