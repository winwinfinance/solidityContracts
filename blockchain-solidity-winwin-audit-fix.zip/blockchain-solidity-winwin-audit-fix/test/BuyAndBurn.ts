import hre, { ethers } from "hardhat";
import { expect } from "chai";
import { Contract, ContractFactory } from "ethers";
import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import axios from "axios";

async function createPairAndAddLiquidity(
  token0: Contract,
  token1: Contract,
  router: Contract,
  deployer: SignerWithAddress
) {
  // Approve tokens for spending by the router
  await token0.connect(deployer).approve(router.address, 1000000000000);
  await token1.connect(deployer).approve(router.address, 1000000000000);
  // Add liquidity to the pool
  const deadline = Math.floor(Date.now() / 1000) + 60 * 20; // 20 minutes

  const tx = await router.connect(deployer).addLiquidity(
    token1.address,
    token0.address,
    1000000000000,
    1000000000000,
    0,
    0,
    deployer.address, // Liquidity will be sent to the deployer's address
    deadline
  );
  await tx.wait();
}

describe("BuyAndBurn", async function () {
  let BuyAndBurn: ContractFactory;
  let buyAndBurn: Contract;
  let WINToken: Contract;
  let HEXToken: Contract;
  let deployer: SignerWithAddress;
  let user: SignerWithAddress;
  let WinWin: ContractFactory;
  let winToken: Contract;
  const HEXAddress = "0x2b591e99afE9f32eAA6214f7B7629768c40Eeb39";
  const routerAddress = "0x98bf93ebf5c380C0e6Ae8e192A7e2AE08edAcc02";
  const WPLSAddress = "0xA1077a294dDE1B09bB078844df40758a5D0f9a27";
  const DEADAddress = "0x000000000000000000000000000000000000dEaD";

  beforeEach(async function () {
    [deployer, user] = await ethers.getSigners();

    WinWin = await ethers.getContractFactory("WinToken");
    const tokenSupply = 5000000000;
    winToken = await WinWin.deploy(tokenSupply);

    const wplsTokenInstance = winToken.attach(WPLSAddress);
    // Deploy the contract
    BuyAndBurn = await ethers.getContractFactory("BuyAndBurn");
    buyAndBurn = await BuyAndBurn.connect(deployer).deploy(routerAddress);

    const path = [WPLSAddress, HEXAddress];

    const abi = await axios.get(
      `https://api.etherscan.io/api?module=contract&action=getabi&address=0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D&apikey=${process.env.ETHERSCAN_API_KEY}`
    );
    await hre.network.provider.send("hardhat_setBalance", [
      deployer.address,
      "0x100000000000000000000000000000000000000000000000",
    ]);

    const routerInstance = new ethers.Contract(
      routerAddress,
      abi.data.result,
      deployer
    );

    createPairAndAddLiquidity(
      winToken,
      wplsTokenInstance,
      routerInstance,
      deployer
    );

    const options = { value: ethers.utils.parseEther("20.0") };

    await routerInstance.swapExactETHForTokens(
      0,
      path,
      user.address,
      "10000000000000000",
      options
    );
    WINToken = await ethers.getContractAt("IERC20", winToken.address);
    HEXToken = await ethers.getContractAt("IERC20", HEXAddress);
  });

  it("should add token address and path", async function () {
    const tokenAddress = HEXAddress;
    const path = [tokenAddress, WPLSAddress, winToken.address];

    await buyAndBurn.connect(deployer).setTokenAndPath(tokenAddress, path);

    const storedPath = await buyAndBurn.getPath(tokenAddress);
    expect(storedPath).to.deep.equal(path);
  });
  it("should update slippage", async function () {
    await buyAndBurn.connect(deployer).updateSlippage(98);

    const slippage = await buyAndBurn.slippage();
    expect(slippage).to.deep.equal(98);
  });

  it("should not allow adding token address with zero address", async function () {
    const tokenAddress = ethers.constants.AddressZero;
    const path = [tokenAddress, WPLSAddress, winToken.address];

    await expect(
      buyAndBurn.connect(deployer).setTokenAndPath(tokenAddress, path)
    ).to.be.revertedWith("Invalid token address");
  });

  it("should update token address and path", async function () {
    const tokenAddress = HEXAddress;
    let path = [tokenAddress, WPLSAddress, winToken.address];

    await buyAndBurn.connect(deployer).setTokenAndPath(tokenAddress, path);

    let storedPath = await buyAndBurn.getPath(tokenAddress);
    expect(storedPath).to.deep.equal(path);

    path = [tokenAddress, winToken.address, WPLSAddress];

    await buyAndBurn.connect(deployer).setTokenAndPath(tokenAddress, path);

    storedPath = await buyAndBurn.getPath(tokenAddress);
    expect(storedPath).to.deep.equal(path);
  });

  it("should not allow swapping and burning tokens when contract holds no tokens", async function () {
    const tokenAddress = HEXAddress;
    const path = [tokenAddress, WPLSAddress, winToken.address];

    await buyAndBurn.connect(deployer).setTokenAndPath(tokenAddress, path);

    await expect(
      buyAndBurn.connect(user).swap([tokenAddress])
    ).to.be.revertedWith("No tokens to swap and burn");
  });

  it("should not allow swapping and burning tokens without defining swap path", async function () {
    const tokenAddress = HEXAddress;
    const amountIn = await HEXToken.balanceOf(user.address);

    // Transfer tokens to the contract
    await HEXToken.connect(user).transfer(buyAndBurn.address, amountIn);

    // Attempt to call the burn function without defining the swap path
    await expect(
      buyAndBurn.connect(user).swap([tokenAddress])
    ).to.be.revertedWith("Path not found for token");

    // Check if the token balance remains in the contract
    const tokenBalance = await HEXToken.balanceOf(buyAndBurn.address);
    expect(tokenBalance).to.equal(amountIn);
  });

  it("should be able to swap and burn the tokens", async function () {
    const tokenAddress = HEXAddress;
    const path = [tokenAddress, WPLSAddress, winToken.address];

    // Add tokenAddress and Path
    await buyAndBurn.connect(deployer).setTokenAndPath(tokenAddress, path);

    // Transfer some tokens to the contract
    const amountIn = await HEXToken.balanceOf(user.address);
    await HEXToken.connect(user).transfer(buyAndBurn.address, amountIn);

    const deadAddressBalanceBeforeBurn = await WINToken.balanceOf(DEADAddress);

    // Call the burn function
    await buyAndBurn.connect(user).swap([HEXAddress]);

    const deadAddressBalanceAfterBurn = await WINToken.balanceOf(DEADAddress);

    // Check if the HEX balance has been burned
    const hexBalance = await HEXToken.balanceOf(buyAndBurn.address);
    expect(hexBalance).to.equal(0);
    expect(Number(deadAddressBalanceAfterBurn)).to.be.greaterThan(
      Number(deadAddressBalanceBeforeBurn)
    );
  });
  it("should be able to swap and burn the PLS", async function () {
    const tokenAddress = WPLSAddress;
    const path = [WPLSAddress, winToken.address];

    // Add tokenAddress and Path
    await buyAndBurn.connect(deployer).setTokenAndPath(tokenAddress, path);

    // Transfer some tokens to the contract
    const amountIn = ethers.utils.parseEther("1.0");

    await deployer.sendTransaction({
      to: buyAndBurn.address,
      value: amountIn,
    });

    const deadAddressBalanceBeforeBurn = await WINToken.balanceOf(DEADAddress);

    // Call the burn function
    await buyAndBurn.connect(user).swapPLS();

    const deadAddressBalanceAfterBurn = await WINToken.balanceOf(DEADAddress);

    expect(Number(deadAddressBalanceAfterBurn)).to.be.greaterThan(
      Number(deadAddressBalanceBeforeBurn)
    );
  });
  it("should revert if non-owner tries to set token address and path", async () => {
    const tokenAddress = HEXAddress;
    const path = [tokenAddress, WPLSAddress, winToken.address];

    await expect(
      buyAndBurn.connect(user).setTokenAndPath(tokenAddress, path)
    ).to.be.revertedWith("Ownable: caller is not the owner");
  });

  it("should revert if non-owner tries to update slippage", async () => {
    await expect(
      buyAndBurn.connect(user).updateSlippage(90)
    ).to.be.revertedWith("Ownable: caller is not the owner");
  });

  it("should get swap path for token", async () => {
    const tokenAddress = HEXAddress;
    const path = [tokenAddress, WPLSAddress, winToken.address];

    await buyAndBurn.connect(deployer).setTokenAndPath(tokenAddress, path);

    const storedPath = await buyAndBurn.getPath(tokenAddress);
    expect(storedPath).to.deep.equal(path);
  });

  it("should revert if getting path for zero address", async () => {
    await expect(
      buyAndBurn.getPath(ethers.constants.AddressZero)
    ).to.be.revertedWith("Invalid token address");
  });

  it("should revert if getting path for unregistered token", async () => {
    const tokenAddress = HEXAddress;

    await expect(buyAndBurn.getPath(tokenAddress)).to.be.revertedWith(
      "Path not found for token"
    );
  });

  it("should be able to receive ETH", async () => {
    const value = ethers.utils.parseEther("1.0");
    await deployer.sendTransaction({
      to: buyAndBurn.address,
      value,
    });

    expect(await ethers.provider.getBalance(buyAndBurn.address)).to.equal(
      value
    );
  });

  it("should revert swapping ETH if no path set", async () => {
    const value = ethers.utils.parseEther("1.0");
    await deployer.sendTransaction({
      to: buyAndBurn.address,
      value,
    });

    await expect(buyAndBurn.connect(user).swapPLS()).to.be.revertedWith(
      "Path not found for token"
    );
  });

  it("should swap and burn ETH", async () => {
    const path = [WPLSAddress, winToken.address];
    await buyAndBurn.connect(deployer).setTokenAndPath(WPLSAddress, path);

    const value = ethers.utils.parseEther("1.0");
    await deployer.sendTransaction({
      to: buyAndBurn.address,
      value,
    });

    const deadAddrBalanceBefore = await WINToken.balanceOf(DEADAddress);

    await buyAndBurn.connect(user).swapPLS();

    const deadAddrBalanceAfter = await WINToken.balanceOf(DEADAddress);

    expect(deadAddrBalanceAfter).to.be.gt(deadAddrBalanceBefore);
    expect(await ethers.provider.getBalance(buyAndBurn.address)).to.equal(0);
  });
});
