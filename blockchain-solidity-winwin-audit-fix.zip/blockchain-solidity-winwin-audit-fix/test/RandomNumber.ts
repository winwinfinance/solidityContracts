import { expect } from "chai";
import { ethers } from "hardhat";
import { BigNumber, Contract } from "ethers";
import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import { setBalance } from "@nomicfoundation/hardhat-network-helpers";

describe("RandomNumber Contract Tests", function () {
  let randomNumberContract: Contract;
  let owner: SignerWithAddress;
  let authorizedAddr: SignerWithAddress;
  let unauthorizedAddr: SignerWithAddress;

  const hashes = [
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [1])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [2])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [3])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [4])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [5])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [6])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [7])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [8])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [9])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [10])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [11])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [12])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [13])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [14])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [15])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [16])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [17])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [18])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [19])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [20])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [21])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [22])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [23])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [24])),
    ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [25])),
  ];

  beforeEach(async function () {
    [owner, authorizedAddr, unauthorizedAddr] = await ethers.getSigners();
    // Set Ether balances
    const initialBalance = ethers.utils.parseEther("1000000000000");

    await setBalance(owner.address, initialBalance);
    await setBalance(authorizedAddr.address, initialBalance);
    await setBalance(unauthorizedAddr.address, initialBalance);

    const RandomNumber = await ethers.getContractFactory("RandomNumber");
    randomNumberContract = await RandomNumber.deploy([authorizedAddr.address]);
    await randomNumberContract.deployed();
  });

  describe("Constructor", function () {
    it("Should set the correct authorized addresses", async function () {
      expect(await randomNumberContract.isAuthorized(authorizedAddr.address)).to
        .be.true;
    });

    it("Should reject zero address being authorized", async function () {
      const RandomNumber = await ethers.getContractFactory("RandomNumber");
      await expect(
        RandomNumber.deploy([ethers.constants.AddressZero])
      ).to.be.revertedWith("Can't be zero address");
    });
  });

  describe("UpdateAuthorization", function () {
    it("Should update authorization status", async function () {
      await randomNumberContract.UpdateAuthorization(
        unauthorizedAddr.address,
        true
      );
      expect(await randomNumberContract.isAuthorized(unauthorizedAddr.address))
        .to.be.true;
    });

    it("Should reject non-owner calls", async function () {
      await expect(
        randomNumberContract
          .connect(unauthorizedAddr)
          .UpdateAuthorization(unauthorizedAddr.address, true)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Should reject zero address", async function () {
      await expect(
        randomNumberContract.UpdateAuthorization(
          ethers.constants.AddressZero,
          true
        )
      ).to.be.revertedWith("Can't be zero address");
    });
  });

  describe("commitHash", function () {
    it("Should commit hashes correctly", async function () {
      const requestId = 1;
      await randomNumberContract
        .connect(authorizedAddr)
        .commitHash(requestId, hashes);
      const committedHash = await randomNumberContract.getCommittedHash(
        requestId
      );
      expect(committedHash.hashes).to.deep.equal(hashes);
      expect(committedHash.revealed).to.be.false;
    });

    it("Should reject unauthorized calls", async function () {
      const requestId = 1;
      await expect(
        randomNumberContract
          .connect(unauthorizedAddr)
          .commitHash(requestId, hashes)
      ).to.be.revertedWith("not authorized");
    });

    it("Should reject incorrect hash length", async function () {
      const invalidHashes = hashes.slice(0, 24); // Only 24 hashes
      const requestId = 1;
      await expect(
        randomNumberContract
          .connect(authorizedAddr)
          .commitHash(requestId, invalidHashes)
      ).to.be.revertedWith("Hashes should be 25");
    });

    it("Should reject double commitment", async function () {
      const requestId = 1;
      await randomNumberContract
        .connect(authorizedAddr)
        .commitHash(requestId, hashes);
      await expect(
        randomNumberContract
          .connect(authorizedAddr)
          .commitHash(requestId, hashes)
      ).to.be.revertedWith("Hashes already set");
    });
  });

  describe("requestRandomWords", function () {
    it("Should successfully request random words", async function () {
      expect(await randomNumberContract.lastRequestId()).to.equal("0");
      const requestId = 1;
      await randomNumberContract
        .connect(authorizedAddr)
        .commitHash(requestId, hashes);
      const tx = await randomNumberContract
        .connect(authorizedAddr)
        .requestRandomWords();
      await tx.wait(); // Wait for the transaction to be mined
      expect(await randomNumberContract.lastRequestId()).to.equal(requestId);
    });

    it("Should reject unauthorized calls", async function () {
      const requestId = 1;
      await randomNumberContract
        .connect(authorizedAddr)
        .commitHash(requestId, hashes);
      await expect(
        randomNumberContract.connect(unauthorizedAddr).requestRandomWords()
      ).to.be.revertedWith("not authorized");
    });

    it("Should reject request without committed hashes", async function () {
      await expect(
        randomNumberContract.connect(authorizedAddr).requestRandomWords()
      ).to.be.revertedWith("hashes not yet set");
    });

    it("Should increment the lastRequestId correctly", async function () {
      const requestId = 1;
      await randomNumberContract
        .connect(authorizedAddr)
        .commitHash(requestId, hashes);
      await randomNumberContract.connect(authorizedAddr).requestRandomWords();
      expect(await randomNumberContract.lastRequestId()).to.equal(requestId);

      const requestId2 = 2;
      await randomNumberContract
        .connect(authorizedAddr)
        .commitHash(requestId2, hashes);
      await randomNumberContract.connect(authorizedAddr).requestRandomWords();
      expect(await randomNumberContract.lastRequestId()).to.equal(requestId2);
    });
  });

  describe("revealHash", function () {
    it("Should reveal hashes correctly", async function () {
      const numbers = Array.from({ length: 25 }, (_, i) =>
        ethers.BigNumber.from(i + 1)
      );
      const requestId = 1;
      await randomNumberContract
        .connect(authorizedAddr)
        .commitHash(requestId, hashes);

      await randomNumberContract.connect(authorizedAddr).requestRandomWords();

      await randomNumberContract.revealHash(requestId, numbers);
      const committedHash = await randomNumberContract.getCommittedHash(
        requestId
      );

      expect(committedHash.numbers).to.deep.equal(numbers);
      expect(committedHash.revealed).to.be.true;
    });

    it("Should reject incorrect number length", async function () {
      const numbers = [
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
        21, 22, 23, 24, 25,
      ];
      const invalidNumbers = numbers.slice(0, 24); // Only 24 numbers
      const requestId = 1;
      await randomNumberContract
        .connect(authorizedAddr)
        .commitHash(requestId, hashes);

      await randomNumberContract.connect(authorizedAddr).requestRandomWords();
      await expect(
        randomNumberContract.revealHash(requestId, invalidNumbers)
      ).to.be.revertedWith("invalid length");
    });

    it("Should reject invalid numbers", async function () {
      const invalidNumbers = [...Array(25).keys()]; // Numbers from 0 to 24

      const requestId = 1;
      await randomNumberContract
        .connect(authorizedAddr)
        .commitHash(requestId, hashes);

      await randomNumberContract.connect(authorizedAddr).requestRandomWords();
      await expect(
        randomNumberContract.revealHash(requestId, invalidNumbers)
      ).to.be.revertedWith("invalid numbers");
    });

    it("Should reject double reveal", async function () {
      const numbers = [
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
        21, 22, 23, 24, 25,
      ];
      const requestId = 1;
      await randomNumberContract
        .connect(authorizedAddr)
        .commitHash(requestId, hashes);
      await randomNumberContract.connect(authorizedAddr).requestRandomWords();
      await randomNumberContract.revealHash(requestId, numbers);
      await expect(
        randomNumberContract.revealHash(requestId, numbers)
      ).to.be.revertedWith("hashes already revealed");
    });
  });

  describe("getRequestStatus", function () {
    it("Should return correct status and numbers for a valid request ID", async function () {
      const numbers = Array.from({ length: 25 }, (_, i) =>
        ethers.BigNumber.from(i + 1)
      );

      const requestId = 1;
      await randomNumberContract
        .connect(authorizedAddr)
        .commitHash(requestId, hashes);
      await randomNumberContract.connect(authorizedAddr).requestRandomWords();
      await randomNumberContract.revealHash(requestId, numbers);

      const [fulfilled, revealedNumbers] =
        await randomNumberContract.getRequestStatus(requestId);

      expect(fulfilled).to.be.true;
      expect(revealedNumbers).to.deep.equal(numbers);
    });

    it("Should revert for request ids which is greter than last request id", async function () {
      let requestId = await randomNumberContract.lastRequestId();

      await expect(
        randomNumberContract.getRequestStatus(requestId.add(1))
      ).to.be.revertedWith("no requests");
    });

    it("Should return false and empty array for a request with committed hashes but not revealed", async function () {
      let requestId = await randomNumberContract.lastRequestId();
      let newRequestId = requestId.add(1);
      await randomNumberContract
        .connect(authorizedAddr)
        .commitHash(newRequestId, hashes);

      await randomNumberContract.connect(authorizedAddr).requestRandomWords();

      const [fulfilled, revealedNumbers] =
        await randomNumberContract.getRequestStatus(newRequestId);

      expect(fulfilled).to.be.false;
      expect(revealedNumbers).to.deep.equal([]);
    });

    it("Should revert if the requestId is greater than the lastRequestId", async function () {
      const invalidRequestId = 2;

      await expect(
        randomNumberContract.getRequestStatus(invalidRequestId)
      ).to.be.revertedWith("no requests");
    });
  });

  describe("lastRequestId", function () {
    it("Should return the correct last request ID", async function () {
      await randomNumberContract.connect(authorizedAddr).commitHash(1, hashes);
      await randomNumberContract.connect(authorizedAddr).requestRandomWords();
      expect(await randomNumberContract.lastRequestId()).to.equal(1);
    });
  });
});
