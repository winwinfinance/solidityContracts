import hre, { ethers, waffle } from "hardhat";
import { BigNumber, Contract, ContractFactory } from "ethers";
import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import { expect } from "chai";
import { BigNumber as BN } from "bignumber.js";

BN.config({ ROUNDING_MODE: BN.ROUND_DOWN });

async function forward(seconds: any) {
  const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;
  await waffle.provider.send("evm_setNextBlockTimestamp", [
    lastTimestamp + seconds,
  ]);
  await waffle.provider.send("evm_mine", []);
}

describe("Win Staking Pool Tests", () => {
  let deployer: SignerWithAddress;
  let user1: SignerWithAddress;
  let user2: SignerWithAddress;
  let rewardDistributor: SignerWithAddress;
  let WinWin: ContractFactory;
  let winToken: Contract;
  let PrizePool: ContractFactory;
  let winPrizePool: Contract;
  let rewardToken: Contract;
  let WinStakingPool: ContractFactory;
  let winStakingPool: Contract;
  let totalRewards: BigNumber = BigNumber.from("1000000000000000000000");

  const WPLSAddress = "0xA1077a294dDE1B09bB078844df40758a5D0f9a27";

  describe("Admin function test", () => {
    beforeEach(async () => {
      const block = await hre.ethers.provider.getBlock("latest");
      [deployer, rewardDistributor, user1, user2] = await ethers.getSigners();
      WinWin = await ethers.getContractFactory("WinToken");
      const tokenSupply = 50000000000000;
      winToken = await WinWin.deploy(tokenSupply);

      rewardToken = await WinWin.deploy(tokenSupply);

      WinStakingPool = await ethers.getContractFactory("WinStakingPool");
      winStakingPool = await WinStakingPool.deploy(
        winToken.address,
        block.timestamp,
        totalRewards
      );
    });

    it("First reward token is same as staking token", async () => {
      const rewardTokens = await winStakingPool.getRewardTokens();

      expect(rewardTokens[0]).to.equal(winToken.address);
    });

    it("admin can add more reward tokens", async () => {
      let rewardTokenCount = await winStakingPool.getRewardTokensCount();

      let rewardTokens = await winStakingPool.getRewardTokens();

      expect(rewardTokenCount).to.equal(1);

      expect(rewardTokens[0]).to.equal(winToken.address);

      await winStakingPool.addReward(rewardToken.address, deployer.address);

      const rewardData = await winStakingPool.getRewardData(
        rewardToken.address
      );

      rewardTokenCount = await winStakingPool.getRewardTokensCount();

      rewardTokens = await winStakingPool.getRewardTokens();

      expect(rewardTokenCount).to.equal(2);

      expect(rewardTokens[0]).to.equal(winToken.address);
      expect(rewardTokens[1]).to.equal(rewardToken.address);

      expect(rewardData.lastUpdateTime).to.not.equal(0);
    });

    it("Only admin can add more reward tokens", async () => {
      expect(await winStakingPool.owner()).to.equal(deployer.address);
      await expect(
        winStakingPool
          .connect(rewardDistributor)
          .addReward(rewardToken.address, deployer.address)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Reward token can not be added twice", async () => {
      await winStakingPool.addReward(rewardToken.address, deployer.address);
      const rewardData = await winStakingPool.getRewardData(
        rewardToken.address
      );

      expect(rewardData.lastUpdateTime).to.not.equal(0);

      await expect(
        winStakingPool.addReward(rewardToken.address, deployer.address)
      ).to.be.revertedWith("Reward Token already added");
    });

    it("Owner can approve reward distributor", async () => {
      await winStakingPool.addReward(rewardToken.address, deployer.address);
      let approved: boolean = await winStakingPool.rewardDistributors(
        rewardToken.address,
        rewardDistributor.address
      );
      expect(approved).to.equal(false);

      await winStakingPool.approveRewardDistributor(
        rewardToken.address,
        rewardDistributor.address,
        true
      );

      approved = await winStakingPool.rewardDistributors(
        rewardToken.address,
        rewardDistributor.address
      );
      expect(approved).to.equal(true);
    });

    it("Only owner can approve reward distributor", async () => {
      await expect(
        winStakingPool
          .connect(rewardDistributor)
          .approveRewardDistributor(
            winToken.address,
            rewardDistributor.address,
            true
          )
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Reward distributor can be added only for added reward tokens", async () => {
      await expect(
        winStakingPool
          .connect(deployer)
          .approveRewardDistributor(
            rewardToken.address,
            rewardDistributor.address,
            true
          )
      ).to.be.revertedWith("Reward Token not added");
    });
  });
  describe("Reward functions", () => {
    beforeEach(async () => {
      const block = await hre.ethers.provider.getBlock("latest");
      [deployer, rewardDistributor, user1, user2] = await ethers.getSigners();
      WinWin = await ethers.getContractFactory("WinToken");
      const tokenSupply = 50000000000000;
      const transferAmount = 1000000000;
      winToken = await WinWin.deploy(tokenSupply);

      rewardToken = await WinWin.deploy(tokenSupply);

      WinStakingPool = await ethers.getContractFactory("WinStakingPool");
      winStakingPool = await WinStakingPool.deploy(
        winToken.address,
        block.timestamp,
        totalRewards
      );

      await winToken
        .connect(deployer)
        .approve(winStakingPool.address, tokenSupply);

      await rewardToken
        .connect(rewardDistributor)
        .approve(winStakingPool.address, tokenSupply);

      await winToken
        .connect(deployer)
        .transfer(winStakingPool.address, totalRewards);
      await rewardToken
        .connect(deployer)
        .transfer(rewardDistributor.address, transferAmount);

      await winStakingPool.addReward(rewardToken.address, deployer.address);

      await winStakingPool.approveRewardDistributor(
        rewardToken.address,
        rewardDistributor.address,
        true
      );
    });

    it("Approved address can add rewards", async () => {
      const rewardAmount = 1000000;
      let rewardData = await winStakingPool.getRewardData(winToken.address);
      expect(rewardData.rewardRate).to.equal(0);
      expect(
        await winStakingPool.getRewardForDuration(winToken.address)
      ).to.equal(0);

      await winStakingPool
        .connect(rewardDistributor)
        .notifyRewardAmount(rewardToken.address, rewardAmount);

      rewardData = await winStakingPool.getRewardData(rewardToken.address);

      expect(rewardData.rewardRate).to.not.equal(0);
      expect(
        await winStakingPool.getRewardForDuration(rewardToken.address)
      ).to.not.equal(0);
    });

    it("Only approved address can add rewards", async () => {
      const rewardAmount = 1000000;

      expect(
        await winStakingPool.rewardDistributors(
          rewardToken.address,
          deployer.address
        )
      ).to.equal(true);

      expect(
        await winStakingPool.rewardDistributors(
          rewardToken.address,
          user1.address
        )
      ).to.equal(false);

      await expect(
        winStakingPool
          .connect(user1)
          .notifyRewardAmount(rewardToken.address, rewardAmount)
      ).to.be.revertedWith("User not Approved");
    });

    it("Notify reward amount will set reward rate", async () => {
      const rewardAmount = 1000000;
      const rewardDuration = await winStakingPool.REWARDS_DURATION();
      await winStakingPool
        .connect(rewardDistributor)
        .notifyRewardAmount(rewardToken.address, rewardAmount);

      const rewardData = await winStakingPool.getRewardData(
        rewardToken.address
      );

      const totalRewards = rewardDuration * rewardData.rewardRate;

      const rewardRate = rewardAmount / rewardDuration;

      expect(rewardRate).to.equal(rewardData.rewardRate);

      expect(totalRewards).to.equal(
        await winStakingPool.getRewardForDuration(rewardToken.address)
      );
    });

    it("If rewards are added before end of current duration leftover rewards will be added", async () => {
      const rewardAmount = 1000000;
      const rewardDuration = await winStakingPool.REWARDS_DURATION();
      await winStakingPool
        .connect(rewardDistributor)
        .notifyRewardAmount(rewardToken.address, rewardAmount);

      let rewardData = await winStakingPool.getRewardData(rewardToken.address);

      await forward(30);

      // taking 31 instaed of 30 as notify rewardAmount will take 1 second
      const leftover = (rewardDuration - 31) * rewardData.rewardRate;

      const newTotalRewards = leftover + rewardAmount;

      const newRewardRate = newTotalRewards / rewardDuration;

      await winStakingPool
        .connect(rewardDistributor)
        .notifyRewardAmount(rewardToken.address, rewardAmount);

      rewardData = await winStakingPool.getRewardData(rewardToken.address);

      expect(newRewardRate).to.equal(rewardData.rewardRate);
      expect(newTotalRewards).to.equal(
        await winStakingPool.getRewardForDuration(rewardToken.address)
      );
    });

    it("Zero rewards can not be added", async () => {
      await expect(
        winStakingPool
          .connect(rewardDistributor)
          .notifyRewardAmount(rewardToken.address, 0)
      ).to.be.revertedWith("No reward");
    });
  });
  describe("User Staking functions", () => {
    beforeEach(async () => {
      const block = await hre.ethers.provider.getBlock("latest");
      [deployer, rewardDistributor, user1, user2] = await ethers.getSigners();
      WinWin = await ethers.getContractFactory("WinToken");
      const tokenSupply = 50000000000000;
      const transferAmount: BigNumber = BigNumber.from("100000000000000000000");
      const rewardAmount: BigNumber = BigNumber.from("10000000000000000000");
      const approvalAmount: BigNumber = BigNumber.from("100000000000000000000");

      winToken = await WinWin.deploy(tokenSupply);

      rewardToken = await WinWin.deploy(tokenSupply);

      WinStakingPool = await ethers.getContractFactory("WinStakingPool");

      winStakingPool = await WinStakingPool.deploy(
        winToken.address,
        block.timestamp,
        totalRewards
      );

      const lastTimestamp = (await waffle.provider.getBlock("latest"))
        .timestamp;

      PrizePool = await ethers.getContractFactory("PrizePool", deployer);

      const prizeDistribution = [6000, 900, 600, 300, 100, 2100];

      winPrizePool = await PrizePool.deploy(
        lastTimestamp + 100,
        winStakingPool.address,
        prizeDistribution
      );

      await winStakingPool.setPrizePoolAddress(winPrizePool.address);

      await winPrizePool.addRewardToken(WPLSAddress);

      await winToken
        .connect(deployer)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(rewardDistributor)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(user1)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(user2)
        .approve(winStakingPool.address, approvalAmount);

      await rewardToken
        .connect(rewardDistributor)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(deployer)
        .transfer(winStakingPool.address, totalRewards);

      await winToken.connect(deployer).transfer(user1.address, transferAmount);
      await winToken.connect(deployer).transfer(user2.address, transferAmount);

      await rewardToken
        .connect(deployer)
        .transfer(rewardDistributor.address, transferAmount);

      await winStakingPool.addReward(rewardToken.address, deployer.address);

      await winStakingPool.approveRewardDistributor(
        rewardToken.address,
        rewardDistributor.address,
        true
      );

      await winStakingPool
        .connect(rewardDistributor)
        .notifyRewardAmount(rewardToken.address, rewardAmount);
    });

    it("User can stake thier win tokens", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      let stakesCount = await winStakingPool.getStakeCount(user1.address);
      const totalWinTokens = await winStakingPool.getTotalWinTokens(
        user1.address
      );
      expect(stakesCount).to.equal(0);

      expect(totalWinTokens).to.equal(0);

      const previousLockedTokens: BigNumber = BigNumber.from(
        await winStakingPool.totalLockedTokens()
      );

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const currentLockedTokens: BigNumber = BigNumber.from(
        await winStakingPool.totalLockedTokens()
      );
      // As this is first stake so shares=stakeAmount
      stakesCount = await winStakingPool.getStakeCount(user1.address);
      expect(stakesCount).to.equal(1);

      const balance = await winStakingPool.getBalance(
        user1.address,
        0,
        winToken.address
      );

      expect(balance._stakedAmount).to.equal(stakeAmount);

      expect(currentLockedTokens.sub(previousLockedTokens)).to.equal(
        stakeAmount
      );
    });

    it("User can not stake 0 tokens", async () => {
      await expect(
        winStakingPool.connect(user1).stake(0, [], [], true)
      ).to.be.revertedWith("Cannot stake 0");
    });

    it("After staking user will start earning rewards", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const winRewardData = await winStakingPool.getWinRewardData();
      const rewardTokenData = await winStakingPool.getRewardData(
        rewardToken.address
      );

      // forwarding 5 seconds
      await forward(5);

      let accumlatedWinToken: BigNumber = winRewardData.rewardRate.mul(5);
      const accumlatedRewardToken: BigNumber =
        rewardTokenData.rewardRate.mul(5);
      accumlatedWinToken = accumlatedWinToken.mul(99).div(100);

      const totalWin = await winStakingPool.getTotalWinTokens(user1.address);

      // Rewards in other tokens
      const rewardData = await winStakingPool.getTotalUserRewards(
        user1.address
      );

      expect(totalWin).to.equal(stakeAmount.add(accumlatedWinToken));

      expect(accumlatedRewardToken).to.equal(rewardData[1]);
    });

    it("Function rewardPerShare() should provide accumlated reward per share", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      const rewardTokenData = await winStakingPool.getRewardData(
        rewardToken.address
      );

      await forward(5);

      const accumlatedRewardToken = BN(
        rewardTokenData.rewardRate.mul(5).toString()
      );

      const rewardPerShare = await winStakingPool.rewardPerShare(
        rewardToken.address
      );

      const sharesTotal = BN((await winStakingPool.sharesTotal()).toString());

      expect(
        accumlatedRewardToken.multipliedBy(1e22).div(sharesTotal).toString()
      ).to.equal(rewardPerShare.toString());
    });

    it("On user's action , accumlated win tokens for current staked user will be autocompounded", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const winRewardData = await winStakingPool.getWinRewardData();

      // forwarding 5 seconds
      await forward(5);

      // totalLockedToken will increase and hence the price of the share will increase
      // That means other users who are staking same amount now will recieve less shares
      // hence less rewards

      // TotalLockedToken => stakeAmount + rewards in 6 seconds

      // TotalLockedToken => 10,000,000,000,000,000,000+300,000,000,000,000,000
      // Shares Total => 10,000,000,000,000,000,000
      // 1 share => totalLockedToken/sharesTotal => 1.03 win token

      // Now if user 2 stakes 10 win token
      // user2's shares => 10/1.03 =>9,708,737,864,077,669,902

      let totalLockedToken = BN(
        (await winStakingPool.totalLockedTokens()).toString()
      );

      let totalAccumlatedRewardsIn6Seconds = BN(
        winRewardData.rewardRate.mul(6).toString()
      );

      totalAccumlatedRewardsIn6Seconds = totalAccumlatedRewardsIn6Seconds
        .multipliedBy(99)
        .div(100);

      totalLockedToken = totalLockedToken.plus(
        totalAccumlatedRewardsIn6Seconds
      );

      const totalShares = BN((await winStakingPool.sharesTotal()).toString());

      const sharePrice = totalLockedToken.div(totalShares);

      await winStakingPool.connect(user2).stake(stakeAmount, [], [], true);

      const calculatedUser2Shares = BN(stakeAmount.toString()).div(sharePrice);

      expect(
        (await winStakingPool.userShares(user2.address)).toString()
      ).to.equal(calculatedUser2Shares.decimalPlaces(0, 1).toString());
    });

    it("Users can claim thier reward tokens (other than win token)", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const lockDuration: number = Number(await winStakingPool.LOCK_DURATION());
      // forwarding locl duration seconds
      await forward(lockDuration);

      const previousUser1Balance = await rewardToken.balanceOf(user1.address);

      const rewardData = await winStakingPool.getTotalUserRewards(
        user1.address
      );
      const rewardInfo = await winStakingPool.getRewardData(
        rewardToken.address
      );

      await winStakingPool.connect(user1).claim(user1.address);

      // Adding rewards for 1 more second as claim will take 1 second after we check getClaimable rewards
      const totalRewards = rewardData[1].add(rewardInfo.rewardRate);

      const currentUser1Balance = await rewardToken.balanceOf(user1.address);

      expect(currentUser1Balance.sub(previousUser1Balance)).to.equal(
        totalRewards
      );
    });
    it("User can call the claim reward tokens on the behalf of other user (other than win token)", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const callerBalanceBefore = await rewardToken.balanceOf(user2.address);

      const lockDuration: number = Number(await winStakingPool.LOCK_DURATION());
      // forwarding locl duration seconds
      await forward(lockDuration);

      const previousUser1Balance = await rewardToken.balanceOf(user1.address);

      const rewardData = await winStakingPool.getTotalUserRewards(
        user1.address
      );
      const rewardInfo = await winStakingPool.getRewardData(
        rewardToken.address
      );

      await winStakingPool.connect(user2).claim(user1.address);

      // Adding rewards for 1 more second as claim will take 1 second after we check getClaimable rewards
      const totalRewards = rewardData[1].add(rewardInfo.rewardRate);

      const currentUser1Balance = await rewardToken.balanceOf(user1.address);

      const callerBalanceAfter = await rewardToken.balanceOf(user2.address);

      expect(currentUser1Balance.sub(previousUser1Balance)).to.equal(
        totalRewards
      );
      expect(callerBalanceAfter).to.equal(callerBalanceBefore);
    });

    it("User can Unstake their staked tokens", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      const previousWinBalance = await winToken.balanceOf(user1.address);
      const previousUser1RewardBalance = await rewardToken.balanceOf(
        user1.address
      );
      const shares = await winStakingPool.userShares(user1.address);
      const winRewardData = await winStakingPool.getWinRewardData();
      const rewardInfo = await winStakingPool.getRewardData(
        rewardToken.address
      );

      const lockDuration: number = Number(await winStakingPool.LOCK_DURATION());
      // forwarding locl duration seconds
      await forward(lockDuration);

      await winStakingPool.connect(user1).unstake(shares);

      // As unstake will take 1 second ,
      // so  win reward acculmated will be added and withdrawn if we are removing our full share from pool

      const currentWinBalance = await winToken.balanceOf(user1.address);

      // await winStakingPool.connect(user1).claim();
      const currentUser1RewardBalance = await rewardToken.balanceOf(
        user1.address
      );

      expect(currentWinBalance.sub(previousWinBalance)).to.equal(
        stakeAmount.add(
          winRewardData.rewardRate
            .mul(lockDuration + 1)
            .mul(99)
            .div(100)
        )
      );

      expect(
        currentUser1RewardBalance.sub(previousUser1RewardBalance)
      ).to.equal(rewardInfo.rewardRate.mul(lockDuration + 1));
    });
    it("Check if the userUnstakeIndex is tracked correctly", async function () {
      const stakeAmount = BigNumber.from("1000000000000000000");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let sharesAfterStake = await winStakingPool.userShares(user1.address);

      await forward(200);
      await winStakingPool.connect(user1).unstake(sharesAfterStake);

      let userUnstakeIndex = await winStakingPool.userUnstakeIndex(
        user1.address
      );
      expect(userUnstakeIndex).to.equal(1);

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      sharesAfterStake = await winStakingPool.userShares(user1.address);

      await forward(200);
      await winStakingPool.connect(user1).unstake(sharesAfterStake);

      userUnstakeIndex = await winStakingPool.userUnstakeIndex(user1.address);
      expect(userUnstakeIndex).to.equal(2);

      await forward(200);
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      await forward(200);
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      sharesAfterStake = await winStakingPool.userShares(user1.address);

      await forward(200);
      await winStakingPool.connect(user1).unstake(sharesAfterStake);

      userUnstakeIndex = await winStakingPool.userUnstakeIndex(user1.address);
      expect(userUnstakeIndex).to.equal(4);
    });
    it("Check if the userUnstakeIndex is tracked correctly (Advanced)", async function () {
      const stakeAmount = BigNumber.from("1000000000000000000");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      await forward(200);
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let sharesAfterStake = await winStakingPool.userShares(user1.address);

      await forward(200);
      await winStakingPool.connect(user1).unstake(sharesAfterStake);

      let userUnstakeIndex = await winStakingPool.userUnstakeIndex(
        user1.address
      );

      expect(userUnstakeIndex).to.equal(2);

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      sharesAfterStake = await winStakingPool.userShares(user1.address);

      await forward(200);
      await winStakingPool.connect(user1).unstake(sharesAfterStake);

      userUnstakeIndex = await winStakingPool.userUnstakeIndex(user1.address);
      expect(userUnstakeIndex).to.equal(3);
    });

    it("User can not unstake 0 tokens", async () => {
      await expect(winStakingPool.connect(user1).unstake(0)).to.be.revertedWith(
        "Cannot unstake 0"
      );
    });
  });
  describe("EES penalty test", () => {
    beforeEach(async () => {
      const block = await hre.ethers.provider.getBlock("latest");
      [deployer, rewardDistributor, user1, user2] = await ethers.getSigners();
      WinWin = await ethers.getContractFactory("WinToken");
      const tokenSupply = 50000000000000;
      const transferAmount: BigNumber = BigNumber.from("100000000000000000000");
      const rewardAmount: BigNumber = BigNumber.from("10000000000000000000");
      const approvalAmount: BigNumber = BigNumber.from("100000000000000000000");
      totalRewards = rewardAmount;

      winToken = await WinWin.deploy(tokenSupply);

      rewardToken = await WinWin.deploy(tokenSupply);

      WinStakingPool = await ethers.getContractFactory("WinStakingPool");
      winStakingPool = await WinStakingPool.deploy(
        winToken.address,
        block.timestamp,
        totalRewards
      );

      const lastTimestamp = (await waffle.provider.getBlock("latest"))
        .timestamp;

      PrizePool = await ethers.getContractFactory("PrizePool", deployer);

      const prizeDistribution = [6000, 900, 600, 300, 100, 2100];

      winPrizePool = await PrizePool.deploy(
        lastTimestamp + 100,
        winStakingPool.address,
        prizeDistribution
      );

      await winStakingPool.setPrizePoolAddress(winPrizePool.address);

      await winPrizePool.addRewardToken(WPLSAddress);

      await winToken
        .connect(deployer)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(rewardDistributor)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(user1)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(user2)
        .approve(winStakingPool.address, approvalAmount);

      await rewardToken
        .connect(rewardDistributor)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(deployer)
        .transfer(winStakingPool.address, totalRewards);
      await winToken.connect(deployer).transfer(user1.address, transferAmount);
      await winToken.connect(deployer).transfer(user2.address, transferAmount);
      await rewardToken
        .connect(deployer)
        .transfer(rewardDistributor.address, transferAmount);

      await winStakingPool.addReward(rewardToken.address, deployer.address);

      await winStakingPool.approveRewardDistributor(
        rewardToken.address,
        rewardDistributor.address,
        true
      );

      await winStakingPool
        .connect(rewardDistributor)
        .notifyRewardAmount(rewardToken.address, rewardAmount);
    });

    it("If user has staked tokens it will be locked for 30 days and lock will apply on individual stakes", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let withdrawableShares = await winStakingPool.getWithdrawableShares(
        user1.address
      );
      // Lock is not completed
      expect(withdrawableShares).to.equal(0);

      // forwarding 40 seconds
      await forward(40);

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      // Now user has two stakes , and locked will be applied indiviudally

      // forwarding to 60 seconds more
      // first stake should be unlocked and second should be still locked
      const lockDuration: number = await winStakingPool.LOCK_DURATION();
      await forward(lockDuration - 40);

      withdrawableShares = await winStakingPool.getWithdrawableShares(
        user1.address
      );

      expect(withdrawableShares).to.equal(stakeAmount);
    });

    it("if user withdraws before unlock time , Penalty will be applied", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const withdrawableShares = await winStakingPool.getWithdrawableShares(
        user1.address
      );
      // Lock is not completed
      expect(withdrawableShares).to.equal(0);

      // forwarding 20 seconds
      await forward(20);

      // Reward during 20 seconds

      let winRewardInfo = await winStakingPool.getWinRewardData();
      let rewardTokenInfo = await winStakingPool.getRewardData(
        rewardToken.address
      );

      let totalWinReward = BN(winRewardInfo.rewardRate.mul(21).toString());
      const totalRewardTokenReward = BN(
        rewardTokenInfo.rewardRate.mul(21).toString()
      );

      let effectiveRewards = BN(
        totalWinReward.multipliedBy(99).div(100).toFixed(0)
      );

      const extraBurnt = totalWinReward.minus(effectiveRewards);
      totalWinReward = effectiveRewards;

      const balance = await winStakingPool.getBalance(
        user1.address,
        0,
        winToken.address
      );

      const totalWinTokens = await winStakingPool.getTotalWinTokens(
        user1.address
      );

      expect(totalWinTokens).to.equal(
        balance._stakedAmount.add(
          totalWinReward
            .minus(winRewardInfo.rewardRate.mul(99).div(100).toString())
            .toString()
        )
      );

      // Unstaking

      const deadAddressWinBalance = await winToken.balanceOf(
        "0x000000000000000000000000000000000000dEaD"
      );

      const deadAddressRewardTokenBalance = await rewardToken.balanceOf(
        "0x000000000000000000000000000000000000dEaD"
      );
      expect(await winStakingPool.userUnstakeIndex(user1.address)).to.equal(0);

      const res = await winStakingPool
        .connect(user1)
        .unstake(balance._sharesAmount);
      const { events } = await res.wait();
      const event = events.find((x) => x.event === "Unstaked");
      // Event testcases
      expect(event.args.penalty).to.be.gt(BigNumber.from("0"));
      expect(event.args.user).to.be.equal(user1.address);
      expect(event.args.shares).to.be.equal(balance._sharesAmount);
      expect(event.args.amount).to.be.equal(
        stakeAmount.add(event.args.penalty)
      );

      expect(await winStakingPool.userUnstakeIndex(user1.address)).to.equal(1);

      const currentDeadAddressWinBalance = await winToken.balanceOf(
        "0x000000000000000000000000000000000000dEaD"
      );

      const currentDeadAddressRewardTokenBalance = await rewardToken.balanceOf(
        "0x000000000000000000000000000000000000dEaD"
      );

      expect(
        currentDeadAddressWinBalance
          .sub(deadAddressWinBalance)
          .sub(extraBurnt.toString())
          .toString()
      ).to.equal(totalWinReward.div(2).toFixed(0));

      expect(
        currentDeadAddressRewardTokenBalance
          .sub(deadAddressRewardTokenBalance)
          .toString()
      ).to.equal(totalRewardTokenReward.dividedBy(2).toString());

      // reward rate of both the reward tokens will increase

      const rewardDuration = await winStakingPool.REWARDS_DURATION();

      const winRewardDuration = await winStakingPool.WIN_REWARD_DURATION();

      const leftTime2 = rewardDuration - 22;

      const leftOutRewardTokenAmount = BN(
        leftTime2 * rewardTokenInfo.rewardRate.toString()
      );

      const winPenaltyRewardRate = totalWinReward
        .div(2)
        .div(winRewardDuration.toString());

      const newRewardTokenRate = leftOutRewardTokenAmount
        .plus(totalRewardTokenReward.div(2))
        .div(rewardDuration.toString());

      winRewardInfo = await winStakingPool.getWinRewardData();
      rewardTokenInfo = await winStakingPool.getRewardData(rewardToken.address);

      expect(winPenaltyRewardRate.toFixed(0).toString()).to.equal(
        winRewardInfo.penaltyRewardRate.toString()
      );

      expect(newRewardTokenRate.toString()).to.equal(
        rewardTokenInfo.rewardRate.toString()
      );
    });

    it("if user withdraws some portion then that penalty on that portion will be applied", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const withdrawableShares = await winStakingPool.getWithdrawableShares(
        user1.address
      );
      // Lock is not completed
      expect(withdrawableShares).to.equal(0);

      // forwarding 20 seconds
      await forward(20);

      // Reward during 20 seconds

      let winRewardInfo = await winStakingPool.getWinRewardData();
      let rewardTokenInfo = await winStakingPool.getRewardData(
        rewardToken.address
      );

      let totalWinReward = BN(winRewardInfo.rewardRate.mul(21).toString());
      const totalRewardTokenReward = BN(
        rewardTokenInfo.rewardRate.mul(21).toString()
      );

      let effectiveRewards = BN(
        totalWinReward.multipliedBy(99).div(100).toFixed(0)
      );

      const extraBurnt = totalWinReward.minus(effectiveRewards);
      totalWinReward = effectiveRewards;

      const balance = await winStakingPool.getBalance(
        user1.address,
        0,
        winToken.address
      );

      const totalWinTokens = await winStakingPool.getTotalWinTokens(
        user1.address
      );

      expect(totalWinTokens).to.equal(
        balance._stakedAmount.add(
          totalWinReward
            .minus(winRewardInfo.rewardRate.mul(99).div(100).toString())
            .toString()
        )
      );

      // Unstaking

      const deadAddressWinBalance = await winToken.balanceOf(
        "0x000000000000000000000000000000000000dEaD"
      );

      const deadAddressRewardTokenBalance = await rewardToken.balanceOf(
        "0x000000000000000000000000000000000000dEaD"
      );
      const shares = await winStakingPool.userShares(user1.address);

      await winStakingPool
        .connect(user1)
        .unstake(BN(shares.toString()).div(2).toString());

      const currentDeadAddressWinBalance = await winToken.balanceOf(
        "0x000000000000000000000000000000000000dEaD"
      );

      const currentDeadAddressRewardTokenBalance = await rewardToken.balanceOf(
        "0x000000000000000000000000000000000000dEaD"
      );

      expect(
        currentDeadAddressWinBalance
          .sub(deadAddressWinBalance)
          .sub(extraBurnt.toString())
          .toString()
      ).to.equal(totalWinReward.div(4).toFixed(0).toString());

      expect(
        currentDeadAddressRewardTokenBalance
          .sub(deadAddressRewardTokenBalance)
          .toString()
      ).to.equal(totalRewardTokenReward.dividedBy(4).toString());

      // reward rate of both the reward tokens will increase

      const rewardDuration = await winStakingPool.REWARDS_DURATION();

      const winRewardDuration = await winStakingPool.WIN_REWARD_DURATION();

      const leftTime2 = rewardDuration - 22;

      const leftOutRewardTokenAmount = BN(
        leftTime2 * rewardTokenInfo.rewardRate.toString()
      );

      const winPenaltyRewardRate = totalWinReward
        .div(4)
        .div(winRewardDuration.toString());

      const newRewardTokenRate = leftOutRewardTokenAmount
        .plus(totalRewardTokenReward.div(4))
        .div(rewardDuration.toString());

      winRewardInfo = await winStakingPool.getWinRewardData();
      rewardTokenInfo = await winStakingPool.getRewardData(rewardToken.address);
      expect(winPenaltyRewardRate.toFixed(0).toString()).to.equal(
        winRewardInfo.penaltyRewardRate.toString()
      );

      expect(newRewardTokenRate.toString()).to.equal(
        rewardTokenInfo.rewardRate.toString()
      );
    });

    it("Claim function claims rewards of unlocked stakes only", async () => {
      let stakeAmount: BigNumber = BigNumber.from("10000000000000000000");

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const lockDuration: number = Number(await winStakingPool.LOCK_DURATION());

      // 20 seconds
      await forward(20);

      stakeAmount = BigNumber.from("20000000000000000000");

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      // 20 seconds
      await forward(20);

      let rewards = await winStakingPool.getClaimableRewards(user1.address);

      expect(rewards[1]).to.equal(0);

      // forwarding rest of the seconds
      await forward(lockDuration - 41);

      rewards = await winStakingPool.getClaimableRewards(user1.address);
      const totalReward = await winStakingPool.getTotalUserRewards(
        user1.address
      );

      expect(totalReward[1]).to.be.above(rewards[1]);

      const user1RewardTokenBalance = await rewardToken.balanceOf(
        user1.address
      );

      await winStakingPool.connect(user1).claim(user1.address);

      const currentUser1RewardTokenBalance = await rewardToken.balanceOf(
        user1.address
      );

      // rewards in 1 second for first stake => 16666934025633336
      expect(
        currentUser1RewardTokenBalance.sub(user1RewardTokenBalance)
      ).to.equal(rewards[1].add("16666934025633336"));
    });

    it("user unstakes some unlocked and some locked stakes ", async () => {
      let stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      const lockDuration: number = Number(await winStakingPool.LOCK_DURATION());

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      // forward 20 seconds

      await forward(20);
      stakeAmount = BigNumber.from("20000000000000000000");

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      // forward 20 seconds
      await forward(20);

      stakeAmount = BigNumber.from("15000000000000000000");

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      // Now user has 2 stakes

      // unlocking  only first stake by forwarding
      await forward(lockDuration - 42);

      const rewards = await winStakingPool.getTotalRewardsOfStake(
        user1.address,
        0
      );

      const rewardTokenBalance = await rewardToken.balanceOf(user1.address);

      const unstakeAmount: BigNumber = BigNumber.from("30000000000000000000");

      const reward1Data = await winStakingPool.getRewardData(
        rewardToken.address
      );
      const stake1Details = await winStakingPool.getBalance(
        user1.address,
        0,
        rewardToken.address
      );

      const sharesTotal = await winStakingPool.sharesTotal();

      await winStakingPool.connect(user1).unstake(unstakeAmount);

      const currentRewardTokenBalance = await rewardToken.balanceOf(
        user1.address
      );

      // Rewards in 1 second => 11111351164846277

      expect(currentRewardTokenBalance.sub(rewardTokenBalance)).to.equal(
        rewards[1].add(
          reward1Data.rewardRate
            .mul(stake1Details._sharesAmount)
            .div(sharesTotal)
        )
      );
    });

    it("User can not withdraw more shares than balance", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const unstakeAmount: BigNumber = BigNumber.from("10000000000000000001");

      await expect(
        winStakingPool.connect(user1).unstake(unstakeAmount)
      ).to.be.revertedWith("Not enough shares");
    });

    it("calculatePenalties function test when all stakes are unlocked", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      // forwarding 30 seconds
      await forward(30);

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let withdrawableShares = await winStakingPool.getWithdrawableShares(
        user1.address
      );

      expect(withdrawableShares).to.equal(0);

      const lockDuration = await winStakingPool.LOCK_DURATION();

      await forward(Number(lockDuration));

      const totalUserRewards = await winStakingPool.getTotalUserRewards(
        user1.address
      );

      const totalClaimableRewards = await winStakingPool.getClaimableRewards(
        user1.address
      );

      expect(totalUserRewards[0]).to.equal(totalClaimableRewards[0]);

      expect(totalUserRewards[1]).to.equal(totalClaimableRewards[1]);

      const totalUserShares = await winStakingPool.userShares(user1.address);

      withdrawableShares = await winStakingPool.getWithdrawableShares(
        user1.address
      );

      expect(withdrawableShares).to.equal(totalUserShares);

      const calculatePenalties = await winStakingPool.calculatePenalties(
        user1.address,
        totalUserShares
      );

      // Both stakes are locked currently so total earned rewards will be penalty

      expect(0).to.equal(calculatePenalties._totalPenaltyRewards[0]);

      expect(0).to.equal(calculatePenalties._totalPenaltyRewards[1]);

      expect(totalClaimableRewards[0]).to.equal(
        calculatePenalties._totalClaimableRewards[0]
      );

      expect(totalClaimableRewards[1]).to.equal(
        calculatePenalties._totalClaimableRewards[1]
      );

      expect(0).to.equal(calculatePenalties._penalizedAmount);
    });

    it("calculatePenalties function test when all stakes are locked", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      // forwarding 30 seconds
      await forward(30);

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const withdrawableShares = await winStakingPool.getWithdrawableShares(
        user1.address
      );

      expect(withdrawableShares).to.equal(0);

      const totalUserRewards = await winStakingPool.getTotalUserRewards(
        user1.address
      );

      const totalUserShares = await winStakingPool.userShares(user1.address);

      const calculatePenalties = await winStakingPool.calculatePenalties(
        user1.address,
        totalUserShares
      );

      // Both stakes are locked currently so total earned rewards will be penalty

      expect(totalUserRewards[0]).to.equal(
        calculatePenalties._totalPenaltyRewards[0]
      );

      expect(totalUserRewards[1]).to.equal(
        calculatePenalties._totalPenaltyRewards[1]
      );

      expect(0).to.equal(calculatePenalties._totalClaimableRewards[0]);

      expect(0).to.equal(calculatePenalties._totalClaimableRewards[1]);

      expect(totalUserShares).to.equal(calculatePenalties._penalizedAmount);
    });

    it("calculatePenalties when some stakes are locked and some are unlocked", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const firstStakeShares = await winStakingPool.getBalance(
        user1.address,
        0,
        winToken.address
      );

      const lockDuration = await winStakingPool.LOCK_DURATION();

      // forwarding 30 seconds
      await forward(30);

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let withdrawableShares = await winStakingPool.getWithdrawableShares(
        user1.address
      );

      expect(withdrawableShares).to.equal(0);

      // 30 forward and 1 second for second stake
      // After this first stake will be unlocked
      await forward(lockDuration - 31);

      withdrawableShares = await winStakingPool.getWithdrawableShares(
        user1.address
      );

      expect(withdrawableShares).to.equal(firstStakeShares._sharesAmount);

      const totalUserRewards = await winStakingPool.getTotalUserRewards(
        user1.address
      );

      const totalClaimableRewards = await winStakingPool.getClaimableRewards(
        user1.address
      );

      const totalUserShares = await winStakingPool.userShares(user1.address);

      const calculatePenalties = await winStakingPool.calculatePenalties(
        user1.address,
        totalUserShares
      );

      expect(totalUserRewards[0].sub(totalClaimableRewards[0])).to.equal(
        calculatePenalties._totalPenaltyRewards[0]
      );

      expect(totalUserRewards[1].sub(totalClaimableRewards[1])).to.equal(
        calculatePenalties._totalPenaltyRewards[1]
      );

      expect(totalClaimableRewards[0]).to.equal(
        calculatePenalties._totalClaimableRewards[0]
      );

      expect(totalClaimableRewards[1]).to.equal(
        calculatePenalties._totalClaimableRewards[1]
      );

      expect(totalUserShares.sub(firstStakeShares._sharesAmount)).to.equal(
        calculatePenalties._penalizedAmount
      );
    });

    it("calculatePenalties when some stakes are locked and some are unlocked with partial withdraw", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const firstStakeShares = await winStakingPool.getBalance(
        user1.address,
        0,
        winToken.address
      );

      const lockDuration = await winStakingPool.LOCK_DURATION();

      // forwarding 30 seconds
      await forward(30);

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let withdrawableShares = await winStakingPool.getWithdrawableShares(
        user1.address
      );

      expect(withdrawableShares).to.equal(0);

      // 30 forward and 1 second for second stake
      // After this first stake will be unlocked
      await forward(lockDuration - 31);

      withdrawableShares = await winStakingPool.getWithdrawableShares(
        user1.address
      );

      expect(withdrawableShares).to.equal(firstStakeShares._sharesAmount);

      const totalUserRewards = await winStakingPool.getTotalUserRewards(
        user1.address
      );

      const totalClaimableRewards = await winStakingPool.getClaimableRewards(
        user1.address
      );

      const secondStakeShares = await winStakingPool.getBalance(
        user1.address,
        1,
        winToken.address
      );

      const calculatePenalties = await winStakingPool.calculatePenalties(
        user1.address,
        firstStakeShares._sharesAmount.add(
          secondStakeShares._sharesAmount.div(2)
        )
      );

      expect(totalUserRewards[0].sub(totalClaimableRewards[0]).div(2)).to.equal(
        calculatePenalties._totalPenaltyRewards[0]
      );

      expect(totalUserRewards[1].sub(totalClaimableRewards[1]).div(2)).to.equal(
        calculatePenalties._totalPenaltyRewards[1]
      );

      expect(totalClaimableRewards[0]).to.equal(
        calculatePenalties._totalClaimableRewards[0]
      );

      expect(totalClaimableRewards[1]).to.equal(
        calculatePenalties._totalClaimableRewards[1]
      );

      expect(secondStakeShares._sharesAmount.div(2)).to.equal(
        calculatePenalties._penalizedAmount
      );
    });
  });

  describe("Automatic Win reward schedule test", () => {
    beforeEach(async () => {
      [deployer, rewardDistributor, user1, user2] = await ethers.getSigners();
      WinWin = await ethers.getContractFactory("WinToken");
      const tokenSupply = 50000000000000;
      const transferAmount: BigNumber = BigNumber.from("100000000000000000000");
      const rewardAmount: BigNumber = BigNumber.from("10000000000000000000");
      const approvalAmount: BigNumber = BigNumber.from("100000000000000000000");
      totalRewards = rewardAmount;

      winToken = await WinWin.deploy(tokenSupply);

      rewardToken = await WinWin.deploy(tokenSupply);

      const block = await hre.ethers.provider.getBlock("latest");

      WinStakingPool = await ethers.getContractFactory("WinStakingPool");
      winStakingPool = await WinStakingPool.deploy(
        winToken.address,
        block.timestamp + 3,
        totalRewards
      );

      const lastTimestamp = (await waffle.provider.getBlock("latest"))
        .timestamp;

      PrizePool = await ethers.getContractFactory("PrizePool", deployer);

      const prizeDistribution = [6000, 900, 600, 300, 100, 2100];

      winPrizePool = await PrizePool.deploy(
        lastTimestamp + 100,
        winStakingPool.address,
        prizeDistribution
      );

      await winStakingPool.setPrizePoolAddress(winPrizePool.address);

      await winPrizePool.addRewardToken(WPLSAddress);

      await winToken
        .connect(deployer)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(user1)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(user2)
        .approve(winStakingPool.address, approvalAmount);

      await rewardToken
        .connect(rewardDistributor)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(deployer)
        .transfer(winStakingPool.address, totalRewards);

      await winToken.connect(deployer).transfer(user1.address, transferAmount);
      await winToken.connect(deployer).transfer(user2.address, transferAmount);

      await rewardToken
        .connect(deployer)
        .transfer(rewardDistributor.address, transferAmount);

      await winStakingPool.addReward(rewardToken.address, deployer.address);

      await winStakingPool.approveRewardDistributor(
        rewardToken.address,
        rewardDistributor.address,
        true
      );

      await winStakingPool
        .connect(rewardDistributor)
        .notifyRewardAmount(rewardToken.address, rewardAmount);
    });

    it("Win Rewards will not be distributed during no stakes", async function () {
      // Passed seconds are => 12 seconds
      // WinRewardDuration => 86400seconds
      // Remaining Seconds => 86400-12 => 86388+1

      const rConstant = await winStakingPool.R_CONSTANT();
      const winRewardDuration = await winStakingPool.WIN_REWARD_DURATION();
      const winDetails = await winStakingPool.getWinRewardData();
      let winReward = await winStakingPool.getWinRewardDetails();
      let totalLockedToken = await winStakingPool.totalLockedTokens();

      expect(winReward.rewardRate).to.equal(
        totalRewards.div(rConstant * winRewardDuration)
      );

      expect(totalLockedToken).to.equal(0);

      await forward(86389);

      const oldWinRate = winReward.rewardRate;

      // Reward Rate for second day
      const totalRewardsForFirstDay =
        winReward.rewardRate.mul(winRewardDuration);
      const totalRemaining = winDetails.totalRemainingReward.sub(
        totalRewardsForFirstDay
      );
      const newRewardRate = totalRemaining.div(rConstant * winRewardDuration);

      winReward = await winStakingPool.getWinRewardDetails();

      expect(winReward.rewardsAccumlated).to.equal(
        oldWinRate.mul(86388).add(newRewardRate).mul(99).div(100)
      );

      expect(winReward.rewardRate).to.equal(newRewardRate);

      expect(winReward.newTotalRemainingRewards).to.equal(totalRemaining);

      expect(winReward.newCurrentDayStartingTimestamp).to.equal(
        winDetails.currentDayStartTime.add(winRewardDuration)
      );

      totalLockedToken = await winStakingPool.totalLockedTokens();
      expect(totalLockedToken).to.equal(0);

      // Now Stake and rewards distribution will start

      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      totalLockedToken = await winStakingPool.totalLockedTokens();
      expect(totalLockedToken).to.equal(stakeAmount);

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      totalLockedToken = await winStakingPool.totalLockedTokens();
      expect(totalLockedToken).to.equal(
        stakeAmount.mul(2).add(winReward.rewardRate.mul(99).div(100))
      );
    });

    it("As soon as all stakes are removed , win reward distribution will stop", async function () {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const rConstant = await winStakingPool.R_CONSTANT();
      const winRewardDuration = await winStakingPool.WIN_REWARD_DURATION();

      const rewardRate = totalRewards.div(rConstant * winRewardDuration);

      // forward 30 seconds
      await forward(30);

      const totalAccumlatedRewards = rewardRate.mul(30);

      const totalFetchedRewards = await winStakingPool.getTotalUserRewards(
        user1.address
      );

      expect(totalFetchedRewards[0]).to.equal(
        totalAccumlatedRewards.mul(99).div(100)
      );

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let totalLockedToken = await winStakingPool.totalLockedTokens();

      // multiplying rewardrate by 31 as second stake will take 1 seconds
      expect(totalLockedToken).to.equal(
        stakeAmount.mul(2).add(rewardRate.mul(31).mul(99).div(100))
      );

      const user1WinBalance = await winToken.balanceOf(user1.address);

      let totalUserShares = await winStakingPool.userShares(user1.address);

      await winStakingPool.connect(user1).unstake(totalUserShares);

      const currentUserWinBalance = await winToken.balanceOf(user1.address);

      // For Precision dividing it by 10
      expect(currentUserWinBalance.sub(user1WinBalance).div(10)).to.equal(
        stakeAmount.mul(2).div(10)
      );

      totalLockedToken = await winStakingPool.totalLockedTokens();

      expect(totalLockedToken).to.equal(0);

      // forwarding 10 days
      await forward(864000);

      totalLockedToken = await winStakingPool.totalLockedTokens();

      expect(totalLockedToken).to.equal(0);

      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      // After stake totalLockedTokens increases to stakeAMount

      totalUserShares = await winStakingPool.userShares(user1.address);

      totalLockedToken = await winStakingPool.totalLockedTokens();

      expect(totalUserShares).to.equal(stakeAmount);

      expect(totalLockedToken).to.equal(stakeAmount);
    });

    it("Reward rate will be set according to total rewards", async function () {
      const winRewardDetails = await winStakingPool.getWinRewardDetails();
      const winRewardDuration = await winStakingPool.WIN_REWARD_DURATION();

      const rConstant = await winStakingPool.R_CONSTANT();

      const firstDayTotalRewards = totalRewards.div(rConstant);

      const firstDayRewardRate = firstDayTotalRewards.div(winRewardDuration);

      expect(winRewardDetails.rewardRate).to.equal(firstDayRewardRate);
    });

    it("Reward rate will change as days changes", async function () {
      const rConstant = await winStakingPool.R_CONSTANT();
      const firstDayTotalRewards = totalRewards.div(rConstant);
      const winRewardDuration = await winStakingPool.WIN_REWARD_DURATION();

      const firstDayRewardRate = firstDayTotalRewards.div(winRewardDuration);

      const secondDayTotalRewards = totalRewards
        .sub(firstDayTotalRewards)
        .div(rConstant);

      const secondDayRewardRate = secondDayTotalRewards.div(winRewardDuration);

      const thirdDayTotalRewards = totalRewards
        .sub(firstDayTotalRewards.add(secondDayTotalRewards))
        .div(rConstant);

      const thirdDayRewardRate = thirdDayTotalRewards.div(winRewardDuration);

      let winRewardDetails = await winStakingPool.getWinRewardDetails();

      // First day
      expect(winRewardDetails.rewardRate).to.equal(firstDayRewardRate);

      await forward(86400);

      // second day
      winRewardDetails = await winStakingPool.getWinRewardDetails();

      expect(winRewardDetails.rewardRate).to.equal(secondDayRewardRate);

      await forward(86400);

      // third day
      winRewardDetails = await winStakingPool.getWinRewardDetails();

      expect(winRewardDetails.rewardRate).to.equal(thirdDayRewardRate);
    });

    it("user will get rewards according to updated reward rate each day", async function () {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const rConstant = await winStakingPool.R_CONSTANT();
      const firstDayTotalRewards = totalRewards.div(rConstant);
      const winRewardDuration = await winStakingPool.WIN_REWARD_DURATION();

      const firstDayRewardRate = firstDayTotalRewards.div(winRewardDuration);

      const secondDayTotalRewards = totalRewards
        .sub(firstDayTotalRewards)
        .div(rConstant);

      const secondDayRewardRate = secondDayTotalRewards.div(winRewardDuration);

      const thirdDayTotalRewards = totalRewards
        .sub(firstDayTotalRewards.add(secondDayTotalRewards))
        .div(rConstant);

      const thirdDayRewardRate = thirdDayTotalRewards.div(winRewardDuration);

      await forward(172787);

      let totalUserRewards = firstDayRewardRate
        .mul(86400 - 13)
        .add(secondDayRewardRate.mul(86400));

      totalUserRewards = totalUserRewards.mul(99).div(100);

      const userRewards = await winStakingPool.getTotalUserRewards(
        user1.address
      );

      expect(userRewards[0]).to.equal(totalUserRewards);

      const winRewardDetails = await winStakingPool.getWinRewardDetails();

      expect(winRewardDetails.rewardRate).to.equal(thirdDayRewardRate);
    });

    it("Penalty win reward is being updated on unstaking before 30 days", async function () {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      await forward(20);

      const rewardDuration = await winStakingPool.WIN_REWARD_DURATION();

      let winRewardInfo = await winStakingPool.getWinRewardData();

      const totalUserRewards = winRewardInfo.rewardRate
        .mul(21)
        .mul(99)
        .div(100);

      const unstakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).unstake(unstakeAmount);

      winRewardInfo = await winStakingPool.getWinRewardData();

      const penaltyRewardRate = totalUserRewards.div(2).div(rewardDuration);

      expect(winRewardInfo.penaltyRewardRate).to.equal(penaltyRewardRate);
    });

    it("User will get penalty rewards as well", async function () {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      await forward(20);

      const rewardDuration = await winStakingPool.WIN_REWARD_DURATION();

      let winRewardInfo = await winStakingPool.getWinRewardData();

      const totalUserRewards = winRewardInfo.rewardRate
        .mul(21)
        .mul(99)
        .div(100);

      const unstakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).unstake(unstakeAmount);

      const penaltyRewardRate = totalUserRewards.div(2).div(rewardDuration);

      await winStakingPool.connect(user2).stake(stakeAmount, [], [], true);

      winRewardInfo = await winStakingPool.getWinRewardData();

      await forward(30);

      const totalUser2Rewards = winRewardInfo.rewardRate
        .mul(30)
        .mul(99)
        .div(100)
        .add(penaltyRewardRate.mul(30));

      const userFetchedRewards = await winStakingPool.getTotalUserRewards(
        user2.address
      );

      expect(userFetchedRewards[0]).to.equal(totalUser2Rewards);
    });

    it("Penalty reward should no longer applied once penalty period is completed", async function () {
      const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      await forward(20);

      const rewardDuration = await winStakingPool.WIN_REWARD_DURATION();

      let winRewardInfo = await winStakingPool.getWinRewardData();

      let totalUserRewards = winRewardInfo.rewardRate.mul(21).mul(99).div(100); // adding 1 as unstake will increate block.timestamp by 1

      const unstakeAmount: BigNumber = BigNumber.from("10000000000000000000");
      await winStakingPool.connect(user1).unstake(unstakeAmount);

      const penaltyRewardRate = totalUserRewards.div(2).div(rewardDuration);

      await winStakingPool.connect(user2).stake(stakeAmount, [], [], true);

      winRewardInfo = await winStakingPool.getWinRewardData();

      // 86400-35(passed seconds)
      await forward(86365);

      totalUserRewards = winRewardInfo.rewardRate
        .mul(86365)
        .mul(99)
        .div(100)
        .add(penaltyRewardRate.mul(86365));

      const winRewardDetails = await winStakingPool.getWinRewardDetails();

      // Forwardiing  50 seconds
      // Only 34 seconds are remaining to complete penalty period
      // so penalty reward will only apply to 34 seconds
      await forward(50);

      totalUserRewards = totalUserRewards.add(
        winRewardDetails.rewardRate
          .mul(50)
          .mul(99)
          .div(100)
          .add(penaltyRewardRate.mul(34))
      );

      const totalFetchedRewards = await winStakingPool.getTotalUserRewards(
        user2.address
      );

      expect(totalFetchedRewards[0]).to.equal(totalUserRewards);
    });
  });
  describe("TWAB tests", () => {
    beforeEach(async () => {
      const block = await hre.ethers.provider.getBlock("latest");
      [deployer, rewardDistributor, user1, user2] = await ethers.getSigners();
      WinWin = await ethers.getContractFactory("WinToken");
      const tokenSupply = 50000000000000;
      const transferAmount: BigNumber = BigNumber.from("100000000000000000000");
      const rewardAmount: BigNumber = BigNumber.from("10000000000000000000");
      const approvalAmount: BigNumber = BigNumber.from("100000000000000000000");

      winToken = await WinWin.deploy(tokenSupply);

      rewardToken = await WinWin.deploy(tokenSupply);

      WinStakingPool = await ethers.getContractFactory("WinStakingPool");

      winStakingPool = await WinStakingPool.deploy(
        winToken.address,
        block.timestamp,
        totalRewards
      );

      const lastTimestamp = (await waffle.provider.getBlock("latest"))
        .timestamp;

      PrizePool = await ethers.getContractFactory("PrizePool", deployer);

      const prizeDistribution = [6000, 900, 600, 300, 100, 2100];

      winPrizePool = await PrizePool.deploy(
        lastTimestamp + 100,
        winStakingPool.address,
        prizeDistribution
      );

      await winStakingPool.setPrizePoolAddress(winPrizePool.address);

      await winPrizePool.addRewardToken(WPLSAddress);

      await winToken
        .connect(deployer)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(rewardDistributor)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(user1)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(user2)
        .approve(winStakingPool.address, approvalAmount);

      await rewardToken
        .connect(rewardDistributor)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(deployer)
        .transfer(winStakingPool.address, totalRewards);

      await winToken.connect(deployer).transfer(user1.address, transferAmount);
      await winToken.connect(deployer).transfer(user2.address, transferAmount);

      await rewardToken
        .connect(deployer)
        .transfer(rewardDistributor.address, transferAmount);

      await winStakingPool.addReward(rewardToken.address, deployer.address);

      await winStakingPool.approveRewardDistributor(
        rewardToken.address,
        rewardDistributor.address,
        true
      );

      await winStakingPool
        .connect(rewardDistributor)
        .notifyRewardAmount(rewardToken.address, rewardAmount);
    });
    context("getBalanceAt", () => {
      it("should return 0 for time before twabs", async () => {
        const lastTimestamp =
          (await waffle.provider.getBlock("latest")).timestamp + 1;
        await winStakingPool.connect(user1).stake(1000, [], [], true);
        expect(
          await winStakingPool.getBalanceAt(user1.address, lastTimestamp - 100)
        ).to.equal(0);
      });

      it("should return the current balance if time at or after last twab", async () => {
        const lastTimestamp =
          (await waffle.provider.getBlock("latest")).timestamp + 1;
        await winStakingPool.connect(user1).stake(1000, [], [], true);
        await forward(1000);
        expect(
          await winStakingPool.getBalanceAt(user1.address, lastTimestamp + 1000)
        ).to.equal("1000");
      });

      it("should return the current balance after the twab", async () => {
        const lastTimestamp =
          (await waffle.provider.getBlock("latest")).timestamp + 1;
        await winStakingPool.connect(user1).stake(1000, [], [], true);
        expect(
          await winStakingPool.getBalanceAt(user1.address, lastTimestamp + 1000)
        ).to.equal("1000");
      });
    });
  });
  describe("Sponser Testcases", () => {
    beforeEach(async () => {
      const block = await hre.ethers.provider.getBlock("latest");
      [deployer, rewardDistributor, user1, user2] = await ethers.getSigners();
      WinWin = await ethers.getContractFactory("WinToken");
      const tokenSupply = 50000000000000;
      const transferAmount: BigNumber = BigNumber.from("100000000000000000000");
      const rewardAmount: BigNumber = BigNumber.from("10000000000000000000");
      const approvalAmount: BigNumber = BigNumber.from("100000000000000000000");

      winToken = await WinWin.deploy(tokenSupply);

      rewardToken = await WinWin.deploy(tokenSupply);

      WinStakingPool = await ethers.getContractFactory("WinStakingPool");

      winStakingPool = await WinStakingPool.deploy(
        winToken.address,
        block.timestamp,
        totalRewards
      );

      const lastTimestamp = (await waffle.provider.getBlock("latest"))
        .timestamp;

      PrizePool = await ethers.getContractFactory("PrizePool", deployer);

      const prizeDistribution = [6000, 900, 600, 300, 100, 2100];

      winPrizePool = await PrizePool.deploy(
        lastTimestamp + 100,
        winStakingPool.address,
        prizeDistribution
      );

      await winStakingPool.setPrizePoolAddress(winPrizePool.address);

      await winPrizePool.addRewardToken(WPLSAddress);

      await winToken
        .connect(deployer)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(rewardDistributor)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(user1)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(user2)
        .approve(winStakingPool.address, approvalAmount);

      await rewardToken
        .connect(rewardDistributor)
        .approve(winStakingPool.address, approvalAmount);

      await winToken
        .connect(deployer)
        .transfer(winStakingPool.address, totalRewards);

      await winToken.connect(deployer).transfer(user1.address, transferAmount);
      await winToken.connect(deployer).transfer(user2.address, transferAmount);

      await rewardToken
        .connect(deployer)
        .transfer(rewardDistributor.address, transferAmount);

      await winStakingPool.addReward(rewardToken.address, deployer.address);

      await winStakingPool.approveRewardDistributor(
        rewardToken.address,
        rewardDistributor.address,
        true
      );

      await winStakingPool
        .connect(rewardDistributor)
        .notifyRewardAmount(rewardToken.address, rewardAmount);
    });
    it("should get tickets when user stakes and has opted in Prize Pool", async () => {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");
      const ticketsBeforeStaking = await winPrizePool.totalTicketNumber();
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      await winStakingPool
        .connect(user1)
        .stake(stakeAmount.mul(2), [], [], true);
      await winStakingPool
        .connect(user1)
        .stake(stakeAmount.div(2), [], [], true);
      const ticketsAfterStaking = await winPrizePool.totalTicketNumber();

      const { start, end } = await winPrizePool.getRangeDetails(
        user1.address,
        0
      );
      expect(await winStakingPool.userShares(user1.address)).to.be.equal(
        ticketsAfterStaking.sub(ticketsBeforeStaking)
      );
      expect(start).to.be.equal(1);
      expect(end).to.be.equal(stakeAmount);
    });
    it("should update tickets when user unstakes", async () => {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");
      const unStakeAmount: BigNumber = ethers.utils.parseEther("1");

      const ticketsBeforeStaking = await winPrizePool.totalTicketNumber();
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const ticketAfterStaking = await winPrizePool.totalTicketNumber();

      await winStakingPool.connect(user1).unstake(unStakeAmount);

      const ticketAfterUnstaking = await winPrizePool.totalTicketNumber();
      const { start, end } = await winPrizePool.getRangeDetails(
        user1.address,
        0
      );

      expect(ticketAfterStaking.sub(ticketsBeforeStaking)).to.be.equal(
        stakeAmount
      );
      expect(ticketAfterStaking.sub(ticketAfterUnstaking)).to.be.equal(
        unStakeAmount
      );
      expect(start).to.be.equal(1);
      expect(end).to.be.equal(stakeAmount.sub(unStakeAmount));
      expect(await winPrizePool.totalTicketNumber()).to.be.equal(
        stakeAmount.sub(unStakeAmount)
      );
    });
    it("should burn tickets when unstaking all amount", async () => {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");
      const unStakeAmount: BigNumber = ethers.utils.parseEther("10");
      const ticketsBeforeStaking = await winPrizePool.totalTicketNumber();
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      const ticketAfterStaking = await winPrizePool.totalTicketNumber();
      await winStakingPool.connect(user1).unstake(unStakeAmount);
      const ticketAfterUnstaking = await winPrizePool.totalTicketNumber();
      expect(ticketAfterStaking.sub(ticketsBeforeStaking)).to.be.equal(
        stakeAmount
      );
      expect(ticketAfterUnstaking).to.be.equal(ticketsBeforeStaking);
    });
    it("should not get tickets when not opted for prizePool", async () => {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], false);
      expect(await winPrizePool.totalTicketNumber()).to.be.equal(0);
    });
    it("should not change preference once staked", async () => {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      await expect(
        winStakingPool.connect(user1).stake(stakeAmount, [], [], false)
      ).to.be.revertedWith("Cannot change PrizePool Preference.");
    });
    it("should be able to change preference after unstaking all funds", async () => {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");
      await winStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      await expect(
        winStakingPool.connect(user1).stake(stakeAmount, [], [], false)
      ).to.be.revertedWith("Cannot change PrizePool Preference.");
      await winStakingPool.connect(user1).unstake(stakeAmount);
      expect(
        await winStakingPool.connect(user1).stake(stakeAmount, [], [], false)
      ).to.be.ok;
    });
  });
});
