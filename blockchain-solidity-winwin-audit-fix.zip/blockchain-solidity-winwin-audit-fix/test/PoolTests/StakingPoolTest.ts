import { expect } from "chai";
import hre, { ethers, waffle } from "hardhat";
import { BigNumber, Contract, ContractFactory } from "ethers";
import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import { BigNumber as BN } from "bignumber.js";
import axios from "axios";

async function forward(seconds: any) {
  const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;
  await waffle.provider.send("evm_setNextBlockTimestamp", [
    lastTimestamp + seconds,
  ]);
  await waffle.provider.send("evm_mine", []);
}
let deployer: SignerWithAddress;
let user1: SignerWithAddress;
let buyAndBurn: SignerWithAddress;
let abi: any;
let erc20Abi: any;
let StakingPool: ContractFactory;
let loanStakingPool: Contract;
let winStakingPool: Contract;
let LoanStrategy: ContractFactory;
let loanStrategy: Contract;
let WinWin: ContractFactory;
let winToken: Contract;
let rewardToken: Contract;
let rewardToken2: Contract;
let PrizePool: ContractFactory;
//  let prizePool: Contract;
let loanPrizePool: Contract;
let winPrizePool: Contract;
let stakeAmount: BigNumber;
let transferAmount: BigNumber;
let approvalAmount: BigNumber;
let rewardAmount: BigNumber;
const loanTokenAddress = "0x9159f1D2a9f51998Fc9Ab03fbd8f265ab14A1b3B";
const yieldSourceAddress = "0x853F0CD4B0083eDf7cFf5Ad9A296f02Ffb71C995";
const USDLAddress = "0x0dEEd1486bc52aA0d3E6f8849cEC5adD6598A162";
const routerAddress = "0x98bf93ebf5c380C0e6Ae8e192A7e2AE08edAcc02";
const WPLSAddress = "0xA1077a294dDE1B09bB078844df40758a5D0f9a27";
let routerInstance;
let stakingTokenInstance: any;

describe("Staking Test Cases", () => {
  beforeEach(async () => {
    const tokenSupply = 50000000000000;
    if (!abi) {
      [deployer, user1, buyAndBurn] = await ethers.getSigners();
      erc20Abi = await hre.artifacts.readArtifact(
        "@openzeppelin/contracts/token/ERC20/IERC20.sol:IERC20"
      );
      abi = await axios.get(
        `https://api.etherscan.io/api?module=contract&action=getabi&address=0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D&apikey=${process.env.ETHERSCAN_API_KEY}`
      );

      const path = [WPLSAddress, loanTokenAddress];

      await hre.network.provider.send("hardhat_setBalance", [
        deployer.address,
        "0x100000000000000000000",
      ]);

      routerInstance = new ethers.Contract(
        routerAddress,
        abi.data.result,
        deployer
      );
      const options = { value: ethers.utils.parseEther("1000000.0") };

      await routerInstance.swapExactETHForTokens(
        0,
        path,
        user1.address,
        "10000000000000",
        options
      );
      stakingTokenInstance = new ethers.Contract(
        loanTokenAddress,
        erc20Abi.abi,
        user1
      );
    }
    WinWin = await ethers.getContractFactory("WinToken");

    winToken = await WinWin.connect(deployer).deploy(tokenSupply);
    winToken.deployed();

    rewardToken = await WinWin.connect(deployer).deploy(tokenSupply);
    rewardToken.deployed();

    rewardToken2 = await WinWin.connect(deployer).deploy(tokenSupply);
    rewardToken2.deployed();

    StakingPool = await ethers.getContractFactory("YieldStakingPool", deployer);
    loanStakingPool = await StakingPool.deploy(loanTokenAddress);
    winStakingPool = await StakingPool.deploy(winToken.address);
    const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;
    PrizePool = await ethers.getContractFactory("PrizePool", deployer);
    const prizeDistribution = [6000, 900, 600, 300, 100, 2100];
    loanPrizePool = await PrizePool.deploy(
      lastTimestamp + 100,
      loanStakingPool.address,
      prizeDistribution
    );
    winPrizePool = await PrizePool.deploy(
      lastTimestamp + 100,
      winStakingPool.address,
      prizeDistribution
    );

    LoanStrategy = await ethers.getContractFactory("LOANStrategy", deployer);
    const distributionAddress = [
      loanPrizePool.address,
      loanStakingPool.address,
      winPrizePool.address,
      winStakingPool.address,
      buyAndBurn.address,
    ];
    const distributionShares = [6000, 3000, 600, 300, 100];

    loanStrategy = await LoanStrategy.deploy(
      loanTokenAddress,
      USDLAddress,
      yieldSourceAddress,
      distributionAddress,
      distributionShares
    );
    await loanStakingPool.setPrizePoolAddress(loanPrizePool.address);

    await winStakingPool.setPrizePoolAddress(winPrizePool.address);

    await winPrizePool.addRewardToken(WPLSAddress);

    await loanPrizePool.addRewardToken(WPLSAddress);

    await loanStakingPool
      .connect(deployer)
      .modifyStrategyAddress(loanStrategy.address);

    await stakingTokenInstance
      .connect(user1)
      .approve(loanStakingPool.address, "10000000000000");

    await stakingTokenInstance
      .connect(user1)
      .approve(loanStrategy.address, "100000000000000000");

    transferAmount = BigNumber.from("1000000000000000000000");
    rewardAmount = BigNumber.from("100000000000000000000");
    stakeAmount = ethers.utils.parseEther("100");
    approvalAmount = BigNumber.from("1000000000000000000000000000000000000");

    await stakingTokenInstance
      .connect(deployer)
      .approve(loanStakingPool.address, approvalAmount);
    await rewardToken
      .connect(deployer)
      .approve(loanStakingPool.address, approvalAmount);
    await stakingTokenInstance
      .connect(user1)
      .approve(loanStakingPool.address, stakeAmount);
  });

  describe("Reward testcase", () => {
    it("Reward Token not added before Approval", async function () {
      await expect(
        loanStakingPool
          .connect(deployer)
          .approveRewardDistributor(rewardToken.address, user1.address, true)
      ).to.be.revertedWith("Reward Token not added");
    });

    it("Only Owner should be allowed to approve Reward Token ", async function () {
      await expect(
        loanStakingPool
          .connect(user1)
          .approveRewardDistributor(rewardToken.address, user1.address, true)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Only Owner should be allowed to add Reward Token ", async function () {
      await expect(
        loanStakingPool
          .connect(user1)
          .addReward(rewardToken.address, user1.address)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Add new Reward Tokens", async function () {
      await loanStakingPool
        .connect(deployer)
        .addReward(rewardToken.address, deployer.address);

      let rewardData = await loanStakingPool.getRewardData(rewardToken.address);

      let rewardTokenCount = await loanStakingPool.getRewardTokensCount();

      let rewardTokens = await loanStakingPool.getRewardTokens();

      expect(rewardData.lastUpdateTime).to.not.equal(0);

      expect(rewardTokenCount).to.equal(1);

      expect(rewardTokens[0]).to.equal(rewardToken.address);

      await loanStakingPool
        .connect(deployer)
        .addReward(rewardToken2.address, deployer.address);

      rewardData = await loanStakingPool.getRewardData(rewardToken2.address);

      rewardTokenCount = await loanStakingPool.getRewardTokensCount();

      rewardTokens = await loanStakingPool.getRewardTokens();

      expect(rewardData.lastUpdateTime).to.not.equal(0);

      expect(rewardTokenCount).to.equal(2);

      expect(rewardTokens[0]).to.equal(rewardToken.address);
      expect(rewardTokens[1]).to.equal(rewardToken2.address);
    });

    it("Same Reward token cannot be added twice ", async function () {
      await loanStakingPool
        .connect(deployer)
        .addReward(rewardToken.address, deployer.address);

      await expect(
        loanStakingPool
          .connect(deployer)
          .addReward(rewardToken.address, deployer.address)
      ).to.be.revertedWith("Reward Token already added");
    });

    it("Only approved caller can set reward rate", async function () {
      await expect(
        loanStakingPool
          .connect(deployer)
          .notifyRewardAmount(rewardToken.address, stakeAmount)
      ).to.be.revertedWith("Caller not approved to add rewards");
    });

    it("Reward Token Amount is zero", async function () {
      await loanStakingPool
        .connect(deployer)
        .addReward(rewardToken.address, deployer.address);
      await loanStakingPool
        .connect(deployer)
        .approveRewardDistributor(rewardToken.address, deployer.address, true);
      await expect(
        loanStakingPool
          .connect(deployer)
          .notifyRewardAmount(rewardToken.address, 0)
      ).to.be.revertedWith("No reward");
    });

    it("Calculate and check Reward Rate", async function () {
      const rewardAmount: BigNumber = BigNumber.from("1000000000000000000000");
      await loanStakingPool
        .connect(deployer)
        .addReward(rewardToken.address, deployer.address);
      await loanStakingPool
        .connect(deployer)
        .approveRewardDistributor(rewardToken.address, deployer.address, true);

      await loanStakingPool
        .connect(deployer)
        .notifyRewardAmount(rewardToken.address, rewardAmount);
      const rewardData = await loanStakingPool
        .connect(deployer)
        .getRewardData(rewardToken.address);

      const rewardDuration: number = await loanStakingPool.REWARDS_DURATION();
      const rewardRate = BN(rewardAmount.toString()).div(
        BN(rewardDuration.toString())
      );

      expect(rewardData.rewardRate.toString()).to.equal(rewardRate.toString());
    });

    it("Calculate Rewards for total Duration", async function () {
      const rewardDuration = 2592000;

      const rewardsRate = await loanStakingPool
        .connect(deployer)
        .getRewardData(rewardToken.address);

      const totalRewards =
        BigInt(rewardDuration) * BigInt(rewardsRate.rewardRate);

      const totalRewardAmount = await loanStakingPool
        .connect(deployer)
        .getRewardForDuration(rewardToken.address);

      expect(totalRewardAmount).to.equal(totalRewards);
    });
  });

  describe("Stake , unstake and earned reward test", () => {
    it("Stake amount should be greater than zero", async function () {
      await expect(
        loanStakingPool.connect(deployer).stake(0, [], [], true)
      ).to.be.revertedWith("Cannot stake 0");
    });

    it("Stake tokens to check total supply & total stake balance of User", async function () {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");

      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      expect(await loanStakingPool.connect(user1).totalSupply()).to.equal(
        stakeAmount
      );
      expect(
        await loanStakingPool.connect(user1).totalBalances(user1.address)
      ).to.equal(stakeAmount);
    });

    it("Cannot unstake zero Amount", async function () {
      await expect(
        loanStakingPool.connect(user1).unstake(0)
      ).to.be.revertedWith("Cannot unstake 0");
    });

    it("User can not unstake more than balance", async () => {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");
      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const unstakeAmount: BigNumber = ethers.utils.parseEther("100");

      await expect(
        loanStakingPool.connect(user1).unstake(unstakeAmount)
      ).to.be.revertedWith("Insufficient Staked Balance");
    });
    it("Check if the userUnstakeIndex is tracked correctly", async function () {
      const stakeAmount = BigNumber.from("1000000000000000000");
      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let balanceAfterStake = await loanStakingPool.totalBalances(
        user1.address
      );

      await forward(200);
      await loanStakingPool.connect(user1).unstake(balanceAfterStake);

      let userUnstakeIndex = await loanStakingPool.userUnstakeIndex(
        user1.address
      );
      expect(userUnstakeIndex).to.equal(1);

      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      balanceAfterStake = await loanStakingPool.totalBalances(user1.address);

      await forward(200);
      await loanStakingPool.connect(user1).unstake(balanceAfterStake);

      userUnstakeIndex = await loanStakingPool.userUnstakeIndex(user1.address);
      expect(userUnstakeIndex).to.equal(2);

      await forward(200);
      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      await forward(200);
      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      balanceAfterStake = await loanStakingPool.totalBalances(user1.address);

      await forward(200);
      await loanStakingPool.connect(user1).unstake(balanceAfterStake);

      userUnstakeIndex = await loanStakingPool.userUnstakeIndex(user1.address);
      expect(userUnstakeIndex).to.equal(4);
    });
    it("Check if the userUnstakeIndex is tracked correctly (advanced) ", async function () {
      const stakeAmount = BigNumber.from("1000000000000000000");
      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      await forward(200);
      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let balanceAfterStake = await loanStakingPool.totalBalances(
        user1.address
      );

      await forward(200);
      await loanStakingPool.connect(user1).unstake(balanceAfterStake);

      let userUnstakeIndex = await loanStakingPool.userUnstakeIndex(
        user1.address
      );

      expect(userUnstakeIndex).to.equal(2);

      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      balanceAfterStake = await loanStakingPool.totalBalances(user1.address);

      await forward(200);
      await loanStakingPool.connect(user1).unstake(balanceAfterStake);

      userUnstakeIndex = await loanStakingPool.userUnstakeIndex(user1.address);
      expect(userUnstakeIndex).to.equal(3);
    });

    it("unstake some staked tokens and check total Supply", async function () {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");

      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const userBalance = await loanStakingPool.totalBalances(user1.address);
      const totalSupply = await loanStakingPool.totalSupply();

      const unstakeAmount = "1000000000000";

      await loanStakingPool.connect(user1).unstake(unstakeAmount);

      const userBalanceAfter = await loanStakingPool.totalBalances(
        user1.address
      );
      const totalSupplyAfter = await loanStakingPool.totalSupply();

      expect(userBalance.sub(userBalanceAfter)).to.equal(unstakeAmount);

      expect(totalSupply.sub(totalSupplyAfter)).to.equal(unstakeAmount);
    });

    it("Calculate claimable earned tokens", async function () {
      const rewardAmount = BigInt("1000000000000000000000");
      await loanStakingPool
        .connect(deployer)
        .addReward(rewardToken.address, deployer.address);

      await loanStakingPool
        .connect(deployer)
        .approveRewardDistributor(rewardToken.address, deployer.address, true);

      await loanStakingPool
        .connect(deployer)
        .notifyRewardAmount(rewardToken.address, rewardAmount);
      const stakeAmount = BigNumber.from("1000000000000000000");
      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      await forward(30);

      const totalUserBalance = await loanStakingPool.totalBalances(
        user1.address
      );

      const totalSupply = await loanStakingPool.totalSupply();

      const rewardData = await loanStakingPool.getRewardData(
        rewardToken.address
      );

      const totalRewardsAccumlated = rewardData.rewardRate * 30;

      const calculatedUserRewards = BN(
        totalUserBalance.toString()
      ).multipliedBy(
        BN(totalRewardsAccumlated.toString()).div(totalSupply.toString())
      );

      const userRewards = await loanStakingPool.getTotalUserRewards(
        user1.address
      );

      expect(userRewards[0].amount).to.equal(
        calculatedUserRewards.toFixed(0, 0).toString()
      );
    });

    it("Total stake count check", async function () {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");
      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const totalStake = await loanStakingPool.getStakeCount(user1.address);

      expect(totalStake).to.equal(2);
    });
  });

  describe("Recover testcases", () => {
    it("Recover Tokens other than Staking Token", async function () {
      await expect(
        loanStakingPool
          .connect(deployer)
          .recoverERC20(loanTokenAddress, transferAmount)
      ).to.be.revertedWith("Cannot withdraw staking token");
    });

    it("Recover tokens other than Reward Token", async function () {
      await rewardToken.transfer(loanStakingPool.address, transferAmount);

      await loanStakingPool
        .connect(deployer)
        .addReward(rewardToken.address, deployer.address);

      await expect(
        loanStakingPool
          .connect(deployer)
          .recoverERC20(rewardToken.address, transferAmount)
      ).to.be.revertedWith("Cannot withdraw reward token");
    });

    it("Recover tokens and transfer to owner", async function () {
      await rewardToken
        .connect(deployer)
        .transfer(loanStakingPool.address, transferAmount);

      const contractBalance: BigNumber = await rewardToken
        .connect(deployer)
        .balanceOf(loanStakingPool.address);

      const ownerPreviousBalance: BigNumber = await rewardToken
        .connect(deployer)
        .balanceOf(deployer.address);

      await loanStakingPool
        .connect(deployer)
        .recoverERC20(rewardToken.address, transferAmount);

      const ownerBalance: BigNumber = await rewardToken
        .connect(deployer)
        .balanceOf(deployer.address);

      expect(ownerPreviousBalance.add(contractBalance)).to.equal(ownerBalance);
    });
  });

  describe("TWAB tests", () => {
    context("getBalanceAt", () => {
      it("should return 0 for time before twabs", async () => {
        const lastTimestamp =
          (await waffle.provider.getBlock("latest")).timestamp + 1;
        await loanStakingPool.connect(user1).stake(1000, [], [], true);
        expect(
          await loanStakingPool.getBalanceAt(user1.address, lastTimestamp - 100)
        ).to.equal(0);
      });

      it("should return the current balance if time at or after last twab", async () => {
        const lastTimestamp =
          (await waffle.provider.getBlock("latest")).timestamp + 1;
        await loanStakingPool.connect(user1).stake(1000, [], [], true);
        await forward(1000);
        expect(
          await loanStakingPool.getBalanceAt(
            user1.address,
            lastTimestamp + 1000
          )
        ).to.equal("1000");
      });

      it("should return the current balance after the twab", async () => {
        const lastTimestamp =
          (await waffle.provider.getBlock("latest")).timestamp + 1;
        await loanStakingPool.connect(user1).stake(1000, [], [], true);
        expect(
          await loanStakingPool.getBalanceAt(
            user1.address,
            lastTimestamp + 1000
          )
        ).to.equal("1000");
      });
    });
  });

  describe("Sponser Testcases", () => {
    it("should get tickets when user stakes and has opted in Prize Pool", async () => {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");
      const ticketsBeforeStaking = await loanPrizePool.totalTicketNumber();
      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      await loanStakingPool
        .connect(user1)
        .stake(stakeAmount.mul(2), [], [], true);
      await loanStakingPool
        .connect(user1)
        .stake(stakeAmount.div(2), [], [], true);
      const ticketsAfterStaking = await loanPrizePool.totalTicketNumber();

      const { start, end } = await loanPrizePool.getRangeDetails(
        user1.address,
        0
      );
      expect(ticketsAfterStaking.sub(ticketsBeforeStaking)).to.be.equal(
        stakeAmount.add(stakeAmount.mul(2).add(stakeAmount.div(2)))
      );
      expect(start).to.be.equal(1);
      expect(end).to.be.equal(stakeAmount);
    });
    it("should update tickets when user unstakes", async () => {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");
      const unStakeAmount: BigNumber = ethers.utils.parseEther("1");

      const ticketsBeforeStaking = await loanPrizePool.totalTicketNumber();
      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const ticketAfterStaking = await loanPrizePool.totalTicketNumber();

      await loanStakingPool.connect(user1).unstake(unStakeAmount);

      const ticketAfterUnstaking = await loanPrizePool.totalTicketNumber();
      const { start, end } = await loanPrizePool.getRangeDetails(
        user1.address,
        0
      );

      expect(ticketAfterStaking.sub(ticketsBeforeStaking)).to.be.equal(
        stakeAmount
      );
      expect(ticketAfterStaking.sub(ticketAfterUnstaking)).to.be.equal(
        unStakeAmount
      );
      expect(start).to.be.equal(1);
      expect(end).to.be.equal(stakeAmount.sub(unStakeAmount));
    });
    it("should burn tickets when unstaking all amount", async () => {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");
      const unStakeAmount: BigNumber = ethers.utils.parseEther("10");
      const ticketsBeforeStaking = await loanPrizePool.totalTicketNumber();
      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      const ticketAfterStaking = await loanPrizePool.totalTicketNumber();
      await loanStakingPool.connect(user1).unstake(unStakeAmount);
      const ticketAfterUnstaking = await loanPrizePool.totalTicketNumber();
      expect(ticketAfterStaking.sub(ticketsBeforeStaking)).to.be.equal(
        stakeAmount
      );
      expect(ticketAfterUnstaking).to.be.equal(ticketsBeforeStaking);
    });
    it("should not get tickets when not opted for prizePool", async () => {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");
      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], false);
      expect(await loanPrizePool.totalTicketNumber()).to.be.equal(0);
    });
    it("should not change preference once staked", async () => {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");
      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      await expect(
        loanStakingPool.connect(user1).stake(stakeAmount, [], [], false)
      ).to.be.revertedWith("Cannot change PrizePool Preference.");
    });
    it("should be able to change preference after unstaking all funds", async () => {
      const stakeAmount: BigNumber = ethers.utils.parseEther("10");
      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      await expect(
        loanStakingPool.connect(user1).stake(stakeAmount, [], [], false)
      ).to.be.revertedWith("Cannot change PrizePool Preference.");
      await loanStakingPool.connect(user1).unstake(stakeAmount);
      expect(
        await loanStakingPool.connect(user1).stake(stakeAmount, [], [], false)
      ).to.be.ok;
    });
  });
});

describe("Early End Staking Penalty test", () => {
  beforeEach(async () => {
    const tokenSupply = 50000000000000;
    if (!abi) {
      [deployer, user1, buyAndBurn] = await ethers.getSigners();
      erc20Abi = await hre.artifacts.readArtifact(
        "@openzeppelin/contracts/token/ERC20/IERC20.sol:IERC20"
      );
      abi = await axios.get(
        `https://api.etherscan.io/api?module=contract&action=getabi&address=0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D&apikey=${process.env.ETHERSCAN_API_KEY}`
      );

      const path = [WPLSAddress, loanTokenAddress];

      await hre.network.provider.send("hardhat_setBalance", [
        deployer.address,
        "0x100000000000000000000",
      ]);

      routerInstance = new ethers.Contract(
        routerAddress,
        abi.data.result,
        deployer
      );
      const options = { value: ethers.utils.parseEther("1000000.0") };

      await routerInstance.swapExactETHForTokens(
        0,
        path,
        user1.address,
        "10000000000000",
        options
      );
      stakingTokenInstance = new ethers.Contract(
        loanTokenAddress,
        erc20Abi.abi,
        user1
      );
    }

    WinWin = await ethers.getContractFactory("WinToken");

    winToken = await WinWin.connect(deployer).deploy(tokenSupply);
    winToken.deployed();

    rewardToken = await WinWin.connect(deployer).deploy(tokenSupply);
    rewardToken.deployed();

    rewardToken2 = await WinWin.connect(deployer).deploy(tokenSupply);
    rewardToken2.deployed();

    StakingPool = await ethers.getContractFactory("YieldStakingPool", deployer);
    loanStakingPool = await StakingPool.deploy(loanTokenAddress);
    winStakingPool = await StakingPool.deploy(winToken.address);

    const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;

    PrizePool = await ethers.getContractFactory("PrizePool", deployer);
    const prizeDistribution = [6000, 900, 600, 300, 100, 2100];
    loanPrizePool = await PrizePool.deploy(
      lastTimestamp + 100,
      loanStakingPool.address,
      prizeDistribution
    );
    winPrizePool = await PrizePool.deploy(
      lastTimestamp + 100,
      loanStakingPool.address,
      prizeDistribution
    );

    await loanStakingPool.setPrizePoolAddress(loanPrizePool.address);

    LoanStrategy = await ethers.getContractFactory("LOANStrategy", deployer);
    const distributionAddress = [
      loanPrizePool.address,
      loanStakingPool.address,
      winPrizePool.address,
      winStakingPool.address,
      buyAndBurn.address,
    ];
    const distributionShares = [6000, 3000, 600, 300, 100];

    loanStrategy = await LoanStrategy.deploy(
      loanTokenAddress,
      USDLAddress,
      yieldSourceAddress,
      distributionAddress,
      distributionShares
    );

    await loanStakingPool.setPrizePoolAddress(loanPrizePool.address);

    await winStakingPool.setPrizePoolAddress(winPrizePool.address);

    await winPrizePool.addRewardToken(WPLSAddress);

    await loanPrizePool.addRewardToken(WPLSAddress);

    await loanStakingPool
      .connect(deployer)
      .modifyStrategyAddress(loanStrategy.address);

    transferAmount = BigNumber.from("100000000000000000000");
    rewardAmount = BigNumber.from("10000000000000000000");
    approvalAmount = BigNumber.from("100000000000000000000");

    await rewardToken
      .connect(deployer)
      .approve(loanStakingPool.address, approvalAmount);

    await rewardToken2
      .connect(deployer)
      .approve(loanStakingPool.address, approvalAmount);

    await stakingTokenInstance
      .connect(user1)
      .approve(loanStakingPool.address, approvalAmount);

    await loanStakingPool
      .connect(deployer)
      .addReward(rewardToken.address, deployer.address);

    await loanStakingPool
      .connect(deployer)
      .addReward(rewardToken2.address, deployer.address);

    await loanStakingPool
      .connect(deployer)
      .notifyRewardAmount(rewardToken.address, rewardAmount);

    await loanStakingPool
      .connect(deployer)
      .notifyRewardAmount(rewardToken2.address, rewardAmount);
  });

  it("If user has staked tokens it will be locked and lock will apply on individual stakes", async () => {
    const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
    const lockDuration: number = await loanStakingPool.LOCK_DURATION();
    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    expect(await loanStakingPool.getWithdrawableShares(user1.address)).to.equal(
      0
    );

    // forwarding 40 seconds

    await forward(40);

    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    expect(await loanStakingPool.getWithdrawableShares(user1.address)).to.equal(
      0
    );

    // again forwarding (lockDuration-40) seconds
    await forward(lockDuration - 40);

    expect(await loanStakingPool.getWithdrawableShares(user1.address)).to.equal(
      stakeAmount
    );
  });

  it("If user withdraws before unlock period , penalty will be applied", async () => {
    const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");

    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    // forward 5 seconds

    await forward(5);

    // Rewards in 5 seconds

    let rewardToken1Data = await loanStakingPool.getRewardData(
      rewardToken.address
    );
    let rewardToken2Data = await loanStakingPool.getRewardData(
      rewardToken2.address
    );

    const toalRewards1 = rewardToken1Data.rewardRate.mul(5);

    const toalRewards2 = rewardToken2Data.rewardRate.mul(5);

    const rewards = await loanStakingPool.getTotalUserRewards(user1.address);

    expect(rewards[0].amount).to.equal(toalRewards1);

    expect(rewards[1].amount).to.equal(toalRewards2);

    const deadAddressRewardToken1Balance = await rewardToken.balanceOf(
      "0x000000000000000000000000000000000000dEaD"
    );

    const deadAddressRewardToken2Balance = await rewardToken2.balanceOf(
      "0x000000000000000000000000000000000000dEaD"
    );

    const winTokenBalance = await stakingTokenInstance.balanceOf(user1.address);

    await loanStakingPool.connect(user1).unstake(stakeAmount);
    const currentWinTokenBalance = await stakingTokenInstance.balanceOf(
      user1.address
    );

    expect(currentWinTokenBalance.sub(winTokenBalance)).to.equal(stakeAmount);

    const currentDeadAddressRewardToken1Balance = await rewardToken.balanceOf(
      "0x000000000000000000000000000000000000dEaD"
    );

    const currentDeadAddressRewardToken2Balance = await rewardToken2.balanceOf(
      "0x000000000000000000000000000000000000dEaD"
    );

    const deadAddressPart1 = BN(
      toalRewards1.add(rewardToken1Data.rewardRate).toString()
    );

    const deadAddressPart2 = BN(
      toalRewards2.add(rewardToken2Data.rewardRate).toString()
    );

    expect(
      currentDeadAddressRewardToken1Balance
        .sub(deadAddressRewardToken1Balance)
        .toString()
    ).to.equal(deadAddressPart1.div(2).toString());

    expect(
      currentDeadAddressRewardToken2Balance
        .sub(deadAddressRewardToken2Balance)
        .toString()
    ).to.equal(deadAddressPart2.div(2).toString());

    const rewardDuration = await loanStakingPool.REWARDS_DURATION();

    const leftTime1 = BN((rewardDuration - 8).toString());
    const leftTime2 = BN((rewardDuration - 7).toString());

    const totalLeftReward1 = leftTime1.multipliedBy(
      BN(rewardToken1Data.rewardRate.toString())
    );

    const totalLeftReward2 = leftTime2.multipliedBy(
      BN(rewardToken2Data.rewardRate.toString())
    );

    const totalRewards1 = totalLeftReward1.plus(deadAddressPart1.div(2));

    const totalRewards2 = totalLeftReward2.plus(deadAddressPart2.div(2));

    const newRewardRate1 = totalRewards1.div(BN(rewardDuration.toString()));

    const newRewardRate2 = totalRewards2.div(BN(rewardDuration.toString()));

    rewardToken1Data = await loanStakingPool.getRewardData(rewardToken.address);
    rewardToken2Data = await loanStakingPool.getRewardData(
      rewardToken2.address
    );

    expect(newRewardRate1.toString()).to.equal(
      rewardToken1Data.rewardRate.toString()
    );

    expect(newRewardRate2.toString()).to.equal(
      rewardToken2Data.rewardRate.toString()
    );
  });

  it("if user withdraws some portion then that penalty on that portion will be applied", async () => {
    const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");

    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    // forward 5 seconds

    await forward(5);

    // Rewards in 5 seconds

    let rewardToken1Data = await loanStakingPool.getRewardData(
      rewardToken.address
    );
    let rewardToken2Data = await loanStakingPool.getRewardData(
      rewardToken2.address
    );

    const toalRewards1 = rewardToken1Data.rewardRate.mul(5);

    const toalRewards2 = rewardToken2Data.rewardRate.mul(5);

    const rewards = await loanStakingPool.getTotalUserRewards(user1.address);

    expect(rewards[0].amount).to.equal(toalRewards1);

    expect(rewards[1].amount).to.equal(toalRewards2);

    const deadAddressRewardToken1Balance = await rewardToken.balanceOf(
      "0x000000000000000000000000000000000000dEaD"
    );

    const deadAddressRewardToken2Balance = await rewardToken2.balanceOf(
      "0x000000000000000000000000000000000000dEaD"
    );

    const winTokenBalance = await stakingTokenInstance.balanceOf(user1.address);

    const unstakeAmount: BigNumber = BigNumber.from("5000000000000000000");

    await loanStakingPool.connect(user1).unstake(unstakeAmount);
    const currentWinTokenBalance = await stakingTokenInstance.balanceOf(
      user1.address
    );

    expect(currentWinTokenBalance.sub(winTokenBalance)).to.equal(unstakeAmount);

    const currentDeadAddressRewardToken1Balance = await rewardToken.balanceOf(
      "0x000000000000000000000000000000000000dEaD"
    );

    const currentDeadAddressRewardToken2Balance = await rewardToken2.balanceOf(
      "0x000000000000000000000000000000000000dEaD"
    );

    const deadAddressPart1 = BN(
      toalRewards1.add(rewardToken1Data.rewardRate).toString()
    );

    const deadAddressPart2 = BN(
      toalRewards2.add(rewardToken2Data.rewardRate).toString()
    );

    expect(
      currentDeadAddressRewardToken1Balance
        .sub(deadAddressRewardToken1Balance)
        .toString()
    ).to.equal(deadAddressPart1.div(4).toString());

    expect(
      currentDeadAddressRewardToken2Balance
        .sub(deadAddressRewardToken2Balance)
        .toString()
    ).to.equal(deadAddressPart2.div(4).toString());

    const rewardDuration = await loanStakingPool.REWARDS_DURATION();

    const leftTime1 = BN((rewardDuration - 8).toString());
    const leftTime2 = BN((rewardDuration - 7).toString());

    const totalLeftReward1 = leftTime1.multipliedBy(
      BN(rewardToken1Data.rewardRate.toString())
    );

    const totalLeftReward2 = leftTime2.multipliedBy(
      BN(rewardToken2Data.rewardRate.toString())
    );

    const totalRewards1 = totalLeftReward1.plus(deadAddressPart1.div(4));

    const totalRewards2 = totalLeftReward2.plus(deadAddressPart2.div(4));

    const newRewardRate1 = totalRewards1.div(BN(rewardDuration.toString()));

    const newRewardRate2 = totalRewards2.div(BN(rewardDuration.toString()));

    rewardToken1Data = await loanStakingPool.getRewardData(rewardToken.address);
    rewardToken2Data = await loanStakingPool.getRewardData(
      rewardToken2.address
    );

    expect(newRewardRate1.toString()).to.equal(
      rewardToken1Data.rewardRate.toString()
    );

    expect(newRewardRate2.toString()).to.equal(
      rewardToken2Data.rewardRate.toString()
    );
  });

  it("Claim function claims rewards of unlocked stakes only", async () => {
    const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
    const lockDuration: number = await loanStakingPool.LOCK_DURATION();

    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    // forward 20 seconds

    await forward(20);

    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    // calculate rewards for stake 1 => 20 + 1 second consumed in staking again
    const rewardToken1Data = await loanStakingPool.getRewardData(
      rewardToken.address
    );
    const rewardToken2Data = await loanStakingPool.getRewardData(
      rewardToken2.address
    );

    let totalRewards1 = rewardToken1Data.rewardRate.mul(21);

    let totalRewards2 = rewardToken2Data.rewardRate.mul(21);

    // forward 20 seconds

    await forward(20);

    let rewards = await loanStakingPool.getClaimableRewards(user1.address);

    expect(rewards[0].amount).to.equal(0);

    expect(rewards[1].amount).to.equal(0);

    await forward(lockDuration - 41);

    // divinding by 2 as in this duration there are two stake each of same share

    totalRewards1 = totalRewards1.add(
      rewardToken1Data.rewardRate.mul(lockDuration - 21).div(2)
    );

    totalRewards2 = totalRewards2.add(
      rewardToken2Data.rewardRate.mul(lockDuration - 21).div(2)
    );

    rewards = await loanStakingPool.getClaimableRewards(user1.address);

    expect(rewards[0].amount).to.equal(totalRewards1);

    expect(rewards[1].amount).to.equal(totalRewards2);

    // as claim will take 1 more second

    // (rewards in 1 second / 2)  as two stakes are there of equal shares

    totalRewards1 = totalRewards1.add(rewardToken1Data.rewardRate.div(2));

    totalRewards2 = totalRewards2.add(rewardToken2Data.rewardRate.div(2));

    const reward1Balance = await rewardToken.balanceOf(user1.address);
    const reward2Balance = await rewardToken2.balanceOf(user1.address);

    await loanStakingPool.connect(user1).claim(user1.address);

    const currentReward1Balance = await rewardToken.balanceOf(user1.address);
    const currentReward2Balance = await rewardToken2.balanceOf(user1.address);

    expect(currentReward1Balance.sub(reward1Balance)).to.equal(totalRewards1);

    expect(currentReward2Balance.sub(reward2Balance)).to.equal(totalRewards2);

    const rewardsForSecondStake = await loanStakingPool.getTotalUserRewards(
      user1.address
    );

    // Rewards for 2'nd stake

    // 20 second forward + (lockDuration - 41) second forward + 1 second for claim

    const totalDurationOfStake = lockDuration - 20;

    const totalRewards1OfStake2 = rewardToken1Data.rewardRate
      .mul(totalDurationOfStake)
      .div(2);

    const totalRewards2OfStake2 = rewardToken2Data.rewardRate
      .mul(totalDurationOfStake)
      .div(2);

    expect(rewardsForSecondStake[0].amount).to.equal(totalRewards1OfStake2);

    expect(rewardsForSecondStake[1].amount).to.equal(totalRewards2OfStake2);
  });
  it("User can claim the rewards on the behalf of another user.", async () => {
    const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
    const lockDuration: number = await loanStakingPool.LOCK_DURATION();

    const callerBalanceBefore = await rewardToken.balanceOf(deployer.address);

    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    // forward 20 seconds

    await forward(20);

    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    // calculate rewards for stake 1 => 20 + 1 second consumed in staking again
    const rewardToken1Data = await loanStakingPool.getRewardData(
      rewardToken.address
    );
    const rewardToken2Data = await loanStakingPool.getRewardData(
      rewardToken2.address
    );

    let totalRewards1 = rewardToken1Data.rewardRate.mul(21);

    let totalRewards2 = rewardToken2Data.rewardRate.mul(21);

    // forward 20 seconds

    await forward(20);

    let rewards = await loanStakingPool.getClaimableRewards(user1.address);

    expect(rewards[0].amount).to.equal(0);

    expect(rewards[1].amount).to.equal(0);

    await forward(lockDuration - 41);

    // divinding by 2 as in this duration there are two stake each of same share

    totalRewards1 = totalRewards1.add(
      rewardToken1Data.rewardRate.mul(lockDuration - 21).div(2)
    );

    totalRewards2 = totalRewards2.add(
      rewardToken2Data.rewardRate.mul(lockDuration - 21).div(2)
    );

    rewards = await loanStakingPool.getClaimableRewards(user1.address);

    expect(rewards[0].amount).to.equal(totalRewards1);

    expect(rewards[1].amount).to.equal(totalRewards2);

    // as claim will take 1 more second

    // (rewards in 1 second / 2)  as two stakes are there of equal shares

    totalRewards1 = totalRewards1.add(rewardToken1Data.rewardRate.div(2));

    totalRewards2 = totalRewards2.add(rewardToken2Data.rewardRate.div(2));

    const reward1Balance = await rewardToken.balanceOf(user1.address);
    const reward2Balance = await rewardToken2.balanceOf(user1.address);

    await loanStakingPool.connect(deployer).claim(user1.address);

    const currentReward1Balance = await rewardToken.balanceOf(user1.address);
    const currentReward2Balance = await rewardToken2.balanceOf(user1.address);
    const callerBalanceAfter = await rewardToken.balanceOf(deployer.address);

    expect(currentReward1Balance.sub(reward1Balance)).to.equal(totalRewards1);

    expect(currentReward2Balance.sub(reward2Balance)).to.equal(totalRewards2);

    expect(callerBalanceAfter).to.equal(callerBalanceBefore);
  });

  it("user unstakes some unlocked and some locked stakes ", async () => {
    const stakeAmount1: BigNumber = BigNumber.from("10000000000000000000");
    const lockDuration: number = await loanStakingPool.LOCK_DURATION();

    await loanStakingPool.connect(user1).stake(stakeAmount1, [], [], true);

    // forward 20 seconds

    await forward(20);

    const stakeAmount2: BigNumber = BigNumber.from("20000000000000000000");

    await loanStakingPool.connect(user1).stake(stakeAmount2, [], [], true);

    // forward 20 seconds
    await forward(20);

    const stakeAmount3: BigNumber = BigNumber.from("15000000000000000000");

    await loanStakingPool.connect(user1).stake(stakeAmount3, [], [], true);

    // unlocking  only first stake by forwarding
    await forward(lockDuration - 42);
    const rewardToken1Data = await loanStakingPool.getRewardData(
      rewardToken.address
    );

    const totalSupply = await loanStakingPool.totalSupply();

    const firstPeriod = rewardToken1Data.rewardRate.mul(21);

    const secondPeriod = rewardToken1Data.rewardRate
      .mul(21)
      .mul(stakeAmount1)
      .div(stakeAmount1.add(stakeAmount2));

    // adding 1 more second for unstake function
    const thirdPeriod = rewardToken1Data.rewardRate
      .mul(59)
      .mul(stakeAmount1)
      .div(totalSupply);

    const totalRewardsForFirstStake = firstPeriod
      .add(secondPeriod)
      .add(thirdPeriod);

    const secondPeriodForSecondStake = rewardToken1Data.rewardRate
      .mul(21)
      .mul(stakeAmount2)
      .div(stakeAmount1.add(stakeAmount2));

    // adding 1 more second for unstake function
    const thirdPeriodForSecondStake = rewardToken1Data.rewardRate
      .mul(59)
      .mul(stakeAmount2)
      .div(totalSupply);

    const totalRewardsForSecondStake = secondPeriodForSecondStake.add(
      thirdPeriodForSecondStake
    );

    // adding 1 more second for unstake function
    const totalRewardsForThirdStake = rewardToken1Data.rewardRate
      .mul(59)
      .mul(stakeAmount3)
      .div(totalSupply);

    const unstakeAmount: BigNumber = BigNumber.from("35000000000000000000");

    const winBalance = await stakingTokenInstance.balanceOf(user1.address);
    const reward1Balance = await rewardToken.balanceOf(user1.address);
    const reward2Balance = await rewardToken2.balanceOf(user1.address);
    const deadAddressRewardToken1Balance = await rewardToken.balanceOf(
      "0x000000000000000000000000000000000000dEaD"
    );

    const deadAddressRewardToken2Balance = await rewardToken2.balanceOf(
      "0x000000000000000000000000000000000000dEaD"
    );

    await loanStakingPool.connect(user1).unstake(unstakeAmount);

    const currentWinBalance = await stakingTokenInstance.balanceOf(
      user1.address
    );
    const currentReward1Balance = await rewardToken.balanceOf(user1.address);
    const currentReward2Balance = await rewardToken2.balanceOf(user1.address);
    const currentDeadAddressRewardToken1Balance = await rewardToken.balanceOf(
      "0x000000000000000000000000000000000000dEaD"
    );

    const currentDeadAddressRewardToken2Balance = await rewardToken2.balanceOf(
      "0x000000000000000000000000000000000000dEaD"
    );

    expect(currentWinBalance.sub(winBalance)).to.equal(unstakeAmount);

    const portionOfThirdStake = BN(
      BigNumber.from("5000000000000000000").toString()
    ).div(BN(stakeAmount3.toString()));

    const penalty = BN(totalRewardsForSecondStake.toString()).plus(
      BN(totalRewardsForThirdStake.toString()).multipliedBy(portionOfThirdStake)
    );

    // for Precision substracting 2 (18 decimal position)

    expect(currentReward1Balance.sub(reward1Balance)).to.equal(
      totalRewardsForFirstStake
    );

    expect(currentReward2Balance.sub(reward2Balance)).to.equal(
      totalRewardsForFirstStake
    );

    // For precision subtracting 2 (18th decimal position)
    expect(
      currentDeadAddressRewardToken2Balance
        .sub(deadAddressRewardToken2Balance)
        .toString()
    ).to.equal(penalty.minus(2).div(2).toFixed(0, 0).toString());

    expect(
      currentDeadAddressRewardToken1Balance
        .sub(deadAddressRewardToken1Balance)
        .toString()
    ).to.equal(penalty.minus(2).div(2).toFixed(0, 0).toString());
  });

  it("Unlocked Rewards to be same as claimable rewards after unlock period", async function () {
    const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    // Unlock Rewards Before Duration Completes
    const unlockRewardBefore = await loanStakingPool.getClaimableRewards(
      user1.address
    );

    expect(unlockRewardBefore[1].amount).to.equal(0);

    await forward(220);

    const totalRewards = await loanStakingPool.getTotalUserRewards(
      user1.address
    );

    const unlockReward = await loanStakingPool.getClaimableRewards(
      user1.address
    );

    // After Lock duration completes, all unclocked rewards to be same as claimable rewards
    expect(totalRewards.amount).to.equal(unlockReward.amount);

    const rewardTokenBalance = await rewardToken.balanceOf(user1.address);

    const rewardToken2Balance = await rewardToken2.balanceOf(user1.address);

    // user claims the reward tokens
    await loanStakingPool.connect(user1).claim(user1.address);

    const currentRewardTokenBalance = await rewardToken.balanceOf(
      user1.address
    );

    const currentRewardToken2Balance = await rewardToken2.balanceOf(
      user1.address
    );

    expect(currentRewardTokenBalance.sub(rewardTokenBalance)).to.equal(
      totalRewards[0].amount
    );

    expect(currentRewardToken2Balance.sub(rewardToken2Balance)).to.equal(
      totalRewards[1].amount
    );

    const claimedAmount = await loanStakingPool.getTotalUserRewards(
      user1.address
    );

    expect(claimedAmount[1].amount).to.equal(0);
  });

  it("Stake tokens, Calculate total reward & compare with total claimable rewards", async function () {
    const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");

    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    await forward(210);

    const firstStakeDetail = await loanStakingPool.getBalance(
      user1.address,
      0,
      rewardToken.address
    );

    const secondStakeDetail = await loanStakingPool.getBalance(
      user1.address,
      1,
      rewardToken.address
    );

    const rewardPerToken = await loanStakingPool.rewardPerToken(
      rewardToken.address
    );

    const firstStakeRewardsEarned = BN(
      firstStakeDetail._stakedAmount.toString()
    )
      .multipliedBy(
        BN(
          rewardPerToken
            .sub(firstStakeDetail._userRewardPerTokenPaid)
            .toString()
        )
      )
      .div(BN("10000000000000000000000"))
      .plus(BN(firstStakeDetail._rewardAmount.toString()));
    const secondStakeRewardsEarned = BN(
      secondStakeDetail._stakedAmount.toString()
    )
      .multipliedBy(
        BN(
          rewardPerToken
            .sub(secondStakeDetail._userRewardPerTokenPaid)
            .toString()
        )
      )
      .div(BN("10000000000000000000000"))
      .plus(BN(secondStakeDetail._rewardAmount.toString()));

    const totalRewards = await loanStakingPool.getTotalUserRewards(
      user1.address
    );

    expect(
      firstStakeRewardsEarned.plus(secondStakeRewardsEarned).toString()
    ).to.equal(totalRewards[0].amount);
  });

  it("Stake & unstake and calculate change in reward rate", async function () {
    const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    const rewardData = await loanStakingPool.getRewardData(rewardToken.address);

    // 50 seconds forwarding
    await forward(50);

    // Reward Earned for 51 seconds => 50 + 1second (for unstake)
    const totalRewards = rewardData.rewardRate.mul(51);

    const reward1Balance = await rewardToken.balanceOf(user1.address);

    const reward2Balance = await rewardToken2.balanceOf(user1.address);

    const burnAddressReward = await rewardToken.balanceOf(
      "0x000000000000000000000000000000000000dEaD"
    );

    await loanStakingPool.connect(user1).unstake(stakeAmount);

    const currentBurnAddressReward = await rewardToken.balanceOf(
      "0x000000000000000000000000000000000000dEaD"
    );

    const currentReward1Balance = await rewardToken.balanceOf(user1.address);

    const currentReward2Balance = await rewardToken2.balanceOf(user1.address);

    expect(currentReward1Balance.sub(reward1Balance)).to.equal(0);

    expect(currentReward2Balance.sub(reward2Balance)).to.equal(0);

    expect(currentBurnAddressReward.sub(burnAddressReward)).to.equal(
      totalRewards.div(2)
    );

    const currentRewardData = await loanStakingPool.getRewardData(
      rewardToken.address
    );

    const remainingReward = totalRewards.div(2);

    const rewardDuration = await loanStakingPool.REWARDS_DURATION();

    const leftTime1 = BigNumber.from(rewardDuration - 53);

    // Now to set new reward Rate with remaining Reward
    const leftOver = leftTime1.mul(rewardData.rewardRate);
    const finalRewardRate = leftOver.add(remainingReward).div(rewardDuration);

    expect(finalRewardRate).to.equal(currentRewardData.rewardRate);
  });

  it("calculatePenalties function test when all stakes are unlocked", async () => {
    const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
    const lockDuration: number = await loanStakingPool.LOCK_DURATION();
    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    expect(await loanStakingPool.getWithdrawableShares(user1.address)).to.equal(
      0
    );

    // forwarding 40 seconds

    await forward(40);

    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    expect(await loanStakingPool.getWithdrawableShares(user1.address)).to.equal(
      0
    );

    // again forwarding (lockDuration-40) seconds
    await forward(Number(lockDuration));

    const totalUserRewards = await loanStakingPool.getTotalUserRewards(
      user1.address
    );

    const totalClaimableRewards = await loanStakingPool.getClaimableRewards(
      user1.address
    );

    const calculatePenalties = await loanStakingPool.calculatePenalties(
      user1.address,
      stakeAmount.mul(2)
    );

    expect(totalUserRewards[0].amount).to.equal(
      totalClaimableRewards[0].amount
    );

    expect(totalUserRewards[1].amount).to.equal(
      totalClaimableRewards[1].amount
    );

    expect(0).to.equal(calculatePenalties._totalPenaltyRewards[0]);

    expect(0).to.equal(calculatePenalties._totalPenaltyRewards[1]);

    expect(totalClaimableRewards[0].amount).to.equal(
      calculatePenalties._totalClaimableRewards[0]
    );

    expect(totalClaimableRewards[1].amount).to.equal(
      calculatePenalties._totalClaimableRewards[1]
    );

    expect(0).to.equal(calculatePenalties._penalizedAmount);
  });

  it("calculatePenalties function test when all stakes are locked", async () => {
    const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");

    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    expect(await loanStakingPool.getWithdrawableShares(user1.address)).to.equal(
      0
    );

    // forwarding 40 seconds

    await forward(40);

    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    expect(await loanStakingPool.getWithdrawableShares(user1.address)).to.equal(
      0
    );

    const totalUserRewards = await loanStakingPool.getTotalUserRewards(
      user1.address
    );

    const calculatePenalties = await loanStakingPool.calculatePenalties(
      user1.address,
      stakeAmount.mul(2)
    );

    expect(0).to.equal(calculatePenalties._totalClaimableRewards[0]);

    expect(0).to.equal(calculatePenalties._totalClaimableRewards[1]);

    expect(totalUserRewards[0].amount).to.equal(
      calculatePenalties._totalPenaltyRewards[0]
    );

    expect(totalUserRewards[1].amount).to.equal(
      calculatePenalties._totalPenaltyRewards[1]
    );

    expect(stakeAmount.mul(2)).to.equal(calculatePenalties._penalizedAmount);
  });

  it("calculatePenalties when some stakes are locked and some are unlocked", async () => {
    const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
    const lockDuration: number = await loanStakingPool.LOCK_DURATION();
    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    expect(await loanStakingPool.getWithdrawableShares(user1.address)).to.equal(
      0
    );

    // forwarding 40 seconds

    await forward(40);

    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    expect(await loanStakingPool.getWithdrawableShares(user1.address)).to.equal(
      0
    );

    // again forwarding (lockDuration-40) seconds
    await forward(lockDuration - 40);

    const totalUserRewards = await loanStakingPool.getTotalUserRewards(
      user1.address
    );

    const totalClaimableRewards = await loanStakingPool.getClaimableRewards(
      user1.address
    );

    const calculatePenalties = await loanStakingPool.calculatePenalties(
      user1.address,
      stakeAmount.mul(2)
    );

    expect(
      totalUserRewards[0].amount.sub(totalClaimableRewards[0].amount)
    ).to.equal(calculatePenalties._totalPenaltyRewards[0]);

    expect(
      totalUserRewards[1].amount.sub(totalClaimableRewards[1].amount)
    ).to.equal(calculatePenalties._totalPenaltyRewards[1]);

    expect(totalClaimableRewards[0].amount).to.equal(
      calculatePenalties._totalClaimableRewards[0]
    );

    expect(totalClaimableRewards[1].amount).to.equal(
      calculatePenalties._totalClaimableRewards[1]
    );

    expect(stakeAmount).to.equal(calculatePenalties._penalizedAmount);
  });

  it("calculatePenalties when some stakes are locked and some are unlocked with partial withdraw", async () => {
    const stakeAmount: BigNumber = BigNumber.from("10000000000000000000");
    const lockDuration: number = await loanStakingPool.LOCK_DURATION();
    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    expect(await loanStakingPool.getWithdrawableShares(user1.address)).to.equal(
      0
    );

    // forwarding 40 seconds

    await forward(40);

    await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

    expect(await loanStakingPool.getWithdrawableShares(user1.address)).to.equal(
      0
    );

    // again forwarding (lockDuration-40) seconds
    await forward(lockDuration - 40);

    const totalUserRewards = await loanStakingPool.getTotalUserRewards(
      user1.address
    );

    const totalClaimableRewards = await loanStakingPool.getClaimableRewards(
      user1.address
    );

    const calculatePenalties = await loanStakingPool.calculatePenalties(
      user1.address,
      stakeAmount.add(stakeAmount.div(2))
    );

    expect(
      totalUserRewards[0].amount.sub(totalClaimableRewards[0].amount).div(2)
    ).to.equal(calculatePenalties._totalPenaltyRewards[0]);

    expect(
      totalUserRewards[1].amount.sub(totalClaimableRewards[1].amount).div(2)
    ).to.equal(calculatePenalties._totalPenaltyRewards[1]);

    expect(totalClaimableRewards[0].amount).to.equal(
      calculatePenalties._totalClaimableRewards[0]
    );

    expect(totalClaimableRewards[1].amount).to.equal(
      calculatePenalties._totalClaimableRewards[1]
    );

    expect(stakeAmount.div(2)).to.equal(calculatePenalties._penalizedAmount);
  });
});
