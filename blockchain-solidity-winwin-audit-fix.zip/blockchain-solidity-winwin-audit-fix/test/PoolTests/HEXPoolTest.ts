import { expect } from "chai";
import hre, { ethers, waffle } from "hardhat";
import { BigNumber, Contract, ContractFactory } from "ethers";
import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import { BigNumber as BN } from "bignumber.js";
import axios from "axios";

BN.config({ ROUNDING_MODE: BN.ROUND_DOWN });

async function forward(seconds: any) {
  const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;
  await waffle.provider.send("evm_setNextBlockTimestamp", [
    lastTimestamp + seconds,
  ]);
  await waffle.provider.send("evm_mine", []);
}

let deployer: SignerWithAddress;
let user1: SignerWithAddress;
let user2: SignerWithAddress;
let buyAndBurn: SignerWithAddress;
let abi: any;
let erc20Abi: any;
let WinWin: ContractFactory;
let winToken: Contract;
let WinStakingPool: ContractFactory;
let winStakingPool: Contract;
let HexStakingPool: ContractFactory;
let hexStakingPool: Contract;
let HexStrategy: ContractFactory;
let hexStrategy: Contract;
let PrizePool: ContractFactory;
let winPrizePool: Contract;
let hexPrizePool: Contract;
let rewardToken: Contract;
let rewardToken2: Contract;
let approvalAmount: BigNumber;
let rewardAmount: BigNumber;
let tokenSupply: BigNumber;
let stakeAmount: BigNumber;
const HEXTokenAddress = "0x2b591e99afE9f32eAA6214f7B7629768c40Eeb39";
const routerAddress = "0x98bf93ebf5c380C0e6Ae8e192A7e2AE08edAcc02";
const WPLSAddress = "0xA1077a294dDE1B09bB078844df40758a5D0f9a27";
let routerInstance: any;
let hexTokenInstance: any;

describe("HEX Pool Test Cases", () => {
  beforeEach(async () => {
    if (!abi) {
      [deployer, user1, user2, buyAndBurn] = await ethers.getSigners();
      erc20Abi = await hre.artifacts.readArtifact(
        "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol:IERC20Metadata"
      );
      abi = await axios.get(
        `https://api.etherscan.io/api?module=contract&action=getabi&address=0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D&apikey=${process.env.ETHERSCAN_API_KEY}`
      );

      const path = [WPLSAddress, HEXTokenAddress];

      await hre.network.provider.send("hardhat_setBalance", [
        deployer.address,
        "0x10000000000000000000000",
      ]);

      routerInstance = new ethers.Contract(
        routerAddress,
        abi.data.result,
        deployer
      );
      const options = { value: ethers.utils.parseEther("10000000.0") };

      await routerInstance.swapExactETHForTokens(
        0,
        path,
        user1.address,
        "10000000000000",
        options
      );
      hexTokenInstance = new ethers.Contract(
        HEXTokenAddress,
        erc20Abi.abi,
        user1
      );
      await routerInstance.swapExactETHForTokens(
        0,
        path,
        deployer.address,
        "10000000000000",
        options
      );
    }

    tokenSupply = BigNumber.from("1000000000000000");
    WinWin = await ethers.getContractFactory("WinToken", deployer);
    winToken = await WinWin.deploy(tokenSupply);
    winToken.deployed();

    const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;

    WinStakingPool = await ethers.getContractFactory(
      "WinStakingPool",
      deployer
    );

    const block = await hre.ethers.provider.getBlock("latest");

    winStakingPool = await WinStakingPool.deploy(
      winToken.address,
      block.timestamp,
      "10000000000"
    );
    winStakingPool.deployed();

    HexStakingPool = await ethers.getContractFactory(
      "HexStakingPool",
      deployer
    );
    hexStakingPool = await HexStakingPool.deploy(HEXTokenAddress);

    PrizePool = await ethers.getContractFactory("PrizePool", deployer);

    const prizeDistribution = [6000, 900, 600, 300, 100, 2100];

    hexPrizePool = await PrizePool.deploy(
      lastTimestamp + 100,
      hexStakingPool.address,
      prizeDistribution
    );

    winPrizePool = await PrizePool.deploy(
      lastTimestamp + 100,
      winStakingPool.address,
      prizeDistribution
    );

    await hexStakingPool.setPrizePoolAddress(hexPrizePool.address);

    await winStakingPool.setPrizePoolAddress(winPrizePool.address);

    await winPrizePool.addRewardToken(hexTokenInstance.address);

    await hexPrizePool.addRewardToken(hexTokenInstance.address);

    HexStrategy = await ethers.getContractFactory("HEXStrategy", deployer);
    const distributionAddress = [
      hexPrizePool.address,
      hexStakingPool.address,
      winPrizePool.address,
      winStakingPool.address,
      buyAndBurn.address,
    ];

    const distributionShares = [6000, 3000, 600, 300, 100];
    hexStrategy = await HexStrategy.deploy(
      HEXTokenAddress,
      distributionAddress,
      distributionShares
    );

    await hexStakingPool
      .connect(deployer)
      .modifyStrategyAddress(hexStrategy.address);

    rewardToken = await WinWin.connect(deployer).deploy("500000000000000000");
    rewardToken.deployed();

    rewardToken2 = await WinWin.connect(deployer).deploy("500000000000000000");
    rewardToken2.deployed();

    await hexTokenInstance
      .connect(user1)
      .approve(hexStakingPool.address, "10000000000000");

    await hexTokenInstance
      .connect(user1)
      .approve(hexStrategy.address, "100000000000000000");

    rewardAmount = BigNumber.from("10000000000");
    stakeAmount = ethers.utils.parseEther("100");
    approvalAmount = BigNumber.from("1000000000000000000000000000000000000");

    await hexTokenInstance
      .connect(deployer)
      .transfer(user2.address, "10000000000");

    await hexTokenInstance
      .connect(user2)
      .approve(hexStakingPool.address, approvalAmount);

    await hexTokenInstance
      .connect(deployer)
      .approve(hexStakingPool.address, approvalAmount);

    await hexTokenInstance
      .connect(deployer)
      .approve(hexStakingPool.address, approvalAmount);

    await rewardToken
      .connect(deployer)
      .approve(hexStakingPool.address, approvalAmount);

    await rewardToken2
      .connect(deployer)
      .approve(hexStakingPool.address, approvalAmount);

    await hexStakingPool
      .connect(deployer)
      .addReward(rewardToken.address, deployer.address);

    await hexStakingPool
      .connect(deployer)
      .approveRewardDistributor(
        hexTokenInstance.address,
        deployer.address,
        true
      );

    await hexStakingPool
      .connect(deployer)
      .notifyRewardAmount(hexTokenInstance.address, rewardAmount);

    await hexStakingPool
      .connect(deployer)
      .notifyRewardAmount(rewardToken.address, rewardAmount);
  });

  describe("Admin and Reward testcase", () => {
    it("Only Owner should be allowed to approve Reward Token ", async function () {
      await expect(
        hexStakingPool
          .connect(user1)
          .approveRewardDistributor(rewardToken.address, user1.address, true)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Only Owner should be allowed to add Reward Token ", async function () {
      await expect(
        hexStakingPool
          .connect(user1)
          .addReward(rewardToken.address, user1.address)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Hex is the first reward token", async function () {
      const rewardTokens = await hexStakingPool.getRewardTokens();
      expect(rewardTokens.length).to.equal(2);
      expect(rewardTokens[0]).to.equal(HEXTokenAddress);
    });

    it("Can't add HEX as reward token. It is added by default", async function () {
      await expect(
        hexStakingPool
          .connect(deployer)
          .addReward(HEXTokenAddress, user1.address)
      ).to.be.revertedWith("Reward Token already added");
    });

    it("Add a new Reward Token", async function () {
      let rewardData = await hexStakingPool.getRewardData(rewardToken2.address);
      let rewardTokens = await hexStakingPool.getRewardTokens();

      expect(rewardData.lastUpdateTime).to.equal(0);
      expect(rewardTokens.length).to.equal(2);

      await hexStakingPool
        .connect(deployer)
        .addReward(rewardToken2.address, user1.address);

      rewardTokens = await hexStakingPool.getRewardTokens();

      rewardData = await hexStakingPool.getRewardData(rewardToken2.address);

      expect(rewardData.lastUpdateTime).to.not.equal(0);
      expect(rewardTokens.length).to.equal(3);
    });

    it("Same Reward token cannot be added twice ", async function () {
      await expect(
        hexStakingPool
          .connect(deployer)
          .addReward(rewardToken.address, deployer.address)
      ).to.be.revertedWith("Reward Token already added");
    });

    it("Only approved caller can set reward rate", async function () {
      const approval = await hexStakingPool.rewardDistributors(
        rewardToken.address,
        user1.address
      );

      expect(approval).to.equal(false);

      await expect(
        hexStakingPool
          .connect(user1)
          .notifyRewardAmount(rewardToken.address, stakeAmount)
      ).to.be.revertedWith("User not Approved");
    });

    it("Reward Token Amount is zero", async function () {
      await expect(
        hexStakingPool
          .connect(deployer)
          .notifyRewardAmount(rewardToken.address, 0)
      ).to.be.revertedWith("No reward");
    });

    it("Calculate and check Reward Rate", async function () {
      const rewardAmount: BigNumber = BigNumber.from("1000000000000000000000");
      await hexStakingPool
        .connect(deployer)
        .addReward(rewardToken2.address, deployer.address);

      await hexStakingPool
        .connect(deployer)
        .notifyRewardAmount(rewardToken2.address, rewardAmount);

      const rewardData = await hexStakingPool
        .connect(deployer)
        .getRewardData(rewardToken2.address);

      const rewardDuration: number = await hexStakingPool.REWARDS_DURATION();
      const rewardRate = BN(rewardAmount.toString()).div(
        BN(rewardDuration.toString())
      );

      expect(rewardData.rewardRate.toString()).to.equal(rewardRate.toString());
    });

    it("Calculate Rewards for total Duration", async function () {
      const rewardAmount: BigNumber = BigNumber.from("1000000000000000000000");

      await hexStakingPool
        .connect(deployer)
        .addReward(rewardToken2.address, deployer.address);

      await hexStakingPool
        .connect(deployer)
        .notifyRewardAmount(rewardToken2.address, rewardAmount);

      const rewardsRate = await hexStakingPool
        .connect(deployer)
        .getRewardData(rewardToken2.address);

      const rewardDuration = await hexStakingPool.REWARDS_DURATION();

      const totalRewards =
        BigInt(rewardDuration) * BigInt(rewardsRate.rewardRate);

      const totalRewardAmount = await hexStakingPool
        .connect(deployer)
        .getRewardForDuration(rewardToken2.address);

      expect(totalRewardAmount).to.equal(totalRewards);
    });

    it("If rewards are added before end of current duration leftover rewards will be added", async () => {
      const rewardAmount = 1000000;
      const rewardDuration = await hexStakingPool.REWARDS_DURATION();
      await hexStakingPool
        .connect(deployer)
        .addReward(rewardToken2.address, deployer.address);

      await hexStakingPool
        .connect(deployer)
        .notifyRewardAmount(rewardToken2.address, rewardAmount);

      let rewardData = await hexStakingPool.getRewardData(rewardToken2.address);

      await forward(30);

      // taking 31 instaed of 30 as notify rewardAmount will take 1 second
      const leftover = (rewardDuration - 31) * rewardData.rewardRate;

      const newTotalRewards = leftover + rewardAmount;

      const newRewardRate = newTotalRewards / rewardDuration;

      await hexStakingPool
        .connect(deployer)
        .notifyRewardAmount(rewardToken2.address, rewardAmount);

      rewardData = await hexStakingPool.getRewardData(rewardToken2.address);

      expect(newRewardRate).to.equal(rewardData.rewardRate);
      expect(newTotalRewards).to.equal(
        await hexStakingPool.getRewardForDuration(rewardToken2.address)
      );
    });
  });

  describe("Stake , unstake and earned reward test", () => {
    it("User can stake thier hex tokens", async function () {
      const stakeAmount: BigNumber = BigNumber.from("10000000");
      let stakesCount = await hexStakingPool.getStakeCount(user1.address);
      const totalHexTokens = await hexStakingPool.getTotalHexTokens(
        user1.address
      );
      expect(stakesCount).to.equal(0);

      expect(totalHexTokens).to.equal(0);

      const previousLockedTokens: BigNumber = BigNumber.from(
        await hexStakingPool.totalLockedTokens()
      );

      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const currentLockedTokens: BigNumber = BigNumber.from(
        await hexStakingPool.totalLockedTokens()
      );
      // As this is first stake so shares=stakeAmount
      stakesCount = await hexStakingPool.getStakeCount(user1.address);
      expect(stakesCount).to.equal(1);

      const balance = await hexStakingPool.getBalance(
        user1.address,
        0,
        HEXTokenAddress
      );

      expect(balance._stakedAmount).to.equal(stakeAmount);

      expect(currentLockedTokens.sub(previousLockedTokens)).to.equal(
        stakeAmount
      );
    });

    it("User can not stake 0 tokens", async function () {
      await expect(
        hexStakingPool.connect(deployer).stake(0, [], [], false)
      ).to.be.revertedWith("Cannot stake 0");
    });

    it("Stake tokens to check total supply & total stake balance of User", async function () {
      const stakeAmount: Number = 100000000;

      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      expect(await hexStakingPool.totalLockedTokens()).to.equal(stakeAmount);
      expect(
        await hexStakingPool.connect(user1).getTotalHexTokens(user1.address)
      ).to.equal(stakeAmount);
    });

    it("After staking user will start earning rewards", async () => {
      const stakeAmount: BigNumber = BigNumber.from("1000000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      const decimals = await hexTokenInstance.decimals();
      const hexRewardData = await hexStakingPool.getRewardData(HEXTokenAddress);
      const rewardTokenData = await hexStakingPool.getRewardData(
        rewardToken.address
      );

      // forwarding 5 seconds
      await forward(5);

      const difference = 18 - Number(decimals);

      const accumlatedHexToken: BigNumber = hexRewardData.rewardRate
        .div(10 ** difference)
        .mul(5);
      const accumlatedRewardToken: BigNumber =
        rewardTokenData.rewardRate.mul(5);

      const totalHex = await hexStakingPool.getTotalHexTokens(user1.address);

      // Rewards in other tokens
      const rewardData = await hexStakingPool.getTotalUserRewards(
        user1.address
      );

      expect(totalHex).to.equal(stakeAmount.add(accumlatedHexToken));

      expect(accumlatedRewardToken).to.equal(rewardData[1]);
    });

    it("Function rewardPerShare() should provide accumlated reward per share", async () => {
      const stakeAmount: BigNumber = BigNumber.from("100000000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      const rewardTokenData = await hexStakingPool.getRewardData(
        rewardToken.address
      );

      await forward(5);

      const accumlatedRewardToken = BN(
        rewardTokenData.rewardRate.mul(5).toString()
      );

      const rewardPerShare = await hexStakingPool.rewardPerShare(
        rewardToken.address
      );

      const sharesTotal = BN((await hexStakingPool.sharesTotal()).toString());

      expect(
        accumlatedRewardToken
          .multipliedBy(BN("10000000000000000000000"))
          .div(sharesTotal)
          .toString()
      ).to.equal(rewardPerShare.toString());
    });

    it("On user's action , accumlated hex tokens for current staked user will be autocompounded", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const hexRewardData = await hexStakingPool.getRewardData(HEXTokenAddress);

      // forwarding 5 seconds
      await forward(5);

      const decimals = await hexTokenInstance.decimals();

      const difference = 18 - Number(decimals);

      // totalLockedToken will increase and hence the price of the share will increase
      // That means other users who are staking same amount now will recieve less shares
      // hence less rewards

      // TotalLockedToken => stakeAmount + rewards in 6 seconds

      // TotalLockedToken => 10,000,000,000,000,000,000+300,000,000,000,000,000
      // Shares Total => 10,000,000,000,000,000,000
      // 1 share => totalLockedToken/sharesTotal => 1.03 win token

      // Now if user 2 stakes 10 win token
      // user2's shares => 10/1.03 =>9,708,737,864,077,669,902

      let totalLockedToken = BN(
        (await hexStakingPool.totalLockedTokens()).toString()
      );

      const totalAccumlatedRewardsIn6Seconds = BN(
        hexRewardData.rewardRate
          .div(10 ** difference)
          .mul(6)
          .toString()
      );

      totalLockedToken = totalLockedToken.plus(
        totalAccumlatedRewardsIn6Seconds
      );

      const totalShares = BN((await hexStakingPool.sharesTotal()).toString());

      const sharePrice = totalLockedToken.div(totalShares);

      await hexStakingPool.connect(user2).stake(stakeAmount, [], [], true);

      const calculatedUser2Shares = BN(stakeAmount.toString()).div(sharePrice);

      expect(
        (await hexStakingPool.userShares(user2.address)).toString()
      ).to.equal(calculatedUser2Shares.decimalPlaces(0, 1).toString());
    });

    it("Cannot unstake zero Amount", async function () {
      await expect(hexStakingPool.connect(user1).unstake(0)).to.be.revertedWith(
        "Cannot unstake 0"
      );
    });

    it("Calculate claimable earned tokens", async function () {
      const rewardAmount = BigInt("1000000000000000");
      await hexStakingPool
        .connect(deployer)
        .approveRewardDistributor(
          hexTokenInstance.address,
          deployer.address,
          true
        );

      await hexStakingPool
        .connect(deployer)
        .notifyRewardAmount(hexTokenInstance.address, rewardAmount);

      const stakeAmount = BigNumber.from("100000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      await forward(30);

      const decimals = await hexTokenInstance.decimals();

      const difference = 18 - Number(decimals);

      const totalUserHexTokens = await hexStakingPool.getTotalHexTokens(
        user1.address
      );

      const rewardData = await hexStakingPool.getRewardData(HEXTokenAddress);

      const totalRewardsAccumlated =
        (rewardData.rewardRate / 10 ** difference) * 30;

      const calculatedUserRewards = stakeAmount.add(totalRewardsAccumlated);

      const userRewards = await hexStakingPool.getTotalUserRewards(
        user1.address
      );

      expect(totalUserHexTokens).to.equal(calculatedUserRewards);

      expect(totalUserHexTokens.sub(stakeAmount)).to.equal(userRewards[0]);
    });
    it("Check if the userUnstakeIndex is tracked correctly", async function () {
      const stakeAmount = BigNumber.from("100000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      await forward(30);

      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      await forward(30);

      const sharesAfter2ndStake = await hexStakingPool.sharesTotal();

      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      await forward(200);

      await hexStakingPool.connect(user1).unstake(sharesAfter2ndStake);

      const userUnstakeIndex = await hexStakingPool.userUnstakeIndex(
        user1.address
      );

      expect(userUnstakeIndex).to.equal(2);
    });
  });

  describe("Early End Staking Penalty test", () => {
    it("If user has staked tokens it will be locked for 30 days and lock will apply on individual stakes", async () => {
      const stakeAmount: Number = 1000000000;
      const lockDuration: number = await hexStakingPool.LOCK_DURATION();
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      expect(
        await hexStakingPool.getTotalWithdrawableHexTokens(user1.address)
      ).to.equal(0);
      expect(
        await hexStakingPool.getWithdrawableShares(user1.address)
      ).to.equal(0);
      // forwarding 40 seconds
      await forward(40);
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      expect(
        await hexStakingPool.getTotalWithdrawableHexTokens(user1.address)
      ).to.equal(0);
      expect(
        await hexStakingPool.getWithdrawableShares(user1.address)
      ).to.equal(0);
      // again forwarding (lockDuration-40) seconds
      // After this first stake will be unlocked
      await forward(lockDuration - 40);
      const totalWithdrawableHEX =
        await hexStakingPool.getTotalWithdrawableHexTokens(user1.address);
      const rewardsData = await hexStakingPool.getClaimableRewards(
        user1.address
      );
      expect(totalWithdrawableHEX.sub(rewardsData[0])).to.equal(stakeAmount);
      const balance = await hexStakingPool.getBalance(
        user1.address,
        0,
        HEXTokenAddress
      );
      expect(
        await hexStakingPool.getWithdrawableShares(user1.address)
      ).to.equal(balance._sharesAmount);
    });
    it("If user withdraws before unlock period , penalty will be applied", async () => {
      const stakeAmount = BigNumber.from("1000000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      // forward 5 seconds
      await forward(5);
      // Rewards in 5 seconds
      let hexTokenRewardData = await hexStakingPool.getRewardData(
        HEXTokenAddress
      );
      let rewardTokenData = await hexStakingPool.getRewardData(
        rewardToken.address
      );
      const decimals = await hexTokenInstance.decimals();
      const difference = 18 - Number(decimals);
      let totalRewards1 = hexTokenRewardData.rewardRate
        .div(10 ** difference)
        .mul(5);
      let totalRewards2 = rewardTokenData.rewardRate.mul(5);
      let rewards = await hexStakingPool.getTotalUserRewards(user1.address);
      expect(rewards[0]).to.equal(totalRewards1);
      expect(rewards[1]).to.equal(totalRewards2);
      const deadAddressRewardToken1Balance = await hexTokenInstance.balanceOf(
        "0x000000000000000000000000000000000000dEaD"
      );
      const deadAddressrewardTokenBalance = await rewardToken.balanceOf(
        "0x000000000000000000000000000000000000dEaD"
      );
      const hexTokenBalance = await hexTokenInstance.balanceOf(user1.address);
      // user1 rewards as stake will take 1 second
      totalRewards1 = totalRewards1.add(
        hexTokenRewardData.rewardRate.div(10 ** difference)
      );
      totalRewards2 = totalRewards2.add(rewardTokenData.rewardRate);
      const stakeAmount2 = BigNumber.from("100000000000");
      await hexStakingPool.connect(deployer).stake(stakeAmount2, [], [], true);
      const user1Shares = await hexStakingPool.userShares(user1.address);
      rewards = await hexStakingPool.getTotalUserRewards(user1.address);
      // rewards of 1 seconds that unstake function will take
      const sharesTotal = await hexStakingPool.sharesTotal();
      const reward1OfUser1 = hexTokenRewardData.rewardRate
        .div(10 ** difference)
        .mul(user1Shares)
        .div(sharesTotal);
      const reward2OfUser1 = rewardTokenData.rewardRate
        .mul(user1Shares)
        .div(sharesTotal);
      totalRewards1 = totalRewards1.add(reward1OfUser1);
      totalRewards2 = totalRewards2.add(reward2OfUser1);

      const res = await hexStakingPool.connect(user1).unstake(user1Shares);
      const { events } = await res.wait();
      const event = events.find((x) => x.event === "Unstaked");
      // Event testcases
      expect(event.args.penalty).to.be.gt(BigNumber.from("0"));
      expect(event.args.user).to.be.equal(user1.address);
      expect(event.args.shares).to.be.equal(user1Shares);
      expect(event.args.amount).to.be.equal(
        stakeAmount.add(event.args.penalty)
      );
      const currentHexTokenBalance = await hexTokenInstance.balanceOf(
        user1.address
      );
      expect(currentHexTokenBalance.sub(hexTokenBalance)).to.equal(stakeAmount);
      const currentDeadAddressRewardToken1Balance =
        await hexTokenInstance.balanceOf(
          "0x000000000000000000000000000000000000dEaD"
        );
      const currentDeadAddressrewardTokenBalance = await rewardToken.balanceOf(
        "0x000000000000000000000000000000000000dEaD"
      );
      expect(
        currentDeadAddressRewardToken1Balance.sub(
          deadAddressRewardToken1Balance
        )
      ).to.equal(totalRewards1.div(2));
      expect(
        currentDeadAddressrewardTokenBalance.sub(deadAddressrewardTokenBalance)
      ).to.equal(totalRewards2.div(2));
      const rewardDuration = BigNumber.from(
        await hexStakingPool.REWARDS_DURATION()
      );
      const leftTime1 = BN(rewardDuration.sub(9).toString());
      const leftTime2 = BN(rewardDuration.sub(8).toString());
      const totalLeftReward1 = leftTime1.multipliedBy(
        BN(hexTokenRewardData.rewardRate.div(10 ** difference).toString())
      );
      const totalLeftReward2 = leftTime2.multipliedBy(
        BN(rewardTokenData.rewardRate.toString())
      );
      totalRewards1 = totalLeftReward1.plus(
        BN(totalRewards1.toString()).minus(BN(totalRewards1.toString()).div(2))
      );
      totalRewards2 = totalLeftReward2.plus(
        BN(totalRewards2.toString()).minus(BN(totalRewards2.toString()).div(2))
      );
      const newRewardRate1 = totalRewards1
        .multipliedBy(10 ** difference)
        .div(BN(rewardDuration.toString()));
      const newRewardRate2 = totalRewards2.div(BN(rewardDuration.toString()));
      hexTokenRewardData = await hexStakingPool.getRewardData(HEXTokenAddress);
      rewardTokenData = await hexStakingPool.getRewardData(rewardToken.address);
      expect(newRewardRate1.toFixed(0).toString()).to.equal(
        hexTokenRewardData.rewardRate.toString()
      );
      expect(newRewardRate2.toFixed(0).toString()).to.equal(
        rewardTokenData.rewardRate.toString()
      );
    });
    it("if user withdraws some portion then that penalty on that portion will be applied", async () => {
      const stakeAmount = BigNumber.from("10000000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      // forward 5 seconds
      await forward(5);
      const decimals = await hexTokenInstance.decimals();
      const difference = 18 - Number(decimals);
      // Rewards in 5 seconds
      let hexTokenRewardData = await hexStakingPool.getRewardData(
        HEXTokenAddress
      );
      let rewardTokenData = await hexStakingPool.getRewardData(
        rewardToken.address
      );
      let totalRewards1 = hexTokenRewardData.rewardRate
        .div(10 ** difference)
        .mul(5);
      let totalRewards2 = rewardTokenData.rewardRate.mul(5);
      let rewards = await hexStakingPool.getTotalUserRewards(user1.address);
      expect(rewards[0]).to.equal(totalRewards1);
      expect(rewards[1]).to.equal(totalRewards2);
      const deadAddressRewardToken1Balance = await hexTokenInstance.balanceOf(
        "0x000000000000000000000000000000000000dEaD"
      );
      const deadAddressrewardTokenBalance = await rewardToken.balanceOf(
        "0x000000000000000000000000000000000000dEaD"
      );
      const stakeAmount2 = BigNumber.from("100000000000");
      await hexStakingPool.connect(deployer).stake(stakeAmount2, [], [], true);
      // user1 rewards as stake will take 1 second
      totalRewards1 = totalRewards1.add(
        hexTokenRewardData.rewardRate.div(10 ** difference)
      );
      totalRewards2 = totalRewards2.add(rewardTokenData.rewardRate);
      const hexTokenBalance = await hexTokenInstance.balanceOf(user1.address);
      const user1Shares = await hexStakingPool.userShares(user1.address);
      rewards = await hexStakingPool.getTotalUserRewards(user1.address);
      // rewards of 1 seconds that unstake function will take
      const sharesTotal = await hexStakingPool.sharesTotal();
      const reward1OfUser1 = hexTokenRewardData.rewardRate
        .div(10 ** difference)
        .mul(user1Shares)
        .div(sharesTotal);
      const reward2OfUser1 = rewardTokenData.rewardRate
        .mul(user1Shares)
        .div(sharesTotal);
      totalRewards1 = totalRewards1.add(reward1OfUser1);
      totalRewards2 = totalRewards2.add(reward2OfUser1);
      await hexStakingPool.connect(user1).unstake(user1Shares.div(2));
      const currentHexTokenBalance = await hexTokenInstance.balanceOf(
        user1.address
      );
      expect(currentHexTokenBalance.sub(hexTokenBalance)).to.equal(
        stakeAmount.div(2)
      );
      const currentDeadAddressRewardToken1Balance =
        await hexTokenInstance.balanceOf(
          "0x000000000000000000000000000000000000dEaD"
        );
      const currentDeadAddressrewardTokenBalance = await rewardToken.balanceOf(
        "0x000000000000000000000000000000000000dEaD"
      );
      expect(
        currentDeadAddressRewardToken1Balance.sub(
          deadAddressRewardToken1Balance
        )
      ).to.equal(totalRewards1.div(4));
      expect(
        currentDeadAddressrewardTokenBalance.sub(deadAddressrewardTokenBalance)
      ).to.equal(totalRewards2.div(4));
      const rewardDuration = BigNumber.from(
        await hexStakingPool.REWARDS_DURATION()
      );
      const leftTime1 = BN(rewardDuration.sub(9).toString());
      const leftTime2 = BN(rewardDuration.sub(8).toString());
      const totalLeftReward1 = leftTime1.multipliedBy(
        BN(hexTokenRewardData.rewardRate.div(10 ** difference).toString())
      );
      const totalLeftReward2 = leftTime2.multipliedBy(
        BN(rewardTokenData.rewardRate.toString())
      );
      totalRewards1 = totalLeftReward1.plus(
        BN(totalRewards1.div(2).toString()).minus(
          BN(totalRewards1.toString()).div(4)
        )
      );
      totalRewards2 = totalLeftReward2.plus(
        BN(totalRewards2.div(2).toString()).minus(
          BN(totalRewards2.toString()).div(4)
        )
      );
      const newRewardRate1 = totalRewards1
        .multipliedBy(10 ** difference)
        .div(BN(rewardDuration.toString()));
      const newRewardRate2 = totalRewards2.div(BN(rewardDuration.toString()));
      hexTokenRewardData = await hexStakingPool.getRewardData(HEXTokenAddress);
      rewardTokenData = await hexStakingPool.getRewardData(rewardToken.address);
      expect(newRewardRate1.toFixed(0).toString()).to.equal(
        hexTokenRewardData.rewardRate.toString()
      );
      expect(newRewardRate2.toFixed(0).toString()).to.equal(
        rewardTokenData.rewardRate.toString()
      );
    });
    it("Claim function claims rewards of unlocked stakes only", async () => {
      const stakeAmount: Number = 100000000;
      const lockDuration: number = await hexStakingPool.LOCK_DURATION();
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      const decimals = await hexTokenInstance.decimals();
      const difference = 18 - Number(decimals);
      // forward 20 seconds
      await forward(20);
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      // calculate rewards for stake 1 => 20 + 1 second consumed in staking again
      const hexTokenRewardData = await hexStakingPool.getRewardData(
        HEXTokenAddress
      );
      const rewardTokenData = await hexStakingPool.getRewardData(
        rewardToken.address
      );
      let totalRewards1 = hexTokenRewardData.rewardRate
        .div(10 ** difference)
        .mul(21);
      let totalRewards2 = rewardTokenData.rewardRate.mul(21);
      let rewardPerShare = BN(totalRewards2.toString())
        .multipliedBy(1000000000000000)
        .div(BN(stakeAmount.toString()));
      // forward 20 seconds
      await forward(20);
      let rewards = await hexStakingPool.getClaimableRewards(user1.address);
      expect(rewards[0]).to.equal(0);
      expect(rewards[1]).to.equal(0);
      await forward(lockDuration - 41);
      // divinding by 2 as in this duration there are two stake each of same share
      const stake1Share = await hexStakingPool.getBalance(
        user1.address,
        0,
        HEXTokenAddress
      );
      const sharesTotal = await hexStakingPool.sharesTotal();
      totalRewards1 = totalRewards1.add(
        hexTokenRewardData.rewardRate
          .mul(lockDuration - 21)
          .mul(stake1Share._sharesAmount)
          .div(sharesTotal)
          .div(10 ** difference)
      );
      totalRewards2 = totalRewards2.add(
        rewardTokenData.rewardRate
          .mul(lockDuration - 21)
          .mul(stake1Share._sharesAmount)
          .div(sharesTotal)
      );
      rewards = await hexStakingPool.getClaimableRewards(user1.address);
      // dividing by 10 for precision
      expect(rewards[0].div(10)).to.equal(totalRewards1.div(10));
      expect(rewards[1]).to.equal(totalRewards2);
      // as claim will take 1 more second
      // (rewards in 1 second / 2)  as two stakes are there of equal shares
      const totalRewardsAccumlated = BN(
        rewardTokenData.rewardRate.mul(lockDuration - 20).toString()
      );
      rewardPerShare = rewardPerShare.plus(
        BN(
          totalRewardsAccumlated
            .multipliedBy(1000000000000000)
            .div(BN(sharesTotal.toString()))
            .toString()
        )
      );
      const reward2Balance = await rewardToken.balanceOf(user1.address);
      await hexStakingPool.connect(user1).claim(user1.address);
      const currentReward2Balance = await rewardToken.balanceOf(user1.address);
      const rewardPerShareFixed = BN(rewardPerShare.toFixed(0));
      expect(currentReward2Balance.sub(reward2Balance)).to.equal(
        rewardPerShareFixed
          .multipliedBy(BN(stake1Share._sharesAmount.toString()))
          .div(1000000000000000)
          .toFixed(0)
          .toString()
      );
    });
    it("Claim rewards on behalf of the user1", async () => {
      const stakeAmount: Number = 100000000;
      const lockDuration: number = await hexStakingPool.LOCK_DURATION();
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const decimals = await hexTokenInstance.decimals();

      const difference = 18 - Number(decimals);

      // forward 20 seconds
      await forward(20);
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      // calculate rewards for stake 1 => 20 + 1 second consumed in staking again
      const hexTokenRewardData = await hexStakingPool.getRewardData(
        HEXTokenAddress
      );
      const rewardTokenData = await hexStakingPool.getRewardData(
        rewardToken.address
      );
      let totalRewards1 = hexTokenRewardData.rewardRate
        .div(10 ** difference)
        .mul(21);
      let totalRewards2 = rewardTokenData.rewardRate.mul(21);
      let rewardPerShare = BN(totalRewards2.toString())
        .multipliedBy(1000000000000000)
        .div(BN(stakeAmount.toString()));
      // forward 20 seconds
      await forward(20);
      let rewards = await hexStakingPool.getClaimableRewards(user1.address);
      expect(rewards[0]).to.equal(0);
      expect(rewards[1]).to.equal(0);
      await forward(lockDuration - 41);
      // divinding by 2 as in this duration there are two stake each of same share
      const stake1Share = await hexStakingPool.getBalance(
        user1.address,
        0,
        HEXTokenAddress
      );
      const sharesTotal = await hexStakingPool.sharesTotal();
      totalRewards1 = totalRewards1.add(
        hexTokenRewardData.rewardRate
          .div(10 ** difference)
          .mul(lockDuration - 21)
          .mul(stake1Share._sharesAmount)
          .div(sharesTotal)
      );
      totalRewards2 = totalRewards2.add(
        rewardTokenData.rewardRate
          .mul(lockDuration - 21)
          .mul(stake1Share._sharesAmount)
          .div(sharesTotal)
      );
      rewards = await hexStakingPool.getClaimableRewards(user1.address);
      // dividing by 10 for precision
      expect(rewards[0].div(10)).to.equal(totalRewards1.div(10));
      expect(rewards[1]).to.equal(totalRewards2);
      // as claim will take 1 more second
      // (rewards in 1 second / 2)  as two stakes are there of equal shares
      const totalRewardsAccumlated = BN(
        rewardTokenData.rewardRate.mul(lockDuration - 20).toString()
      );
      rewardPerShare = rewardPerShare.plus(
        BN(
          totalRewardsAccumlated
            .multipliedBy(1000000000000000)
            .div(BN(sharesTotal.toString()))
            .toString()
        )
      );
      const reward2Balance = await rewardToken.balanceOf(user1.address);
      await hexStakingPool.connect(deployer).claim(user1.address);
      const currentReward2Balance = await rewardToken.balanceOf(user1.address);
      const rewardPerShareFixed = BN(rewardPerShare.toFixed(0));
      expect(currentReward2Balance.sub(reward2Balance)).to.equal(
        rewardPerShareFixed
          .multipliedBy(BN(stake1Share._sharesAmount.toString()))
          .div(1000000000000000)
          .toFixed(0)
          .toString()
      );
    });

    it("user unstakes some unlocked and some locked stakes ", async () => {
      let stakeAmount: BigNumber = BigNumber.from("1000000000");
      const lockDuration: number = Number(await hexStakingPool.LOCK_DURATION());
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      // forward 20 seconds
      await forward(20);
      stakeAmount = BigNumber.from("2000000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      // forward 20 seconds
      await forward(20);
      stakeAmount = BigNumber.from("1500000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      // Now user has 3 stakes
      // unlocking  only first stake by forwarding
      await forward(lockDuration - 42);
      const rewards = await hexStakingPool.getTotalRewardsOfStake(
        user1.address,
        0
      );
      const rewardTokenBalance = await rewardToken.balanceOf(user1.address);
      const unstakeShares: BigNumber = BigNumber.from("2000000000");
      const reward1Data = await hexStakingPool.getRewardData(
        rewardToken.address
      );
      const stake1Details = await hexStakingPool.getBalance(
        user1.address,
        0,
        rewardToken.address
      );
      const sharesTotal = await hexStakingPool.sharesTotal();
      await hexStakingPool.connect(user1).unstake(unstakeShares);
      const currentRewardTokenBalance = await rewardToken.balanceOf(
        user1.address
      );
      // Rewards in 1 second =>
      // dividing by 10 for precision to match expect
      expect(
        currentRewardTokenBalance.sub(rewardTokenBalance).div(10)
      ).to.equal(
        rewards[1]
          .add(
            reward1Data.rewardRate
              .mul(stake1Details._sharesAmount)
              .div(sharesTotal)
          )
          .div(10)
      );
    });

    it("User can not withdraw more than shares than balance", async () => {
      const stakeAmount: Number = 10000000;
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      // As in first stake share price is 1
      // Stake amount==shares given
      const unstakeAmount: BigNumber = BigNumber.from("10000001");
      await expect(
        hexStakingPool.connect(user1).unstake(unstakeAmount)
      ).to.be.revertedWith("Not enough shares");
    });

    it("Unlocked Rewards to be same as claimable rewards after unlock period", async function () {
      const stakeAmount: Number = 10000000;
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      // Unlock Rewards Before Duration Completes
      const unlockRewardBefore = await hexStakingPool.getClaimableRewards(
        user1.address
      );
      await forward(5);
      let totalRewards = await hexStakingPool.getTotalUserRewards(
        user1.address
      );
      expect(unlockRewardBefore[1]).to.equal(0);
      expect(totalRewards[1]).to.not.equal(0);
      const lockDuration = await hexStakingPool.LOCK_DURATION();
      await forward(Number(lockDuration.toString()));
      totalRewards = await hexStakingPool.getTotalUserRewards(user1.address);
      const unlockReward = await hexStakingPool.getClaimableRewards(
        user1.address
      );
      // After Lock duration completes, all unclocked rewards to be same as claimable rewards
      expect(totalRewards[1]).to.equal(unlockReward[1]);
      const rewardTokenBalance = await rewardToken.balanceOf(user1.address);
      const reward1Data = await hexStakingPool.getRewardData(
        rewardToken.address
      );
      // user claims the reward tokens
      await hexStakingPool.connect(user1).claim(user1.address);
      const currentrewardTokenBalance = await rewardToken.balanceOf(
        user1.address
      );
      expect(currentrewardTokenBalance.sub(rewardTokenBalance)).to.equal(
        totalRewards[1].add(reward1Data.rewardRate)
      );
      const rewardsAfterClaim = await hexStakingPool.getTotalUserRewards(
        user1.address
      );
      expect(rewardsAfterClaim[1]).to.equal(0);
    });

    it("calculatePenalties function test when all stakes are unlocked", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      // forwarding 30 seconds
      await forward(30);
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      let withdrawableShares = await hexStakingPool.getWithdrawableShares(
        user1.address
      );
      expect(withdrawableShares).to.equal(0);
      const lockDuration = await hexStakingPool.LOCK_DURATION();
      await forward(Number(lockDuration));
      const totalUserRewards = await hexStakingPool.getTotalUserRewards(
        user1.address
      );
      const totalClaimableRewards = await hexStakingPool.getClaimableRewards(
        user1.address
      );
      expect(totalUserRewards[0]).to.equal(totalClaimableRewards[0]);
      expect(totalUserRewards[1]).to.equal(totalClaimableRewards[1]);
      const totalUserShares = await hexStakingPool.userShares(user1.address);
      withdrawableShares = await hexStakingPool.getWithdrawableShares(
        user1.address
      );
      expect(withdrawableShares).to.equal(totalUserShares);
      const calculatePenalties = await hexStakingPool.calculatePenalties(
        user1.address,
        totalUserShares
      );
      // Both stakes are locked currently so total earned rewards will be penalty
      expect(0).to.equal(calculatePenalties._totalPenaltyRewards[0]);
      expect(0).to.equal(calculatePenalties._totalPenaltyRewards[1]);
      expect(totalClaimableRewards[0]).to.equal(
        calculatePenalties._totalClaimableRewards[0]
      );
      expect(totalClaimableRewards[1]).to.equal(
        calculatePenalties._totalClaimableRewards[1]
      );
      expect(0).to.equal(calculatePenalties._penalizedAmount);
    });

    it("calculatePenalties function test when all stakes are locked", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      // forwarding 30 seconds
      await forward(30);
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      const withdrawableShares = await hexStakingPool.getWithdrawableShares(
        user1.address
      );
      expect(withdrawableShares).to.equal(0);
      const totalUserRewards = await hexStakingPool.getTotalUserRewards(
        user1.address
      );
      const totalUserShares = await hexStakingPool.userShares(user1.address);
      const calculatePenalties = await hexStakingPool.calculatePenalties(
        user1.address,
        totalUserShares
      );
      // Both stakes are locked currently so total earned rewards will be penalty
      expect(totalUserRewards[0]).to.equal(
        calculatePenalties._totalPenaltyRewards[0]
      );
      expect(totalUserRewards[1]).to.equal(
        calculatePenalties._totalPenaltyRewards[1]
      );
      expect(0).to.equal(calculatePenalties._totalClaimableRewards[0]);
      expect(0).to.equal(calculatePenalties._totalClaimableRewards[1]);
      expect(totalUserShares).to.equal(calculatePenalties._penalizedAmount);
    });

    it("calculatePenalties when some stakes are locked and some are unlocked", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      const firstStakeShares = await hexStakingPool.getBalance(
        user1.address,
        0,
        HEXTokenAddress
      );
      const lockDuration = await hexStakingPool.LOCK_DURATION();
      // forwarding 30 seconds
      await forward(30);
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      let withdrawableShares = await hexStakingPool.getWithdrawableShares(
        user1.address
      );
      expect(withdrawableShares).to.equal(0);
      // 30 forward and 1 second for second stake
      // After this first stake will be unlocked
      await forward(lockDuration - 31);
      withdrawableShares = await hexStakingPool.getWithdrawableShares(
        user1.address
      );
      expect(withdrawableShares).to.equal(firstStakeShares._sharesAmount);
      const totalUserRewards = await hexStakingPool.getTotalUserRewards(
        user1.address
      );
      const totalClaimableRewards = await hexStakingPool.getClaimableRewards(
        user1.address
      );
      const totalUserShares = await hexStakingPool.userShares(user1.address);
      const calculatePenalties = await hexStakingPool.calculatePenalties(
        user1.address,
        totalUserShares
      );
      expect(totalUserRewards[0].sub(totalClaimableRewards[0])).to.equal(
        calculatePenalties._totalPenaltyRewards[0]
      );
      expect(totalUserRewards[1].sub(totalClaimableRewards[1])).to.equal(
        calculatePenalties._totalPenaltyRewards[1]
      );
      expect(totalClaimableRewards[0]).to.equal(
        calculatePenalties._totalClaimableRewards[0]
      );
      expect(totalClaimableRewards[1]).to.equal(
        calculatePenalties._totalClaimableRewards[1]
      );
      expect(totalUserShares.sub(firstStakeShares._sharesAmount)).to.equal(
        calculatePenalties._penalizedAmount
      );
    });

    it("calculatePenalties when some stakes are locked and some are unlocked with partial withdraw", async () => {
      const stakeAmount: BigNumber = BigNumber.from("1000000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      const firstStakeShares = await hexStakingPool.getBalance(
        user1.address,
        0,
        HEXTokenAddress
      );
      const lockDuration = await hexStakingPool.LOCK_DURATION();
      // forwarding 30 seconds
      await forward(30);
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      let withdrawableShares = await hexStakingPool.getWithdrawableShares(
        user1.address
      );
      expect(withdrawableShares).to.equal(0);
      // 30 forward and 1 second for second stake
      // After this first stake will be unlocked
      await forward(lockDuration - 31);
      withdrawableShares = await hexStakingPool.getWithdrawableShares(
        user1.address
      );
      expect(withdrawableShares).to.equal(firstStakeShares._sharesAmount);
      const totalUserRewards = await hexStakingPool.getTotalUserRewards(
        user1.address
      );
      const totalClaimableRewards = await hexStakingPool.getClaimableRewards(
        user1.address
      );
      const secondStakeShares = await hexStakingPool.getBalance(
        user1.address,
        1,
        HEXTokenAddress
      );
      const calculatePenalties = await hexStakingPool.calculatePenalties(
        user1.address,
        firstStakeShares._sharesAmount.add(
          secondStakeShares._sharesAmount.div(2)
        )
      );
      expect(totalUserRewards[0].sub(totalClaimableRewards[0]).div(2)).to.equal(
        calculatePenalties._totalPenaltyRewards[0]
      );
      expect(totalUserRewards[1].sub(totalClaimableRewards[1]).div(2)).to.equal(
        calculatePenalties._totalPenaltyRewards[1]
      );
      expect(totalClaimableRewards[0]).to.equal(
        calculatePenalties._totalClaimableRewards[0]
      );
      expect(totalClaimableRewards[1]).to.equal(
        calculatePenalties._totalClaimableRewards[1]
      );
      expect(secondStakeShares._sharesAmount.div(2)).to.equal(
        calculatePenalties._penalizedAmount
      );
    });
  });

  describe("TWAB tests", () => {
    context("getBalanceAt", () => {
      it("should return 0 for time before twabs", async () => {
        const lastTimestamp =
          (await waffle.provider.getBlock("latest")).timestamp + 1;
        await hexStakingPool.connect(user1).stake(1000, [], [], true);
        expect(
          await hexStakingPool.getBalanceAt(user1.address, lastTimestamp - 100)
        ).to.equal(0);
      });

      it("should return the current balance if time at or after last twab", async () => {
        const lastTimestamp =
          (await waffle.provider.getBlock("latest")).timestamp + 1;
        await hexStakingPool.connect(user1).stake(1000, [], [], true);
        await forward(1000);
        expect(
          await hexStakingPool.getBalanceAt(user1.address, lastTimestamp + 1000)
        ).to.equal("1000");
      });

      it("should return the current balance after the twab", async () => {
        const lastTimestamp =
          (await waffle.provider.getBlock("latest")).timestamp + 1;
        await hexStakingPool.connect(user1).stake(1000, [], [], true);
        expect(
          await hexStakingPool.getBalanceAt(user1.address, lastTimestamp + 1000)
        ).to.equal("1000");
      });
    });
  });
  describe("Sponser Testcases", () => {
    it("should get tickets when user stakes and has opted in Prize Pool", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000");
      const ticketsBeforeStaking = await hexPrizePool.totalTicketNumber();
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      await hexStakingPool
        .connect(user1)
        .stake(stakeAmount.mul(2), [], [], true);
      await hexStakingPool
        .connect(user1)
        .stake(stakeAmount.div(2), [], [], true);
      const ticketsAfterStaking = await hexPrizePool.totalTicketNumber();

      const { start, end } = await hexPrizePool.getRangeDetails(
        user1.address,
        0
      );
      expect(await hexStakingPool.userShares(user1.address)).to.be.equal(
        ticketsAfterStaking.sub(ticketsBeforeStaking)
      );
      expect(start).to.be.equal(1);
      expect(end).to.be.equal(stakeAmount);
    });
    it("should update tickets when user unstakes", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000");
      const unStakeAmount: BigNumber = BigNumber.from("1000000");

      const ticketsBeforeStaking = await hexPrizePool.totalTicketNumber();
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const ticketAfterStaking = await hexPrizePool.totalTicketNumber();

      await hexStakingPool.connect(user1).unstake(unStakeAmount);

      const ticketAfterUnstaking = await hexPrizePool.totalTicketNumber();
      const { start, end } = await hexPrizePool.getRangeDetails(
        user1.address,
        0
      );

      expect(ticketAfterStaking.sub(ticketsBeforeStaking)).to.be.equal(
        stakeAmount
      );
      expect(ticketAfterStaking.sub(ticketAfterUnstaking)).to.be.equal(
        unStakeAmount
      );
      expect(start).to.be.equal(1);
      expect(end).to.be.equal(stakeAmount.sub(unStakeAmount));
      expect(await hexPrizePool.totalTicketNumber()).to.be.equal(
        stakeAmount.sub(unStakeAmount)
      );
    });
    it("should burn tickets when unstaking all amount", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000");
      const unStakeAmount: BigNumber = BigNumber.from("10000000");
      const ticketsBeforeStaking = await hexPrizePool.totalTicketNumber();
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      const ticketAfterStaking = await hexPrizePool.totalTicketNumber();
      await hexStakingPool.connect(user1).unstake(unStakeAmount);
      const ticketAfterUnstaking = await hexPrizePool.totalTicketNumber();
      expect(ticketAfterStaking.sub(ticketsBeforeStaking)).to.be.equal(
        stakeAmount
      );
      expect(ticketAfterUnstaking).to.be.equal(ticketsBeforeStaking);
    });
    it("should not get tickets when not opted for prizePool", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], false);
      expect(await hexPrizePool.totalTicketNumber()).to.be.equal(0);
    });
    it("should not change preference once staked", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      await expect(
        hexStakingPool.connect(user1).stake(stakeAmount, [], [], false)
      ).to.be.revertedWith("Cannot change PrizePool Preference.");
    });
    it("should be able to change preference after unstaking all funds", async () => {
      const stakeAmount: BigNumber = BigNumber.from("10000000");
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);
      await expect(
        hexStakingPool.connect(user1).stake(stakeAmount, [], [], false)
      ).to.be.revertedWith("Cannot change PrizePool Preference.");
      await hexStakingPool.connect(user1).unstake(stakeAmount);
      expect(
        await hexStakingPool.connect(user1).stake(stakeAmount, [], [], false)
      ).to.be.ok;
    });
  });
});
