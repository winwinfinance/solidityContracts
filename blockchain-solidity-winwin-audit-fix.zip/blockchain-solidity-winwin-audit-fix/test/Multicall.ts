import { ethers } from "hardhat";
import { Contract, ContractFactory } from "ethers";
import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import { expect } from "chai";

describe("Multicall Test", function () {
  let deployer: SignerWithAddress,
    user1: SignerWithAddress,
    user2: SignerWithAddress,
    user3: SignerWithAddress;
  let Token: ContractFactory;
  let token: Contract;
  let Multicall: ContractFactory;
  let multicall: Contract;
  before(async () => {
    [deployer, user1, user2, user3] = await ethers.getSigners();
    const tokenSupply = 5000000000;
    Token = await ethers.getContractFactory("WinToken");
    token = await Token.deploy(tokenSupply);
    await token.deployed();
    Multicall = await ethers.getContractFactory("MultiCall");
    multicall = await Multicall.deploy();
    await multicall.deployed();
  });
  it("batches function calls", async function () {
    expect(await token.balanceOf(user1.address)).to.be.equal(0);
    expect(await token.balanceOf(user2.address)).to.be.equal(0);
    expect(await token.balanceOf(user3.address)).to.be.equal(0);

    await token.approve(multicall.address, 30000);

    const iface = new ethers.utils.Interface([
      "function transferFrom(address from, address to, uint256 amount)",
    ]);

    await multicall.multiCall(
      [token.address, token.address, token.address],
      [
        iface.encodeFunctionData("transferFrom", [
          deployer.address,
          user1.address,
          10000,
        ]),
        iface.encodeFunctionData("transferFrom", [
          deployer.address,
          user2.address,
          10000,
        ]),
        iface.encodeFunctionData("transferFrom", [
          deployer.address,
          user3.address,
          10000,
        ]),
      ]
    );

    expect(await token.balanceOf(user1.address)).to.be.equal(10000);
    expect(await token.balanceOf(user2.address)).to.be.equal(10000);
    expect(await token.balanceOf(user3.address)).to.be.equal(10000);
  });
  it("reverts if targets length != data length", async () => {
    await expect(multicall.multiCall([token.address], [])).to.be.revertedWith(
      "target length != data length"
    );
  });

  it("reverts if call fails", async () => {
    const iface = new ethers.utils.Interface([
      "function transferFrom(address from, address to, uint256 amount)",
    ]);

    await expect(
      multicall.multiCall(
        [token.address],
        [
          iface.encodeFunctionData("transferFrom", [
            deployer.address,
            user1.address,
            1000000000000000,
          ]),
        ]
      )
    ).to.be.reverted;
  });
});
