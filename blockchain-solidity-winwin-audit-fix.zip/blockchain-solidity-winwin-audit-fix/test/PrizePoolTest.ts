import { expect } from "chai";
import { ethers, waffle } from "hardhat";
import { BigNumber, Contract, ContractFactory } from "ethers";
import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import { doesNotMatch } from "assert";
import { setBalance } from "@nomicfoundation/hardhat-network-helpers";

let deployer: SignerWithAddress,
  user1: SignerWithAddress,
  user2: SignerWithAddress,
  user3: SignerWithAddress,
  user4: SignerWithAddress,
  user5: SignerWithAddress,
  user6: SignerWithAddress,
  user7: SignerWithAddress,
  user8: SignerWithAddress,
  user9: SignerWithAddress;

let PrizePoolContract: ContractFactory;
let prizePool: Contract;
let WinWin: ContractFactory;
let winToken: Contract;
let WinStakingPool: ContractFactory;
let winStakingPool: Contract;
let RandomNumberContract: ContractFactory;
let randomNumber: Contract;
let rewardToken1: Contract;
let rewardToken2: Contract;
let rewardToken3: Contract;

const hashes = [
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [1])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [2])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [3])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [4])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [5])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [6])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [7])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [8])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [9])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [10])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [11])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [12])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [13])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [14])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [15])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [16])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [17])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [18])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [19])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [20])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [21])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [22])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [23])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [24])),
  ethers.utils.keccak256(ethers.utils.solidityPack(["uint256"], [25])),
];

async function forward(seconds: any) {
  const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;
  await waffle.provider.send("evm_setNextBlockTimestamp", [
    lastTimestamp + seconds,
  ]);
  await waffle.provider.send("evm_mine", []);
}

async function multipleEligibleStakes() {
  // user 1 stakes
  let ethAmount = "100";
  const weiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user1.address, weiAmount, [], []);

  let totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
  let totalTickets = await prizePool.totalTicketNumber();

  expect(totalEligibleTickets).to.equal(weiAmount);
  expect(totalTickets).to.equal(weiAmount);

  // Ending range will be current total eligible tickets number
  let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTickets
  );

  expect(endingRangeDetails.userAddress).to.equal(user1.address);

  expect(endingRangeDetails.start).to.equal(1);

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);

  // user 2 stakes

  ethAmount = "12";
  const user2WeiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user2.address, user2WeiAmount, [], []);

  totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
  totalTickets = await prizePool.totalTicketNumber();

  expect(totalEligibleTickets).to.equal(weiAmount.add(user2WeiAmount));
  expect(totalTickets).to.equal(weiAmount.add(user2WeiAmount));

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTickets
  );

  expect(endingRangeDetails.userAddress).to.equal(user2.address);

  expect(endingRangeDetails.start).to.equal(weiAmount.add(1));

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);

  // user 3 stakes

  ethAmount = "23";
  const user3WeiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user3.address, user3WeiAmount, [], []);

  totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
  totalTickets = await prizePool.totalTicketNumber();

  expect(totalEligibleTickets).to.equal(
    weiAmount.add(user2WeiAmount).add(user3WeiAmount)
  );
  expect(totalTickets).to.equal(
    weiAmount.add(user2WeiAmount).add(user3WeiAmount)
  );

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTickets
  );

  expect(endingRangeDetails.userAddress).to.equal(user3.address);

  expect(endingRangeDetails.start).to.equal(
    weiAmount.add(user2WeiAmount).add(1)
  );

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);

  // User 1 stakes again

  ethAmount = "87";
  const user1WeiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user1.address, user1WeiAmount, [], []);

  totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
  totalTickets = await prizePool.totalTicketNumber();

  expect(totalEligibleTickets).to.equal(
    weiAmount.add(user2WeiAmount).add(user3WeiAmount).add(user1WeiAmount)
  );
  expect(totalTickets).to.equal(
    weiAmount.add(user2WeiAmount).add(user3WeiAmount).add(user1WeiAmount)
  );

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTickets
  );

  expect(endingRangeDetails.userAddress).to.equal(user1.address);

  expect(endingRangeDetails.start).to.equal(
    weiAmount.add(user2WeiAmount).add(user3WeiAmount).add(1)
  );

  expect(endingRangeDetails.indexInUserRanges).to.equal(1);
}

async function multipleEligibleStakesSetupForShuffle() {
  // user 1 stakes
  let ethAmount = "1000";
  const weiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user1.address, weiAmount, [], []);

  let totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
  let totalTickets = await prizePool.totalTicketNumber();

  expect(totalEligibleTickets).to.equal(weiAmount);
  expect(totalTickets).to.equal(weiAmount);

  // Ending range will be current total eligible tickets number
  let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTickets
  );

  expect(endingRangeDetails.userAddress).to.equal(user1.address);

  expect(endingRangeDetails.start).to.equal(1);

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);

  // user 2 stakes

  ethAmount = "12";
  const user2WeiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user2.address, user2WeiAmount, [], []);

  totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
  totalTickets = await prizePool.totalTicketNumber();

  expect(totalEligibleTickets).to.equal(weiAmount.add(user2WeiAmount));
  expect(totalTickets).to.equal(weiAmount.add(user2WeiAmount));

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTickets
  );

  expect(endingRangeDetails.userAddress).to.equal(user2.address);

  expect(endingRangeDetails.start).to.equal(weiAmount.add(1));

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);

  // user 3 stakes

  ethAmount = "230";
  const user3WeiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user3.address, user3WeiAmount, [], []);

  totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
  totalTickets = await prizePool.totalTicketNumber();

  expect(totalEligibleTickets).to.equal(
    weiAmount.add(user2WeiAmount).add(user3WeiAmount)
  );
  expect(totalTickets).to.equal(
    weiAmount.add(user2WeiAmount).add(user3WeiAmount)
  );

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTickets
  );

  expect(endingRangeDetails.userAddress).to.equal(user3.address);

  expect(endingRangeDetails.start).to.equal(
    weiAmount.add(user2WeiAmount).add(1)
  );

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);

  // User 1 stakes again

  ethAmount = "87";
  const user1WeiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user1.address, user1WeiAmount, [], []);

  totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
  totalTickets = await prizePool.totalTicketNumber();

  expect(totalEligibleTickets).to.equal(
    weiAmount.add(user2WeiAmount).add(user3WeiAmount).add(user1WeiAmount)
  );
  expect(totalTickets).to.equal(
    weiAmount.add(user2WeiAmount).add(user3WeiAmount).add(user1WeiAmount)
  );

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTickets
  );

  expect(endingRangeDetails.userAddress).to.equal(user1.address);

  expect(endingRangeDetails.start).to.equal(
    weiAmount.add(user2WeiAmount).add(user3WeiAmount).add(1)
  );

  expect(endingRangeDetails.indexInUserRanges).to.equal(1);

  ethAmount = "22";
  const user4WeiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user4.address, user4WeiAmount, [], []);

  totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
  totalTickets = await prizePool.totalTicketNumber();

  expect(totalEligibleTickets).to.equal(
    weiAmount
      .add(user2WeiAmount)
      .add(user3WeiAmount)
      .add(user1WeiAmount)
      .add(user4WeiAmount)
  );
  expect(totalTickets).to.equal(
    weiAmount
      .add(user2WeiAmount)
      .add(user3WeiAmount)
      .add(user1WeiAmount)
      .add(user4WeiAmount)
  );

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTickets
  );

  expect(endingRangeDetails.userAddress).to.equal(user4.address);

  expect(endingRangeDetails.start).to.equal(
    weiAmount.add(user2WeiAmount).add(user3WeiAmount).add(user1WeiAmount).add(1)
  );

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);

  ethAmount = "34";
  const user5WeiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user5.address, user5WeiAmount, [], []);

  totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
  totalTickets = await prizePool.totalTicketNumber();

  expect(totalEligibleTickets).to.equal(
    weiAmount
      .add(user2WeiAmount)
      .add(user3WeiAmount)
      .add(user1WeiAmount)
      .add(user4WeiAmount)
      .add(user5WeiAmount)
  );
  expect(totalTickets).to.equal(
    weiAmount
      .add(user2WeiAmount)
      .add(user3WeiAmount)
      .add(user1WeiAmount)
      .add(user4WeiAmount)
      .add(user5WeiAmount)
  );

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTickets
  );

  expect(endingRangeDetails.userAddress).to.equal(user5.address);

  expect(endingRangeDetails.start).to.equal(
    weiAmount
      .add(user2WeiAmount)
      .add(user3WeiAmount)
      .add(user1WeiAmount)
      .add(user4WeiAmount)
      .add(1)
  );

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);
}

async function multipleEligibleStakesSetupForShuffleLimit() {
  await multipleEligibleStakesSetupForShuffle();
  // user 1 stakes
  let ethAmount = "2";
  const user1WeiAmount = ethers.utils.parseEther(ethAmount);
  let totalEligibleTicketsBefore = await prizePool.totalEligibleForThisDraw();
  let totalTicketsBefore = await prizePool.totalTicketNumber();

  await prizePool
    .connect(deployer)
    .getTickets(user1.address, user1WeiAmount, [], []);

  let totalEligibleTicketsAfter = await prizePool.totalEligibleForThisDraw();
  let totalTicketsAfter = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsBefore.add(user1WeiAmount)).to.equal(
    totalEligibleTicketsAfter
  );
  expect(totalTicketsBefore.add(user1WeiAmount)).to.equal(totalTicketsAfter);

  // Ending range will be current total eligible tickets number
  let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTicketsAfter
  );

  expect(endingRangeDetails.userAddress).to.equal(user1.address);

  expect(endingRangeDetails.start).to.equal(totalEligibleTicketsBefore.add(1));

  expect(endingRangeDetails.indexInUserRanges).to.equal(2);

  // user 7 stakes
  ethAmount = "5";
  let user7WeiAmount = ethers.utils.parseEther(ethAmount);
  totalEligibleTicketsBefore = await prizePool.totalEligibleForThisDraw();
  totalTicketsBefore = await prizePool.totalTicketNumber();

  await prizePool
    .connect(deployer)
    .getTickets(user7.address, user7WeiAmount, [], []);

  totalEligibleTicketsAfter = await prizePool.totalEligibleForThisDraw();
  totalTicketsAfter = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsBefore.add(user7WeiAmount)).to.equal(
    totalEligibleTicketsAfter
  );
  expect(totalTicketsBefore.add(user7WeiAmount)).to.equal(totalTicketsAfter);

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTicketsAfter
  );

  expect(endingRangeDetails.userAddress).to.equal(user7.address);

  expect(endingRangeDetails.start).to.equal(totalEligibleTicketsBefore.add(1));

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);

  // user 8 stakes
  ethAmount = "7";
  const user8WeiAmount = ethers.utils.parseEther(ethAmount);
  totalEligibleTicketsBefore = await prizePool.totalEligibleForThisDraw();
  totalTicketsBefore = await prizePool.totalTicketNumber();

  await prizePool
    .connect(deployer)
    .getTickets(user8.address, user8WeiAmount, [], []);

  totalEligibleTicketsAfter = await prizePool.totalEligibleForThisDraw();
  totalTicketsAfter = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsBefore.add(user8WeiAmount)).to.equal(
    totalEligibleTicketsAfter
  );
  expect(totalTicketsBefore.add(user8WeiAmount)).to.equal(totalTicketsAfter);

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTicketsAfter
  );

  expect(endingRangeDetails.userAddress).to.equal(user8.address);

  expect(endingRangeDetails.start).to.equal(totalEligibleTicketsBefore.add(1));

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);

  // user 7 stakes
  ethAmount = "9";
  user7WeiAmount = ethers.utils.parseEther(ethAmount);
  totalEligibleTicketsBefore = await prizePool.totalEligibleForThisDraw();
  totalTicketsBefore = await prizePool.totalTicketNumber();

  await prizePool
    .connect(deployer)
    .getTickets(user7.address, user7WeiAmount, [], []);

  totalEligibleTicketsAfter = await prizePool.totalEligibleForThisDraw();
  totalTicketsAfter = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsBefore.add(user7WeiAmount)).to.equal(
    totalEligibleTicketsAfter
  );
  expect(totalTicketsBefore.add(user7WeiAmount)).to.equal(totalTicketsAfter);

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTicketsAfter
  );

  expect(endingRangeDetails.userAddress).to.equal(user7.address);

  expect(endingRangeDetails.start).to.equal(totalEligibleTicketsBefore.add(1));

  expect(endingRangeDetails.indexInUserRanges).to.equal(1);

  // user 9 stakes
  ethAmount = "3";
  const user9WeiAmount = ethers.utils.parseEther(ethAmount);
  totalEligibleTicketsBefore = await prizePool.totalEligibleForThisDraw();
  totalTicketsBefore = await prizePool.totalTicketNumber();

  await prizePool
    .connect(deployer)
    .getTickets(user9.address, user9WeiAmount, [], []);

  totalEligibleTicketsAfter = await prizePool.totalEligibleForThisDraw();
  totalTicketsAfter = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsBefore.add(user9WeiAmount)).to.equal(
    totalEligibleTicketsAfter
  );
  expect(totalTicketsBefore.add(user9WeiAmount)).to.equal(totalTicketsAfter);

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalEligibleTicketsAfter
  );

  expect(endingRangeDetails.userAddress).to.equal(user9.address);

  expect(endingRangeDetails.start).to.equal(totalEligibleTicketsBefore.add(1));

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);
}

async function multipleNonEligibleStakesForShuffle() {
  const totalEligibleTicketsBefore = await prizePool.totalEligibleForThisDraw();
  const totalTicketsBefore = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsBefore).to.equal(totalTicketsBefore);

  // Now user4 is staking
  let ethAmount = "40";
  const weiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user4.address, weiAmount, [], []);

  let totalEligibleTicketsAfter = await prizePool.totalEligibleForThisDraw();
  let totalTicketsAfter = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsAfter).to.equal(totalEligibleTicketsBefore);
  expect(totalTicketsAfter).to.equal(totalTicketsBefore.add(weiAmount));

  // Ending range will be current total eligible tickets number
  let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalTicketsAfter
  );

  expect(endingRangeDetails.userAddress).to.equal(user4.address);

  expect(endingRangeDetails.start).to.equal(totalEligibleTicketsBefore.add(1));

  expect(endingRangeDetails.indexInUserRanges).to.equal(1);

  // Now user5 is staking
  ethAmount = "150";
  const user5weiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user5.address, user5weiAmount, [], []);

  totalEligibleTicketsAfter = await prizePool.totalEligibleForThisDraw();
  totalTicketsAfter = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsAfter).to.equal(totalEligibleTicketsBefore);
  expect(totalTicketsAfter).to.equal(
    totalTicketsBefore.add(weiAmount).add(user5weiAmount)
  );

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalTicketsAfter
  );

  expect(endingRangeDetails.userAddress).to.equal(user5.address);

  expect(endingRangeDetails.start).to.equal(
    totalEligibleTicketsBefore.add(weiAmount).add(1)
  );

  expect(endingRangeDetails.indexInUserRanges).to.equal(1);

  // Now user6 is staking
  ethAmount = "88";
  const user6weiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user6.address, user6weiAmount, [], []);

  totalEligibleTicketsAfter = await prizePool.totalEligibleForThisDraw();
  totalTicketsAfter = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsAfter).to.equal(totalEligibleTicketsBefore);
  expect(totalTicketsAfter).to.equal(
    totalTicketsBefore.add(weiAmount).add(user5weiAmount).add(user6weiAmount)
  );

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalTicketsAfter
  );

  expect(endingRangeDetails.userAddress).to.equal(user6.address);

  expect(endingRangeDetails.start).to.equal(
    totalEligibleTicketsBefore.add(weiAmount).add(user5weiAmount).add(1)
  );

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);

  // Now user5 is staking
  ethAmount = "30";
  const user5weiAmount2 = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user5.address, user5weiAmount2, [], []);

  totalEligibleTicketsAfter = await prizePool.totalEligibleForThisDraw();
  totalTicketsAfter = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsAfter).to.equal(totalEligibleTicketsBefore);
  expect(totalTicketsAfter).to.equal(
    totalTicketsBefore
      .add(weiAmount)
      .add(user5weiAmount)
      .add(user6weiAmount)
      .add(user5weiAmount2)
  );

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalTicketsAfter
  );

  expect(endingRangeDetails.userAddress).to.equal(user5.address);

  expect(endingRangeDetails.start).to.equal(
    totalEligibleTicketsBefore
      .add(weiAmount)
      .add(user5weiAmount)
      .add(user6weiAmount)
      .add(1)
  );

  expect(endingRangeDetails.indexInUserRanges).to.equal(2);
}

async function multipleNonEligibleStakes() {
  const totalEligibleTicketsBefore = await prizePool.totalEligibleForThisDraw();
  const totalTicketsBefore = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsBefore).to.equal(totalTicketsBefore);

  // Now user4 is staking
  let ethAmount = "40";
  const weiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user4.address, weiAmount, [], []);

  let totalEligibleTicketsAfter = await prizePool.totalEligibleForThisDraw();
  let totalTicketsAfter = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsAfter).to.equal(totalEligibleTicketsBefore);
  expect(totalTicketsAfter).to.equal(totalTicketsBefore.add(weiAmount));

  // Ending range will be current total eligible tickets number
  let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalTicketsAfter
  );

  expect(endingRangeDetails.userAddress).to.equal(user4.address);

  expect(endingRangeDetails.start).to.equal(totalEligibleTicketsBefore.add(1));

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);

  // Now user5 is staking
  ethAmount = "150";
  const user5weiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user5.address, user5weiAmount, [], []);

  totalEligibleTicketsAfter = await prizePool.totalEligibleForThisDraw();
  totalTicketsAfter = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsAfter).to.equal(totalEligibleTicketsBefore);
  expect(totalTicketsAfter).to.equal(
    totalTicketsBefore.add(weiAmount).add(user5weiAmount)
  );

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalTicketsAfter
  );

  expect(endingRangeDetails.userAddress).to.equal(user5.address);

  expect(endingRangeDetails.start).to.equal(
    totalEligibleTicketsBefore.add(weiAmount).add(1)
  );

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);

  // Now user6 is staking
  ethAmount = "88";
  const user6weiAmount = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user6.address, user6weiAmount, [], []);

  totalEligibleTicketsAfter = await prizePool.totalEligibleForThisDraw();
  totalTicketsAfter = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsAfter).to.equal(totalEligibleTicketsBefore);
  expect(totalTicketsAfter).to.equal(
    totalTicketsBefore.add(weiAmount).add(user5weiAmount).add(user6weiAmount)
  );

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalTicketsAfter
  );

  expect(endingRangeDetails.userAddress).to.equal(user6.address);

  expect(endingRangeDetails.start).to.equal(
    totalEligibleTicketsBefore.add(weiAmount).add(user5weiAmount).add(1)
  );

  expect(endingRangeDetails.indexInUserRanges).to.equal(0);

  // Now user5 is staking
  ethAmount = "30";
  const user5weiAmount2 = ethers.utils.parseEther(ethAmount);
  await prizePool
    .connect(deployer)
    .getTickets(user5.address, user5weiAmount2, [], []);

  totalEligibleTicketsAfter = await prizePool.totalEligibleForThisDraw();
  totalTicketsAfter = await prizePool.totalTicketNumber();

  expect(totalEligibleTicketsAfter).to.equal(totalEligibleTicketsBefore);
  expect(totalTicketsAfter).to.equal(
    totalTicketsBefore
      .add(weiAmount)
      .add(user5weiAmount)
      .add(user6weiAmount)
      .add(user5weiAmount2)
  );

  // Ending range will be current total eligible tickets number
  endingRangeDetails = await prizePool.getDetailsFromEndingRange(
    totalTicketsAfter
  );

  expect(endingRangeDetails.userAddress).to.equal(user5.address);

  expect(endingRangeDetails.start).to.equal(
    totalEligibleTicketsBefore
      .add(weiAmount)
      .add(user5weiAmount)
      .add(user6weiAmount)
      .add(1)
  );

  expect(endingRangeDetails.indexInUserRanges).to.equal(1);
}

async function unstakeEligible() {
  // U2 unstakes some tokens

  let ethAmount = "5";
  const user2UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

  let totalEmptyRanges = await prizePool.totalEmptyRanges();

  expect(totalEmptyRanges).to.equal(0);

  let totalEligibleForThisDrawBeforeBurn =
    await prizePool.totalEligibleForThisDraw();

  let totalTicketNumberBeforeBurn = await prizePool.totalTicketNumber();

  let userRangeDetail = await prizePool.getRangeDetails(user2.address, 0);

  expect(userRangeDetail.start).to.equal("100000000000000000001");
  expect(userRangeDetail.end).to.equal("112000000000000000000");

  await prizePool
    .connect(deployer)
    .burnTickets(user2.address, user2UnstakeWeiAmount);

  // As it is middle slot so total eligible tickets will not decrease
  // Empty ticket slots will be pushed to emptyRange array
  // Shuffling will not happen as it only happens after cycleStartTime + cooldown period

  const totalUser2Ranges = await prizePool.totalUserRanges(user2.address);

  expect(totalUser2Ranges).to.equal(1);

  totalEmptyRanges = await prizePool.totalEmptyRanges();

  expect(totalEmptyRanges).to.equal(1);

  let totalEligibleForThisDrawAfterBurn =
    await prizePool.totalEligibleForThisDraw();

  let totalTicketNumberAfterBurn = await prizePool.totalTicketNumber();

  expect(totalEligibleForThisDrawAfterBurn).to.equal(
    totalEligibleForThisDrawBeforeBurn
  );

  expect(totalTicketNumberAfterBurn).to.equal(totalTicketNumberBeforeBurn);

  let emptyRangeDetail = await prizePool.getEmptyRangeDetail(0);
  expect(emptyRangeDetail.start).to.equal("107000000000000000001");
  expect(emptyRangeDetail.end).to.equal("112000000000000000000");

  userRangeDetail = await prizePool.getRangeDetails(user2.address, 0);

  expect(userRangeDetail.start).to.equal("100000000000000000001");
  expect(userRangeDetail.end).to.equal("107000000000000000000");

  let emptyRangesIndex = await prizePool.emptyRangesIndex(emptyRangeDetail.end);

  expect(emptyRangesIndex).to.equal(0);

  // User 3 unstake 9 tokens

  ethAmount = "9";
  const user3UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

  totalEmptyRanges = await prizePool.totalEmptyRanges();

  expect(totalEmptyRanges).to.equal(1);

  totalEligibleForThisDrawBeforeBurn =
    await prizePool.totalEligibleForThisDraw();

  totalTicketNumberBeforeBurn = await prizePool.totalTicketNumber();

  userRangeDetail = await prizePool.getRangeDetails(user3.address, 0);

  expect(userRangeDetail.start).to.equal("112000000000000000001");
  expect(userRangeDetail.end).to.equal("135000000000000000000");

  await prizePool
    .connect(deployer)
    .burnTickets(user3.address, user3UnstakeWeiAmount);

  // As it is middle slot so total eligible tickets will not decrease
  // Empty ticket slots will be pushed to emptyRange array
  // Shuffling will not happen as it only happens after cycleStartTime + cooldown period

  const totalUser3Ranges = await prizePool.totalUserRanges(user3.address);

  expect(totalUser3Ranges).to.equal(1);

  totalEmptyRanges = await prizePool.totalEmptyRanges();

  expect(totalEmptyRanges).to.equal(2);

  totalEligibleForThisDrawAfterBurn =
    await prizePool.totalEligibleForThisDraw();

  totalTicketNumberAfterBurn = await prizePool.totalTicketNumber();

  expect(totalEligibleForThisDrawAfterBurn).to.equal(
    totalEligibleForThisDrawBeforeBurn
  );

  expect(totalTicketNumberAfterBurn).to.equal(totalTicketNumberBeforeBurn);

  emptyRangeDetail = await prizePool.getEmptyRangeDetail(1);
  expect(emptyRangeDetail.start).to.equal("126000000000000000001");
  expect(emptyRangeDetail.end).to.equal("135000000000000000000");

  userRangeDetail = await prizePool.getRangeDetails(user3.address, 0);

  expect(userRangeDetail.start).to.equal("112000000000000000001");
  expect(userRangeDetail.end).to.equal("126000000000000000000");

  emptyRangesIndex = await prizePool.emptyRangesIndex(emptyRangeDetail.end);

  expect(emptyRangesIndex).to.equal(1);
}

async function unstakeEligibleForShuffle() {
  // U2 unstakes some tokens

  let ethAmount = "5";
  const user2UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

  let totalEmptyRanges = await prizePool.totalEmptyRanges();

  expect(totalEmptyRanges).to.equal(0);

  let totalEligibleForThisDrawBeforeBurn =
    await prizePool.totalEligibleForThisDraw();

  let totalTicketNumberBeforeBurn = await prizePool.totalTicketNumber();

  let userRangeDetail = await prizePool.getRangeDetails(user2.address, 0);

  expect(userRangeDetail.start).to.equal("1000000000000000000001");
  expect(userRangeDetail.end).to.equal("1012000000000000000000");

  await prizePool
    .connect(deployer)
    .burnTickets(user2.address, user2UnstakeWeiAmount);

  // As it is middle slot so total eligible tickets will not decrease
  // Empty ticket slots will be pushed to emptyRange array
  // Shuffling will not happen as it only happens after cycleStartTime + cooldown period

  const totalUser2Ranges = await prizePool.totalUserRanges(user2.address);

  expect(totalUser2Ranges).to.equal(1);

  totalEmptyRanges = await prizePool.totalEmptyRanges();

  expect(totalEmptyRanges).to.equal(1);

  let totalEligibleForThisDrawAfterBurn =
    await prizePool.totalEligibleForThisDraw();

  let totalTicketNumberAfterBurn = await prizePool.totalTicketNumber();

  expect(totalEligibleForThisDrawAfterBurn).to.equal(
    totalEligibleForThisDrawBeforeBurn
  );

  expect(totalTicketNumberAfterBurn).to.equal(totalTicketNumberBeforeBurn);

  let emptyRangeDetail = await prizePool.getEmptyRangeDetail(0);
  expect(emptyRangeDetail.start).to.equal("1007000000000000000001");
  expect(emptyRangeDetail.end).to.equal("1012000000000000000000");

  userRangeDetail = await prizePool.getRangeDetails(user2.address, 0);

  expect(userRangeDetail.start).to.equal("1000000000000000000001");
  expect(userRangeDetail.end).to.equal("1007000000000000000000");

  // User 3 unstake 9 tokens

  ethAmount = "9";
  const user3UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

  totalEmptyRanges = await prizePool.totalEmptyRanges();

  expect(totalEmptyRanges).to.equal(1);

  totalEligibleForThisDrawBeforeBurn =
    await prizePool.totalEligibleForThisDraw();

  totalTicketNumberBeforeBurn = await prizePool.totalTicketNumber();

  userRangeDetail = await prizePool.getRangeDetails(user3.address, 0);

  expect(userRangeDetail.start).to.equal("1012000000000000000001");
  expect(userRangeDetail.end).to.equal("1242000000000000000000");

  await prizePool
    .connect(deployer)
    .burnTickets(user3.address, user3UnstakeWeiAmount);

  // As it is middle slot so total eligible tickets will not decrease
  // Empty ticket slots will be pushed to emptyRange array
  // Shuffling will not happen as it only happens after cycleStartTime + cooldown period

  const totalUser3Ranges = await prizePool.totalUserRanges(user3.address);

  expect(totalUser3Ranges).to.equal(1);

  totalEmptyRanges = await prizePool.totalEmptyRanges();

  expect(totalEmptyRanges).to.equal(2);

  totalEligibleForThisDrawAfterBurn =
    await prizePool.totalEligibleForThisDraw();

  totalTicketNumberAfterBurn = await prizePool.totalTicketNumber();

  expect(totalEligibleForThisDrawAfterBurn).to.equal(
    totalEligibleForThisDrawBeforeBurn
  );

  expect(totalTicketNumberAfterBurn).to.equal(totalTicketNumberBeforeBurn);

  emptyRangeDetail = await prizePool.getEmptyRangeDetail(1);
  expect(emptyRangeDetail.start).to.equal("1233000000000000000001");
  expect(emptyRangeDetail.end).to.equal("1242000000000000000000");

  userRangeDetail = await prizePool.getRangeDetails(user3.address, 0);

  expect(userRangeDetail.start).to.equal("1012000000000000000001");
  expect(userRangeDetail.end).to.equal("1233000000000000000000");
}

async function unstakeNonEligible() {
  let totalEmptyRanges = await prizePool.totalEmptyRanges();

  expect(totalEmptyRanges).to.equal(0);

  // u4 is unstaking

  let ethAmount = "4";
  const user4UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

  let totalEligibleForThisDrawBeforeBurn =
    await prizePool.totalEligibleForThisDraw();

  let totalTicketNumberBeforeBurn = await prizePool.totalTicketNumber();

  let userRangeDetail = await prizePool.getRangeDetails(user4.address, 0);

  expect(userRangeDetail.start).to.equal("222000000000000000001");
  expect(userRangeDetail.end).to.equal("262000000000000000000");

  await prizePool
    .connect(deployer)
    .burnTickets(user4.address, user4UnstakeWeiAmount);

  // As it is middle slot so total tickets will not decrease
  // Empty ticket slots will be pushed to emptyRange array

  const totalUser4Ranges = await prizePool.totalUserRanges(user4.address);

  expect(totalUser4Ranges).to.equal(1);

  totalEmptyRanges = await prizePool.totalEmptyRanges();

  expect(totalEmptyRanges).to.equal(1);

  let totalEligibleForThisDrawAfterBurn =
    await prizePool.totalEligibleForThisDraw();

  let totalTicketNumberAfterBurn = await prizePool.totalTicketNumber();

  expect(totalEligibleForThisDrawAfterBurn).to.equal(
    totalEligibleForThisDrawBeforeBurn
  );

  expect(totalTicketNumberAfterBurn).to.equal(totalTicketNumberBeforeBurn);

  const emptyRangeDetail = await prizePool.getEmptyRangeDetail(0);
  expect(emptyRangeDetail.start).to.equal("258000000000000000001");
  expect(emptyRangeDetail.end).to.equal("262000000000000000000");

  const emptyRangeIndex = await prizePool.emptyRangesIndex(
    emptyRangeDetail.end
  );

  expect(emptyRangeIndex).to.equal(0);

  userRangeDetail = await prizePool.getRangeDetails(user4.address, 0);

  expect(userRangeDetail.start).to.equal("222000000000000000001");
  expect(userRangeDetail.end).to.equal("258000000000000000000");

  // u6 is unstaking

  ethAmount = "28";
  const user6UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

  totalEligibleForThisDrawBeforeBurn =
    await prizePool.totalEligibleForThisDraw();

  totalTicketNumberBeforeBurn = await prizePool.totalTicketNumber();

  userRangeDetail = await prizePool.getRangeDetails(user6.address, 0);

  expect(userRangeDetail.start).to.equal("412000000000000000001");
  expect(userRangeDetail.end).to.equal("500000000000000000000");

  await prizePool
    .connect(deployer)
    .burnTickets(user6.address, user6UnstakeWeiAmount);

  // As it is middle slot so total tickets will not decrease
  // Empty ticket slots will be pushed to emptyRange array

  const totalUser6Ranges = await prizePool.totalUserRanges(user6.address);

  expect(totalUser6Ranges).to.equal(1);

  totalEmptyRanges = await prizePool.totalEmptyRanges();

  expect(totalEmptyRanges).to.equal(2);

  totalEligibleForThisDrawAfterBurn =
    await prizePool.totalEligibleForThisDraw();

  totalTicketNumberAfterBurn = await prizePool.totalTicketNumber();

  expect(totalEligibleForThisDrawAfterBurn).to.equal(
    totalEligibleForThisDrawBeforeBurn
  );

  expect(totalTicketNumberAfterBurn).to.equal(totalTicketNumberBeforeBurn);

  const emptyRangeDetail1 = await prizePool.getEmptyRangeDetail(0);
  expect(emptyRangeDetail1.start).to.equal("258000000000000000001");
  expect(emptyRangeDetail1.end).to.equal("262000000000000000000");

  const emptyRangeDetail2 = await prizePool.getEmptyRangeDetail(1);
  expect(emptyRangeDetail2.start).to.equal("472000000000000000001");
  expect(emptyRangeDetail2.end).to.equal("500000000000000000000");

  const emptyRange2Index = await prizePool.emptyRangesIndex(
    emptyRangeDetail2.end
  );

  expect(emptyRange2Index).to.equal(1);

  userRangeDetail = await prizePool.getRangeDetails(user6.address, 0);

  expect(userRangeDetail.start).to.equal("412000000000000000001");
  expect(userRangeDetail.end).to.equal("472000000000000000000");
}

describe("Prize Pool test", () => {
  beforeEach(async () => {
    [deployer, user1, user2, user3, user4, user5, user6, user7, user8, user9] =
      await ethers.getSigners();
    // Set Ether balances
    const initialBalance = ethers.utils.parseEther("100000"); // Set initial balance to 1000 ETH

    await setBalance(deployer.address, initialBalance);
    await setBalance(user1.address, initialBalance);
    await setBalance(user2.address, initialBalance);
    await setBalance(user3.address, initialBalance);
    await setBalance(user4.address, initialBalance);
    await setBalance(user5.address, initialBalance);
    await setBalance(user6.address, initialBalance);
    await setBalance(user7.address, initialBalance);
    await setBalance(user8.address, initialBalance);
    await setBalance(user9.address, initialBalance);
  });

  describe("Eligible slots", () => {
    beforeEach(async () => {
      WinWin = await ethers.getContractFactory("WinToken");
      winToken = await WinWin.deploy("10000000000000");

      const lastTimestamp = (await waffle.provider.getBlock("latest"))
        .timestamp;

      WinStakingPool = await ethers.getContractFactory("WinStakingPool");

      winStakingPool = await WinStakingPool.deploy(
        winToken.address,
        lastTimestamp,
        "1000000000"
      );

      PrizePoolContract = await ethers.getContractFactory(
        "PrizePool",
        deployer
      );
      const prizeDistribution = [6000, 900, 600, 300, 100, 2100];
      prizePool = await PrizePoolContract.deploy(
        lastTimestamp + 100,
        deployer.address,
        prizeDistribution
      );
    });

    it("If users are staking before cycle start time of the draw then they will be eligible for the draw", async () => {
      const ethAmount = "100";
      const weiAmount = ethers.utils.parseEther(ethAmount);
      await prizePool
        .connect(deployer)
        .getTickets(user1.address, weiAmount, [], []);

      const totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
      const totalTickets = await prizePool.totalTicketNumber();

      expect(totalEligibleTickets).to.equal(weiAmount);
      expect(totalTickets).to.equal(weiAmount);

      // Ending range will be current total eligible tickets number
      const endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        totalEligibleTickets
      );

      expect(endingRangeDetails.userAddress).to.equal(user1.address);

      expect(endingRangeDetails.start).to.equal(1);

      expect(endingRangeDetails.indexInUserRanges).to.equal(0);
    });

    it("Multiple users with multiple stakes before cycle start time", async () => {
      await multipleEligibleStakes();
    });

    it("Multiple users with multiple stakes and unstakes before cycle start time", async () => {
      await multipleEligibleStakes();
      await unstakeEligible();
    });

    it("Multiple stakes and withdraw from last slot", async () => {
      await multipleEligibleStakes();
      // As U1 has last ticket slot

      const ethAmount = "10";
      const user1UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

      let totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(0);

      const totalEligibleForThisDrawBeforeBurn =
        await prizePool.totalEligibleForThisDraw();

      const totalTicketNumberBeforeBurn = await prizePool.totalTicketNumber();

      let userRangeDetail = await prizePool.getRangeDetails(user1.address, 1);

      expect(userRangeDetail.start).to.equal("135000000000000000001");
      expect(userRangeDetail.end).to.equal("222000000000000000000");

      await prizePool
        .connect(deployer)
        .burnTickets(user1.address, user1UnstakeWeiAmount);

      // As it is last  slot so total eligible tickets and total ticket number will  decrease
      // it will not be pushed to empty range array

      const totalUser1Ranges = await prizePool.totalUserRanges(user1.address);

      expect(totalUser1Ranges).to.equal(2);

      totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(0);

      const totalEligibleForThisDrawAfterBurn =
        await prizePool.totalEligibleForThisDraw();

      const totalTicketNumberAfterBurn = await prizePool.totalTicketNumber();

      expect(
        totalEligibleForThisDrawAfterBurn.add(user1UnstakeWeiAmount)
      ).to.equal(totalEligibleForThisDrawBeforeBurn);

      expect(totalTicketNumberAfterBurn.add(user1UnstakeWeiAmount)).to.equal(
        totalTicketNumberBeforeBurn
      );

      userRangeDetail = await prizePool.getRangeDetails(user1.address, 1);

      expect(userRangeDetail.start).to.equal("135000000000000000001");
      expect(userRangeDetail.end).to.equal("212000000000000000000");
    });

    it("Multiple stakes and unstakes and one slots filling during stakes", async () => {
      await multipleEligibleStakes();
      await unstakeEligible();

      const ethAmount = "5";
      const user4WeiAmount = ethers.utils.parseEther(ethAmount);

      const totalEligibleTicketsBefore =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsBefore = await prizePool.totalTicketNumber();

      let emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(2);

      let emptyRangeDetail = await prizePool.getEmptyRangeDetail(0);
      expect(emptyRangeDetail.start).to.equal("107000000000000000001");
      expect(emptyRangeDetail.end).to.equal("112000000000000000000");

      const emptyRange2Detail = await prizePool.getEmptyRangeDetail(1);
      expect(emptyRange2Detail.start).to.equal("126000000000000000001");
      expect(emptyRange2Detail.end).to.equal("135000000000000000000");

      let indexInEmptyArray = await prizePool.emptyRangesIndex(
        emptyRange2Detail.end
      );
      expect(indexInEmptyArray).to.equal(1);

      let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRangeDetail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      await prizePool
        .connect(deployer)
        .getTickets(user4.address, user4WeiAmount, [0], []); // 0th slot

      emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(1);

      const totalEligibleTicketsAfter =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsAfter = await prizePool.totalTicketNumber();

      expect(totalEligibleTicketsBefore).to.equal(totalEligibleTicketsAfter);
      expect(totalTicketsBefore).to.equal(totalTicketsAfter);

      // Ending range will be current total eligible tickets number
      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRangeDetail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user4.address);

      expect(endingRangeDetails.start).to.equal(emptyRangeDetail.start);

      expect(endingRangeDetails.indexInUserRanges).to.equal(0);

      emptyRangeDetail = await prizePool.getEmptyRangeDetail(0);
      expect(emptyRangeDetail.start).to.equal(emptyRange2Detail.start);
      expect(emptyRangeDetail.end).to.equal(emptyRange2Detail.end);

      indexInEmptyArray = await prizePool.emptyRangesIndex(
        emptyRange2Detail.end
      );
      expect(indexInEmptyArray).to.equal(0);
    });

    it("Multiple stakes and unstakes and multiple slots filling during stake(1)", async () => {
      await multipleEligibleStakes();
      await unstakeEligible();

      const ethAmount = "10";
      const user4WeiAmount = ethers.utils.parseEther(ethAmount);

      const totalEligibleTicketsBefore =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsBefore = await prizePool.totalTicketNumber();

      let emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(2);

      const emptyRange1Detail = await prizePool.getEmptyRangeDetail(0);
      expect(emptyRange1Detail.start).to.equal("107000000000000000001");
      expect(emptyRange1Detail.end).to.equal("112000000000000000000");

      const emptyRangeIndex = await prizePool.emptyRangesIndex(
        emptyRange1Detail.end
      );

      expect(emptyRangeIndex).to.equal(0);

      let emptyRange2Detail = await prizePool.getEmptyRangeDetail(1);
      expect(emptyRange2Detail.start).to.equal("126000000000000000001");
      expect(emptyRange2Detail.end).to.equal("135000000000000000000");

      let emptyRange2Index = await prizePool.emptyRangesIndex(
        emptyRange2Detail.end
      );

      expect(emptyRange2Index).to.equal(1);

      let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRange1Detail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      let endingRange2Details = await prizePool.getDetailsFromEndingRange(
        emptyRange2Detail.end
      );

      expect(endingRange2Details.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      await prizePool
        .connect(deployer)
        .getTickets(user4.address, user4WeiAmount, [0, 1], []); // 0th slot

      emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(1);

      const totalEligibleTicketsAfter =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsAfter = await prizePool.totalTicketNumber();

      expect(totalEligibleTicketsBefore).to.equal(totalEligibleTicketsAfter);
      expect(totalTicketsBefore).to.equal(totalTicketsAfter);

      // Ending range will be current total eligible tickets number
      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRange1Detail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user4.address);

      expect(endingRangeDetails.start).to.equal(emptyRange1Detail.start);

      expect(endingRangeDetails.indexInUserRanges).to.equal(0);

      endingRange2Details = await prizePool.getDetailsFromEndingRange(
        "131000000000000000000"
      );

      expect(endingRange2Details.userAddress).to.equal(user4.address);

      expect(endingRange2Details.start).to.equal(emptyRange2Detail.start);

      expect(endingRange2Details.indexInUserRanges).to.equal(1);

      emptyRange2Detail = await prizePool.getEmptyRangeDetail(0);

      expect(emptyRange2Detail.start).to.equal("131000000000000000001");
      expect(emptyRange2Detail.end).to.equal("135000000000000000000");

      emptyRange2Index = await prizePool.emptyRangesIndex(
        emptyRange2Detail.end
      );

      expect(emptyRange2Index).to.equal(0);
    });

    it("Multiple stakes and unstakes and multiple slots filling during stake(2)", async () => {
      await multipleEligibleStakes();
      await unstakeEligible();

      const ethAmount = "15";
      const user4WeiAmount = ethers.utils.parseEther(ethAmount);

      const totalEligibleTicketsBefore =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsBefore = await prizePool.totalTicketNumber();

      let emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(2);

      const emptyRange1Detail = await prizePool.getEmptyRangeDetail(0);
      expect(emptyRange1Detail.start).to.equal("107000000000000000001");
      expect(emptyRange1Detail.end).to.equal("112000000000000000000");

      let emptyRangeIndex = await prizePool.emptyRangesIndex(
        emptyRange1Detail.end
      );

      expect(emptyRangeIndex).to.equal(0);

      const emptyRange2Detail = await prizePool.getEmptyRangeDetail(1);
      expect(emptyRange2Detail.start).to.equal("126000000000000000001");
      expect(emptyRange2Detail.end).to.equal("135000000000000000000");

      let emptyRange2Index = await prizePool.emptyRangesIndex(
        emptyRange2Detail.end
      );

      expect(emptyRange2Index).to.equal(1);

      let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRange1Detail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      await prizePool
        .connect(deployer)
        .getTickets(user4.address, user4WeiAmount, [0, 1], []); // 0th slot

      emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(0);

      const totalEligibleTicketsAfter =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsAfter = await prizePool.totalTicketNumber();

      const extraStake = ethers.utils.parseEther("1");
      expect(totalEligibleTicketsBefore.add(extraStake)).to.equal(
        totalEligibleTicketsAfter
      );
      expect(totalTicketsBefore.add(extraStake)).to.equal(totalTicketsAfter);

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRange1Detail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user4.address);

      expect(endingRangeDetails.start).to.equal(emptyRange1Detail.start);

      expect(endingRangeDetails.indexInUserRanges).to.equal(0);

      const endingRange2Details = await prizePool.getDetailsFromEndingRange(
        emptyRange2Detail.end
      );

      expect(endingRange2Details.userAddress).to.equal(user4.address);

      expect(endingRange2Details.start).to.equal(emptyRange2Detail.start);

      expect(endingRange2Details.indexInUserRanges).to.equal(1);

      const endingRange3Details = await prizePool.getDetailsFromEndingRange(
        totalEligibleTicketsAfter
      );

      expect(endingRange3Details.userAddress).to.equal(user4.address);

      expect(endingRange3Details.start).to.equal(
        totalEligibleTicketsBefore.add(1)
      );

      expect(endingRange3Details.indexInUserRanges).to.equal(2);

      emptyRangeIndex = await prizePool.emptyRangesIndex(emptyRange1Detail.end);

      expect(emptyRangeIndex).to.equal(0);

      emptyRange2Index = await prizePool.emptyRangesIndex(
        emptyRange2Detail.end
      );

      expect(emptyRange2Index).to.equal(0);
    });
  });

  describe("Non Eligible slots", () => {
    beforeEach(async () => {
      WinWin = await ethers.getContractFactory("WinToken");
      winToken = await WinWin.deploy("10000000000000");

      const lastTimestamp = (await waffle.provider.getBlock("latest"))
        .timestamp;

      WinStakingPool = await ethers.getContractFactory("WinStakingPool");

      winStakingPool = await WinStakingPool.deploy(
        winToken.address,
        lastTimestamp,
        "1000000000"
      );

      PrizePoolContract = await ethers.getContractFactory(
        "PrizePool",
        deployer
      );
      const prizeDistribution = [6000, 900, 600, 300, 100, 2100];
      prizePool = await PrizePoolContract.deploy(
        lastTimestamp + 50,
        deployer.address,
        prizeDistribution
      );
    });

    it("User are staking after start of the cycle so they will be not eligible for current draw", async () => {
      await multipleEligibleStakes();

      // forwarding 50 seconds to start cycle
      await forward(50);

      const totalEligibleTicketsBefore =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsBefore = await prizePool.totalTicketNumber();

      expect(totalEligibleTicketsBefore).to.equal(totalTicketsBefore);

      // Now user4 is staking
      const ethAmount = "40";
      const weiAmount = ethers.utils.parseEther(ethAmount);
      await prizePool
        .connect(deployer)
        .getTickets(user4.address, weiAmount, [], []);

      const totalEligibleTicketsAfter =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsAfter = await prizePool.totalTicketNumber();

      expect(totalEligibleTicketsAfter).to.equal(totalEligibleTicketsBefore);
      expect(totalTicketsAfter).to.equal(totalTicketsBefore.add(weiAmount));

      const totalEligibleDetails = await prizePool.getDetailsFromEndingRange(
        totalEligibleTicketsAfter
      );

      expect(totalEligibleDetails.userAddress).to.equal(user1.address);

      expect(totalEligibleDetails.indexInUserRanges).to.equal(1);

      // Ending range will be current total eligible tickets number
      const endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        totalTicketsAfter
      );

      expect(endingRangeDetails.userAddress).to.equal(user4.address);

      expect(endingRangeDetails.start).to.equal(
        totalEligibleTicketsBefore.add(1)
      );

      expect(endingRangeDetails.indexInUserRanges).to.equal(0);
    });

    it("Multiple users are staking after start of the cycle", async () => {
      await multipleEligibleStakes();

      // forwarding 50 seconds to start cycle
      await forward(50);

      await multipleNonEligibleStakes();

      // User with both eligible and non eligible
      const totalEligibleTicketsBefore =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsBefore = await prizePool.totalTicketNumber();

      // Now user2 is staking
      const ethAmount = "60";
      const user2weiAmount2 = ethers.utils.parseEther(ethAmount);
      await prizePool
        .connect(deployer)
        .getTickets(user2.address, user2weiAmount2, [], []);

      const totalEligibleTicketsAfter =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsAfter = await prizePool.totalTicketNumber();

      expect(totalEligibleTicketsAfter).to.equal(totalEligibleTicketsBefore);
      expect(totalTicketsAfter).to.equal(
        totalTicketsBefore.add(user2weiAmount2)
      );

      const endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        totalTicketsAfter
      );

      expect(endingRangeDetails.userAddress).to.equal(user2.address);

      expect(endingRangeDetails.start).to.equal(totalTicketsBefore.add(1));

      expect(endingRangeDetails.indexInUserRanges).to.equal(1);
    });

    it("Multiple non eligible stakes and unstakes", async () => {
      await multipleEligibleStakes();

      // forwarding 50 seconds to start cycle
      await forward(50);

      await multipleNonEligibleStakes();

      let totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(0);

      // u4 is unstaking

      const ethAmount = "4";
      const user4UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

      const totalEligibleForThisDrawBeforeBurn =
        await prizePool.totalEligibleForThisDraw();

      const totalTicketNumberBeforeBurn = await prizePool.totalTicketNumber();

      let userRangeDetail = await prizePool.getRangeDetails(user4.address, 0);

      expect(userRangeDetail.start).to.equal("222000000000000000001");
      expect(userRangeDetail.end).to.equal("262000000000000000000");

      await prizePool
        .connect(deployer)
        .burnTickets(user4.address, user4UnstakeWeiAmount);

      // As it is middle slot so total tickets will not decrease
      // Empty ticket slots will be pushed to emptyRange array

      const totalUser4Ranges = await prizePool.totalUserRanges(user4.address);

      expect(totalUser4Ranges).to.equal(1);

      totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(1);

      const totalEligibleForThisDrawAfterBurn =
        await prizePool.totalEligibleForThisDraw();

      const totalTicketNumberAfterBurn = await prizePool.totalTicketNumber();

      expect(totalEligibleForThisDrawAfterBurn).to.equal(
        totalEligibleForThisDrawBeforeBurn
      );

      expect(totalTicketNumberAfterBurn).to.equal(totalTicketNumberBeforeBurn);

      const emptyRangeDetail = await prizePool.getEmptyRangeDetail(0);
      expect(emptyRangeDetail.start).to.equal("258000000000000000001");
      expect(emptyRangeDetail.end).to.equal("262000000000000000000");

      const emptyRangeIndex = await prizePool.emptyRangesIndex(
        emptyRangeDetail.end
      );

      expect(emptyRangeIndex).to.equal(0);

      userRangeDetail = await prizePool.getRangeDetails(user4.address, 0);

      expect(userRangeDetail.start).to.equal("222000000000000000001");
      expect(userRangeDetail.end).to.equal("258000000000000000000");
    });

    it("Multiple non eligible stakes and multiple unstakes", async () => {
      await multipleEligibleStakes();

      // forwarding 50 seconds to start cycle
      await forward(50);

      await multipleNonEligibleStakes();

      await unstakeNonEligible();
    });

    it("Multiple non eligible stakes and unstake the last slot", async () => {
      await multipleEligibleStakes();

      // forwarding 50 seconds to start cycle
      await forward(50);

      await multipleNonEligibleStakes();

      // As U5 has last ticket slot

      const ethAmount = "27";
      const user5UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

      let totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(0);

      const totalEligibleForThisDrawBeforeBurn =
        await prizePool.totalEligibleForThisDraw();

      const totalTicketNumberBeforeBurn = await prizePool.totalTicketNumber();

      let userRangeDetail = await prizePool.getRangeDetails(user5.address, 1);

      expect(userRangeDetail.start).to.equal("500000000000000000001");
      expect(userRangeDetail.end).to.equal("530000000000000000000");

      await prizePool
        .connect(deployer)
        .burnTickets(user5.address, user5UnstakeWeiAmount);

      // As it is last  slot so total ticket number will  decrease
      // it will not be pushed to empty range array

      const totalUser5Ranges = await prizePool.totalUserRanges(user5.address);

      expect(totalUser5Ranges).to.equal(2);

      totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(0);

      const totalEligibleForThisDrawAfterBurn =
        await prizePool.totalEligibleForThisDraw();

      const totalTicketNumberAfterBurn = await prizePool.totalTicketNumber();

      expect(totalEligibleForThisDrawAfterBurn).to.equal(
        totalEligibleForThisDrawBeforeBurn
      );

      expect(totalTicketNumberAfterBurn.add(user5UnstakeWeiAmount)).to.equal(
        totalTicketNumberBeforeBurn
      );

      userRangeDetail = await prizePool.getRangeDetails(user5.address, 1);

      expect(userRangeDetail.start).to.equal("500000000000000000001");
      expect(userRangeDetail.end).to.equal("503000000000000000000");
    });

    it("Multiple non eligible stakes and unstake and full slot filling", async () => {
      await multipleEligibleStakes();

      // forwarding 50 seconds to start cycle
      await forward(50);

      await multipleNonEligibleStakes();

      await unstakeNonEligible();

      // U5 is staking

      const ethAmount = "4";
      const user5WeiAmount = ethers.utils.parseEther(ethAmount);

      const totalEligibleTicketsBefore =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsBefore = await prizePool.totalTicketNumber();

      let emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(2);

      const emptyRangeDetail = await prizePool.getEmptyRangeDetail(0);
      expect(emptyRangeDetail.start).to.equal("258000000000000000001");
      expect(emptyRangeDetail.end).to.equal("262000000000000000000");

      const emptyRange2Detail = await prizePool.getEmptyRangeDetail(1);
      expect(emptyRange2Detail.start).to.equal("472000000000000000001");
      expect(emptyRange2Detail.end).to.equal("500000000000000000000");

      let emptyRangesIndex = await prizePool.emptyRangesIndex(
        emptyRange2Detail.end
      );
      expect(emptyRangesIndex).to.equal(1);

      let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRangeDetail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      await prizePool
        .connect(deployer)
        .getTickets(user5.address, user5WeiAmount, [0], []); // 0th slot

      emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(1);

      const totalEligibleTicketsAfter =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsAfter = await prizePool.totalTicketNumber();

      expect(totalEligibleTicketsBefore).to.equal(totalEligibleTicketsAfter);
      expect(totalTicketsBefore).to.equal(totalTicketsAfter);

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRangeDetail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user5.address);

      expect(endingRangeDetails.start).to.equal(emptyRangeDetail.start);

      expect(endingRangeDetails.indexInUserRanges).to.equal(2);

      emptyRangesIndex = await prizePool.emptyRangesIndex(
        emptyRange2Detail.end
      );
      expect(emptyRangesIndex).to.equal(0);
    });

    it("Multiple non eligible stakes and unstake and partial slot filling", async () => {
      await multipleEligibleStakes();

      // forwarding 50 seconds to start cycle
      await forward(50);

      await multipleNonEligibleStakes();

      await unstakeNonEligible();

      // U5 is staking

      const ethAmount = "2";
      const user5WeiAmount = ethers.utils.parseEther(ethAmount);

      const totalEligibleTicketsBefore =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsBefore = await prizePool.totalTicketNumber();

      let emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(2);

      const emptyRangeDetail = await prizePool.getEmptyRangeDetail(0);
      expect(emptyRangeDetail.start).to.equal("258000000000000000001");
      expect(emptyRangeDetail.end).to.equal("262000000000000000000");

      let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRangeDetail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      await prizePool
        .connect(deployer)
        .getTickets(user5.address, user5WeiAmount, [0], []); // 0th slot

      emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(2);

      const totalEligibleTicketsAfter =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsAfter = await prizePool.totalTicketNumber();

      expect(totalEligibleTicketsBefore).to.equal(totalEligibleTicketsAfter);
      expect(totalTicketsBefore).to.equal(totalTicketsAfter);

      // Ending range will be current total eligible tickets number
      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRangeDetail.start.add(user5WeiAmount).sub(1)
      );

      expect(endingRangeDetails.userAddress).to.equal(user5.address);

      expect(endingRangeDetails.start).to.equal(emptyRangeDetail.start);

      expect(endingRangeDetails.indexInUserRanges).to.equal(2);

      const updatedEmptyRangeDetail = await prizePool.getEmptyRangeDetail(0);

      expect(updatedEmptyRangeDetail.start).to.equal(
        emptyRangeDetail.start.add(user5WeiAmount)
      );
      expect(updatedEmptyRangeDetail.end).to.equal("262000000000000000000");
    });

    it("Multiple non eligible stakes and unstakes and multiple slots filling during stake(1)", async () => {
      await multipleEligibleStakes();

      // forwarding 50 seconds to start cycle
      await forward(50);

      await multipleNonEligibleStakes();

      await unstakeNonEligible();

      const ethAmount = "30";
      const user7WeiAmount = ethers.utils.parseEther(ethAmount);

      const totalEligibleTicketsBefore =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsBefore = await prizePool.totalTicketNumber();

      let emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(2);

      const emptyRange1Detail = await prizePool.getEmptyRangeDetail(0);
      expect(emptyRange1Detail.start).to.equal("258000000000000000001");
      expect(emptyRange1Detail.end).to.equal("262000000000000000000");

      let emptyRange2Detail = await prizePool.getEmptyRangeDetail(1);
      expect(emptyRange2Detail.start).to.equal("472000000000000000001");
      expect(emptyRange2Detail.end).to.equal("500000000000000000000");

      let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRange1Detail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      await prizePool
        .connect(deployer)
        .getTickets(user7.address, user7WeiAmount, [0, 1], []); // 0th slot

      emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(1);

      const totalEligibleTicketsAfter =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsAfter = await prizePool.totalTicketNumber();

      expect(totalEligibleTicketsBefore).to.equal(totalEligibleTicketsAfter);
      expect(totalTicketsBefore).to.equal(totalTicketsAfter);

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRange1Detail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user7.address);

      expect(endingRangeDetails.start).to.equal(emptyRange1Detail.start);

      expect(endingRangeDetails.indexInUserRanges).to.equal(0);

      const endingRange2Details = await prizePool.getDetailsFromEndingRange(
        "498000000000000000000"
      );

      expect(endingRange2Details.userAddress).to.equal(user7.address);

      expect(endingRange2Details.start).to.equal(emptyRange2Detail.start);

      expect(endingRange2Details.indexInUserRanges).to.equal(1);

      emptyRange2Detail = await prizePool.getEmptyRangeDetail(0);

      expect(emptyRange2Detail.start).to.equal("498000000000000000001");
      expect(emptyRange2Detail.end).to.equal("500000000000000000000");

      const emptyRangeIndex = await prizePool.emptyRangesIndex(
        emptyRange2Detail.end
      );

      expect(emptyRangeIndex).to.equal(0);
    });

    it("Multiple non eligible stakes and unstakes and multiple slots filling during stake(2)", async () => {
      await multipleEligibleStakes();

      // forwarding 50 seconds to start cycle
      await forward(50);

      await multipleNonEligibleStakes();

      await unstakeNonEligible();

      const ethAmount = "32";
      const user7WeiAmount = ethers.utils.parseEther(ethAmount);

      const totalEligibleTicketsBefore =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsBefore = await prizePool.totalTicketNumber();

      let emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(2);

      const emptyRange1Detail = await prizePool.getEmptyRangeDetail(0);
      expect(emptyRange1Detail.start).to.equal("258000000000000000001");
      expect(emptyRange1Detail.end).to.equal("262000000000000000000");

      const emptyRange2Detail = await prizePool.getEmptyRangeDetail(1);
      expect(emptyRange2Detail.start).to.equal("472000000000000000001");
      expect(emptyRange2Detail.end).to.equal("500000000000000000000");

      let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRange1Detail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      await prizePool
        .connect(deployer)
        .getTickets(user7.address, user7WeiAmount, [0, 1], []); // 0th slot

      emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(0);

      const totalEligibleTicketsAfter =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsAfter = await prizePool.totalTicketNumber();

      expect(totalEligibleTicketsBefore).to.equal(totalEligibleTicketsAfter);
      expect(totalTicketsBefore).to.equal(totalTicketsAfter);

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRange1Detail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user7.address);

      expect(endingRangeDetails.start).to.equal(emptyRange1Detail.start);

      expect(endingRangeDetails.indexInUserRanges).to.equal(0);

      const endingRange2Details = await prizePool.getDetailsFromEndingRange(
        emptyRange2Detail.end
      );

      expect(endingRange2Details.userAddress).to.equal(user7.address);

      expect(endingRange2Details.start).to.equal(emptyRange2Detail.start);

      expect(endingRange2Details.indexInUserRanges).to.equal(1);

      let emptyRangeIndex = await prizePool.emptyRangesIndex(
        emptyRange2Detail.end
      );

      expect(emptyRangeIndex).to.equal(0);

      emptyRangeIndex = await prizePool.emptyRangesIndex(emptyRange2Detail.end);

      expect(emptyRangeIndex).to.equal(0);
    });

    it("Multiple non eligible stakes and unstakes and multiple slots filling during stake(3)", async () => {
      await multipleEligibleStakes();

      // forwarding 50 seconds to start cycle
      await forward(50);

      await multipleNonEligibleStakes();

      await unstakeNonEligible();

      const ethAmount = "42";
      const user7WeiAmount = ethers.utils.parseEther(ethAmount);

      const totalEligibleTicketsBefore =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsBefore = await prizePool.totalTicketNumber();

      let emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(2);

      const emptyRange1Detail = await prizePool.getEmptyRangeDetail(0);
      expect(emptyRange1Detail.start).to.equal("258000000000000000001");
      expect(emptyRange1Detail.end).to.equal("262000000000000000000");

      const emptyRange2Detail = await prizePool.getEmptyRangeDetail(1);
      expect(emptyRange2Detail.start).to.equal("472000000000000000001");
      expect(emptyRange2Detail.end).to.equal("500000000000000000000");

      let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRange1Detail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      await prizePool
        .connect(deployer)
        .getTickets(user7.address, user7WeiAmount, [0, 1], []); // 0th slot

      emptyRangeLength = await prizePool.totalEmptyRanges();

      expect(emptyRangeLength).to.equal(0);

      const totalEligibleTicketsAfter =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsAfter = await prizePool.totalTicketNumber();
      const extraTickets = ethers.utils.parseEther("10");

      expect(totalEligibleTicketsBefore).to.equal(totalEligibleTicketsAfter);

      expect(totalTicketsBefore.add(extraTickets)).to.equal(totalTicketsAfter);

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRange1Detail.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user7.address);

      expect(endingRangeDetails.start).to.equal(emptyRange1Detail.start);

      expect(endingRangeDetails.indexInUserRanges).to.equal(0);

      const endingRange2Details = await prizePool.getDetailsFromEndingRange(
        emptyRange2Detail.end
      );

      expect(endingRange2Details.userAddress).to.equal(user7.address);

      expect(endingRange2Details.start).to.equal(emptyRange2Detail.start);

      expect(endingRange2Details.indexInUserRanges).to.equal(1);

      const totalUserRanges = await prizePool.totalUserRanges(user7.address);

      expect(totalUserRanges).to.equal(3);

      // last slot is allocated for remaining tickets so totalTicketAfter will be the ending range
      const range3Details = await prizePool.getDetailsFromEndingRange(
        totalTicketsAfter
      );

      expect(range3Details.userAddress).to.equal(user7.address);

      expect(range3Details.start).to.equal(totalTicketsBefore.add(1));

      expect(range3Details.indexInUserRanges).to.equal(2);
    });
  });

  describe("Eligible and Non Eligible slots", () => {
    beforeEach(async () => {
      WinWin = await ethers.getContractFactory("WinToken");
      winToken = await WinWin.deploy("10000000000000");

      const lastTimestamp = (await waffle.provider.getBlock("latest"))
        .timestamp;

      WinStakingPool = await ethers.getContractFactory("WinStakingPool");

      winStakingPool = await WinStakingPool.deploy(
        winToken.address,
        lastTimestamp,
        "1000000000"
      );

      PrizePoolContract = await ethers.getContractFactory(
        "PrizePool",
        deployer
      );
      const prizeDistribution = [6000, 900, 600, 300, 100, 2100];
      prizePool = await PrizePoolContract.deploy(
        lastTimestamp + 50,
        deployer.address,
        prizeDistribution
      );
    });

    it("User has stake in both eligible and non eligible ", async () => {
      await multipleEligibleStakes();

      // forwarding 50 seconds to start cycle
      await forward(50);

      await multipleNonEligibleStakes();

      const totalEligibleForThisDraw =
        await prizePool.totalEligibleForThisDraw();
      const totalTickets = await prizePool.totalTicketNumber();

      expect(totalEligibleForThisDraw).to.equal("222000000000000000000");
      expect(totalTickets).to.equal("530000000000000000000");

      const unstakeEthAmount = "1";
      const unstakeWeiAmount = ethers.utils.parseEther(unstakeEthAmount);

      const totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(0);

      let endingRangeDetials = await prizePool.getDetailsFromEndingRange(
        totalTickets
      );

      expect(endingRangeDetials.userAddress).to.equal(user5.address);
      expect(endingRangeDetials.start).to.equal("500000000000000000001");
      expect(endingRangeDetials.indexInUserRanges).to.equal(1);

      await prizePool
        .connect(deployer)
        .burnTickets(user5.address, unstakeWeiAmount);

      const totalEligibleForThisDrawAfter =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsAfter = await prizePool.totalTicketNumber();

      expect(totalEligibleForThisDrawAfter).to.equal("222000000000000000000");
      expect(totalTicketsAfter).to.equal("529000000000000000000");

      endingRangeDetials = await prizePool.getDetailsFromEndingRange(
        totalTickets
      );

      expect(endingRangeDetials.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      endingRangeDetials = await prizePool.getDetailsFromEndingRange(
        totalTicketsAfter
      );

      expect(endingRangeDetials.userAddress).to.equal(user5.address);
      expect(endingRangeDetials.start).to.equal("500000000000000000001");
      expect(endingRangeDetials.indexInUserRanges).to.equal(1);

      const rangeDetials = await prizePool.getRangeDetails(user5.address, 1);

      expect(rangeDetials.start).to.equal("500000000000000000001");
      expect(rangeDetials.end).to.equal(totalTicketsAfter);
    });

    it("User in the non eligible time can not fill eligible slots", async () => {
      await multipleEligibleStakes();

      // forwarding 50 seconds to start cycle
      await forward(50);

      await multipleNonEligibleStakes();

      await unstakeEligible();

      let ethAmount = "4";
      const user4UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

      await prizePool
        .connect(deployer)
        .burnTickets(user4.address, user4UnstakeWeiAmount);

      // As it is middle slot so total tickets will not decrease
      // Empty ticket slots will be pushed to emptyRange array

      const totalUser4Ranges = await prizePool.totalUserRanges(user4.address);

      expect(totalUser4Ranges).to.equal(1);

      const totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(3);

      const emptyRangeDetials = await prizePool.getEmptyRangeDetail(2);

      expect(emptyRangeDetials.start).to.equal("258000000000000000001");
      expect(emptyRangeDetials.end).to.equal("262000000000000000000");

      const endingDetials = await prizePool.emptyRangesIndex(
        emptyRangeDetials.end
      );

      expect(endingDetials).to.equal(2);

      ethAmount = "90";
      const weiAmount = ethers.utils.parseEther(ethAmount);

      await expect(
        prizePool
          .connect(deployer)
          .getTickets(user5.address, weiAmount, [0], [])
      ).to.be.revertedWith("can not fill eligible slots");
    });

    it("User Removing all it's tickets", async () => {
      await multipleEligibleStakes();

      // forwarding 50 seconds to start cycle
      await forward(50);

      const totalEligibleForThisDraw =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketNumbers = await prizePool.totalTicketNumber();

      expect(totalEligibleForThisDraw).to.equal("222000000000000000000");
      expect(totalTicketNumbers).to.equal("222000000000000000000");

      let ethAmount = "23";
      const weiAmount = ethers.utils.parseEther(ethAmount);

      await prizePool
        .connect(deployer)
        .getTickets(user2.address, weiAmount, [], []);

      let totalEligibleForThisDrawAfter =
        await prizePool.totalEligibleForThisDraw();
      let totalTicketNumbersAfter = await prizePool.totalTicketNumber();

      expect(totalEligibleForThisDrawAfter).to.equal(totalEligibleForThisDraw);
      expect(totalTicketNumbersAfter).to.equal(
        totalTicketNumbers.add(weiAmount)
      );

      let totalUserRanges = await prizePool.totalUserRanges(user2.address);

      expect(totalUserRanges).to.equal(2);

      ethAmount = "89";
      const user5WeiAmount = ethers.utils.parseEther(ethAmount);

      await prizePool
        .connect(deployer)
        .getTickets(user5.address, user5WeiAmount, [], []);

      totalEligibleForThisDrawAfter =
        await prizePool.totalEligibleForThisDraw();
      totalTicketNumbersAfter = await prizePool.totalTicketNumber();

      expect(totalEligibleForThisDrawAfter).to.equal(totalEligibleForThisDraw);
      expect(totalTicketNumbersAfter).to.equal(
        totalTicketNumbers.add(weiAmount).add(user5WeiAmount)
      );

      let totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(0);

      ethAmount = "35";
      const user5UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

      const userRange1Detail = await prizePool.getRangeDetails(
        user2.address,
        0
      );
      const userRange2Detail = await prizePool.getRangeDetails(
        user2.address,
        1
      );

      let userEndingIndex = await prizePool.getDetailsFromEndingRange(
        userRange1Detail.end
      );

      expect(userEndingIndex.userAddress).to.equal(user2.address);
      expect(userEndingIndex.indexInUserRanges).to.equal(0);

      userEndingIndex = await prizePool.getDetailsFromEndingRange(
        userRange2Detail.end
      );

      expect(userEndingIndex.userAddress).to.equal(user2.address);
      expect(userEndingIndex.indexInUserRanges).to.equal(1);

      await prizePool
        .connect(deployer)
        .burnTickets(user2.address, user5UnstakeWeiAmount);

      totalUserRanges = await prizePool.totalUserRanges(user2.address);

      expect(totalUserRanges).to.equal(0);

      userEndingIndex = await prizePool.getDetailsFromEndingRange(
        userRange2Detail.end
      );

      expect(userEndingIndex.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      userEndingIndex = await prizePool.getDetailsFromEndingRange(
        userRange1Detail.end
      );

      expect(userEndingIndex.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(2);

      const emptyRangeDetails = await prizePool.getEmptyRangeDetail(0);

      expect(emptyRangeDetails.start).to.equal(userRange2Detail.start);
      expect(emptyRangeDetails.end).to.equal(userRange2Detail.end);

      const emptyRangeDetails2 = await prizePool.getEmptyRangeDetail(1);

      expect(emptyRangeDetails2.start).to.equal(userRange1Detail.start);
      expect(emptyRangeDetails2.end).to.equal(userRange1Detail.end);

      let endingRangeIndex = await prizePool.emptyRangesIndex(
        emptyRangeDetails.end
      );

      expect(endingRangeIndex).to.equal(0);

      endingRangeIndex = await prizePool.emptyRangesIndex(
        emptyRangeDetails2.end
      );

      expect(endingRangeIndex).to.equal(1);
    });
  });

  describe("Shuffle test", () => {
    beforeEach(async () => {
      WinWin = await ethers.getContractFactory("WinToken");
      winToken = await WinWin.deploy("10000000000000");

      const lastTimestamp = (await waffle.provider.getBlock("latest"))
        .timestamp;

      WinStakingPool = await ethers.getContractFactory("WinStakingPool");

      winStakingPool = await WinStakingPool.deploy(
        winToken.address,
        lastTimestamp,
        "1000000000"
      );

      PrizePoolContract = await ethers.getContractFactory(
        "PrizePool",
        deployer
      );
      const prizeDistribution = [6000, 900, 600, 300, 100, 2100];
      prizePool = await PrizePoolContract.deploy(
        lastTimestamp + 50,
        deployer.address,
        prizeDistribution
      );
    });

    it("Shuffle when only eligible slots are present", async () => {
      await multipleEligibleStakes();
      await unstakeEligible();

      let totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
      let totalTickets = await prizePool.totalTicketNumber();

      expect(totalEligibleTickets).to.equal("222000000000000000000");
      expect(totalTickets).to.equal("222000000000000000000");

      await forward(150);

      const totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(2);

      const emptyRange1 = await prizePool.getEmptyRangeDetail(0);

      const emptyRange2 = await prizePool.getEmptyRangeDetail(1);

      expect(emptyRange1.start).to.equal("107000000000000000001");
      expect(emptyRange1.end).to.equal("112000000000000000000");

      let endingRange1Details = await prizePool.getDetailsFromEndingRange(
        emptyRange1.end
      );

      expect(endingRange1Details.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      expect(emptyRange2.start).to.equal("126000000000000000001");
      expect(emptyRange2.end).to.equal("135000000000000000000");

      let endingRange2Details = await prizePool.getDetailsFromEndingRange(
        emptyRange2.end
      );

      expect(endingRange2Details.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      // 107 - 112
      // 126 - 135

      await prizePool.bigShuffle([0, 1]);

      endingRange1Details = await prizePool.getDetailsFromEndingRange(
        emptyRange1.end
      );

      endingRange2Details = await prizePool.getDetailsFromEndingRange(
        emptyRange2.end
      );

      expect(endingRange1Details.userAddress).to.equal(user1.address);

      expect(endingRange1Details.start).to.equal(emptyRange1.start);

      expect(endingRange1Details.indexInUserRanges).to.equal(2);

      expect(endingRange2Details.userAddress).to.equal(user1.address);

      expect(endingRange2Details.start).to.equal(emptyRange2.start);

      expect(endingRange2Details.indexInUserRanges).to.equal(3);

      let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        totalEligibleTickets
      );

      expect(endingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
      totalTickets = await prizePool.totalTicketNumber();

      expect(totalEligibleTickets).to.equal("208000000000000000000");
      expect(totalTickets).to.equal("208000000000000000000");

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        totalEligibleTickets
      );

      expect(endingRangeDetails.userAddress).to.equal(user1.address);

      expect(endingRangeDetails.start).to.equal("135000000000000000001");

      expect(endingRangeDetails.indexInUserRanges).to.equal(1);
    });

    it("Shuffle on eligible slots", async () => {
      await multipleEligibleStakesSetupForShuffle();

      let totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
      let totalTickets = await prizePool.totalTicketNumber();

      expect(totalEligibleTickets).to.equal("1385000000000000000000");
      expect(totalTickets).to.equal("1385000000000000000000");

      let totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(0);

      const ethAmount = "143";
      const user3UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

      // Making  slot empty
      await prizePool
        .connect(deployer)
        .burnTickets(user3.address, user3UnstakeWeiAmount);

      totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(1);

      const emptyRangeDetails = await prizePool.getEmptyRangeDetail(0);

      expect(emptyRangeDetails.start).to.equal("1099000000000000000001");

      expect(emptyRangeDetails.end).to.equal("1242000000000000000000");

      await forward(150);

      await prizePool.bigShuffle([0]);

      totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(0);

      totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
      totalTickets = await prizePool.totalTicketNumber();

      expect(totalEligibleTickets).to.equal("1242000000000000000000");
      expect(totalTickets).to.equal("1242000000000000000000");

      // U5 previously had -> 1351-1385 now it has changed to 1099-1133
      const user5Detials = await prizePool.getRangeDetails(user5.address, 0);

      expect(user5Detials.start).to.equal(emptyRangeDetails.start);
      expect(user5Detials.end).to.equal(
        emptyRangeDetails.start.add("34000000000000000000").sub(1)
      );

      // Ending range will be current total eligible tickets number
      let user5EndingRangeDetails = await prizePool.getDetailsFromEndingRange(
        "1385000000000000000000"
      );

      expect(user5EndingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      user5EndingRangeDetails = await prizePool.getDetailsFromEndingRange(
        user5Detials.end
      );

      expect(user5EndingRangeDetails.userAddress).to.equal(user5.address);
      expect(user5EndingRangeDetails.indexInUserRanges).to.equal(0);
      expect(user5EndingRangeDetails.start).to.equal(user5Detials.start);
      // U1 previously had -> 1242-1329 now it has changed to 1133-1155
      const user4Detials = await prizePool.getRangeDetails(user4.address, 0);

      expect(user4Detials.start).to.equal(
        emptyRangeDetails.start.add("34000000000000000000")
      );
      expect(user4Detials.end).to.equal(
        emptyRangeDetails.start
          .add("34000000000000000000")
          .add("22000000000000000000")
          .sub(1)
      );

      // Ending range will be current total eligible tickets number
      let user4EndingRangeDetails = await prizePool.getDetailsFromEndingRange(
        "1351000000000000000000"
      );

      expect(user4EndingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      user4EndingRangeDetails = await prizePool.getDetailsFromEndingRange(
        user4Detials.end
      );

      expect(user4EndingRangeDetails.userAddress).to.equal(user4.address);
      expect(user4EndingRangeDetails.indexInUserRanges).to.equal(0);
      expect(user4EndingRangeDetails.start).to.equal(user4Detials.start);

      // U1 previously had -> 1329-1351 now it has changed to 1155=1242
      const user1Details = await prizePool.getRangeDetails(user1.address, 1);

      expect(user1Details.start).to.equal(
        emptyRangeDetails.start
          .add("34000000000000000000")
          .add("22000000000000000000")
      );
      expect(user1Details.end).to.equal(
        emptyRangeDetails.start
          .add("34000000000000000000")
          .add("22000000000000000000")
          .add("87000000000000000000")
          .sub(1)
      );

      // Ending range will be current total eligible tickets number
      let user1EndingRangeDetails = await prizePool.getDetailsFromEndingRange(
        "1329000000000000000000"
      );

      expect(user1EndingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      user1EndingRangeDetails = await prizePool.getDetailsFromEndingRange(
        user1Details.end
      );

      expect(user1EndingRangeDetails.userAddress).to.equal(user1.address);
      expect(user1EndingRangeDetails.indexInUserRanges).to.equal(1);
      expect(user1EndingRangeDetails.start).to.equal(user1Details.start);
    });

    it("Shuffle on eligible slots max 5 shuffle to fill one empty slot in one transaction", async () => {
      await multipleEligibleStakesSetupForShuffleLimit();

      let totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
      let totalTickets = await prizePool.totalTicketNumber();

      expect(totalEligibleTickets).to.equal("1411000000000000000000");
      expect(totalTickets).to.equal("1411000000000000000000");

      let totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(0);

      const ethAmount = "143";
      const user3UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

      // Making  slot empty
      await prizePool
        .connect(deployer)
        .burnTickets(user3.address, user3UnstakeWeiAmount);

      totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(1);

      const emptyRangeDetails = await prizePool.getEmptyRangeDetail(0);

      expect(emptyRangeDetails.start).to.equal("1099000000000000000001");

      expect(emptyRangeDetails.end).to.equal("1242000000000000000000");

      const emptyRangeIndex = await prizePool.emptyRangesIndex(
        emptyRangeDetails.end
      );

      expect(emptyRangeIndex).to.equal(0);

      await forward(150);

      await prizePool.bigShuffle([0]);

      const emptyRangeDetailsAfter = await prizePool.getEmptyRangeDetail(0);

      expect(emptyRangeDetailsAfter.start).to.equal("1118000000000000000001");

      expect(emptyRangeDetailsAfter.end).to.equal("1242000000000000000000");

      totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
      totalTickets = await prizePool.totalTicketNumber();

      expect(totalEligibleTickets).to.equal("1392000000000000000000");
      expect(totalTickets).to.equal("1392000000000000000000");

      // U9 previously had -> 1408-1411 now it has changed to 1099-1102
      const totalUser9Ranges = await prizePool.totalUserRanges(user9.address);

      expect(totalUser9Ranges).to.equal(1);

      const user9Details = await prizePool.getRangeDetails(user9.address, 0);

      expect(user9Details.start).to.equal(emptyRangeDetails.start);
      expect(user9Details.end).to.equal(
        emptyRangeDetails.start.add("3000000000000000000").sub(1)
      );

      // previous Ending range will be current total eligible tickets number
      let user9EndingRangeDetails = await prizePool.getDetailsFromEndingRange(
        "1411000000000000000000"
      );

      expect(user9EndingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      user9EndingRangeDetails = await prizePool.endingRangeToUser(
        user9Details.end
      );

      expect(user9EndingRangeDetails.userAddress).to.equal(user9.address);

      expect(user9EndingRangeDetails.start).to.equal(emptyRangeDetails.start);

      expect(user9EndingRangeDetails.indexInUserRanges).to.equal(0);

      // U7 previously had -> 1399-1408 now it has changed to 1102-1111
      let user7Details = await prizePool.getRangeDetails(user7.address, 1);

      expect(user7Details.start).to.equal(
        emptyRangeDetails.start.add("3000000000000000000")
      );
      expect(user7Details.end).to.equal(
        emptyRangeDetails.start
          .add("3000000000000000000")
          .add("9000000000000000000")
          .sub(1)
      );

      // previous Ending range will be current total eligible tickets number
      let user7EndingRangeDetails = await prizePool.getDetailsFromEndingRange(
        "1408000000000000000000"
      );

      expect(user7EndingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      let totalUser7Ranges = await prizePool.totalUserRanges(user7.address);

      expect(totalUser7Ranges).to.equal(2);

      user7EndingRangeDetails = await prizePool.endingRangeToUser(
        emptyRangeDetails.start
          .add("3000000000000000000")
          .add("9000000000000000000")
          .sub(1)
      );

      expect(user7EndingRangeDetails.userAddress).to.equal(user7.address);

      expect(user7EndingRangeDetails.start).to.equal(
        emptyRangeDetails.start.add("3000000000000000000")
      );

      expect(user7EndingRangeDetails.indexInUserRanges).to.equal(1);

      // U8 previously had -> 1392-1399 now it has changed to 1111-1118
      const user8Details = await prizePool.getRangeDetails(user8.address, 0);

      expect(user8Details.start).to.equal(
        emptyRangeDetails.start
          .add("3000000000000000000")
          .add("9000000000000000000")
      );
      expect(user8Details.end).to.equal(
        emptyRangeDetails.start
          .add("3000000000000000000")
          .add("9000000000000000000")
          .add("7000000000000000000")
          .sub(1)
      );

      let user8EndingRangeDetails = await prizePool.getDetailsFromEndingRange(
        "1399000000000000000000"
      );

      expect(user8EndingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      const totalUser8Ranges = await prizePool.totalUserRanges(user8.address);

      expect(totalUser8Ranges).to.equal(1);

      user8EndingRangeDetails = await prizePool.endingRangeToUser(
        emptyRangeDetails.start
          .add("3000000000000000000")
          .add("9000000000000000000")
          .add("7000000000000000000")
          .sub(1)
      );

      expect(user8EndingRangeDetails.userAddress).to.equal(user8.address);

      expect(user8EndingRangeDetails.start).to.equal(
        emptyRangeDetails.start
          .add("3000000000000000000")
          .add("9000000000000000000")
      );

      expect(user8EndingRangeDetails.indexInUserRanges).to.equal(0);

      //U7 previously had -> 1387-1392 it will remain unchanged
      user7Details = await prizePool.getRangeDetails(user7.address, 0);

      expect(user7Details.end).to.equal(totalEligibleTickets);

      totalUser7Ranges = await prizePool.totalUserRanges(user7.address);

      expect(totalUser7Ranges).to.equal(2);

      user7EndingRangeDetails = await prizePool.endingRangeToUser(
        totalEligibleTickets
      );

      expect(user7EndingRangeDetails.userAddress).to.equal(user7.address);

      expect(user7EndingRangeDetails.start).to.equal(user7Details.start);

      expect(user7EndingRangeDetails.indexInUserRanges).to.equal(0);

      //U1 previously had -> 1385-1387 now it remain unchanged
      let user1Details = await prizePool.getRangeDetails(user1.address, 2);

      expect(user1Details.end).to.equal(user7Details.start.sub(1));

      const totalUser1Ranges = await prizePool.totalUserRanges(user1.address);

      expect(totalUser1Ranges).to.equal(3);

      let user1EndingRangeDetails = await prizePool.endingRangeToUser(
        user7Details.start.sub(1)
      );

      expect(user1EndingRangeDetails.userAddress).to.equal(user1.address);

      expect(user1EndingRangeDetails.start).to.equal(user1Details.start);

      expect(user1EndingRangeDetails.indexInUserRanges).to.equal(2);

      const user5EndingRangeDetails = await prizePool.getDetailsFromEndingRange(
        "1385000000000000000000"
      );

      expect(user5EndingRangeDetails.userAddress).to.equal(user5.address);
    });

    it("During shuffling if there is any empty slot in between", async () => {
      await multipleEligibleStakesSetupForShuffleLimit();

      const totalEligibleTickets = await prizePool.totalEligibleForThisDraw();
      const totalTickets = await prizePool.totalTicketNumber();

      expect(totalEligibleTickets).to.equal("1411000000000000000000");
      expect(totalTickets).to.equal("1411000000000000000000");

      let totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(0);

      let ethAmount = "143";
      const user3UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

      // Making  slot empty
      await prizePool
        .connect(deployer)
        .burnTickets(user3.address, user3UnstakeWeiAmount);

      totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(1);

      const emptyRangeDetails0 = await prizePool.getEmptyRangeDetail(0);

      expect(emptyRangeDetails0.start).to.equal("1099000000000000000001");

      expect(emptyRangeDetails0.end).to.equal("1242000000000000000000");

      let emptyRangeIndex = await prizePool.emptyRangesIndex(
        emptyRangeDetails0.end
      );

      expect(emptyRangeIndex).to.equal(0);

      ethAmount = "7";
      const user8UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);
      // //Making another slot empty
      await prizePool
        .connect(deployer)
        .burnTickets(user8.address, user8UnstakeWeiAmount);

      totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(2);

      const emptyRangeDetails1 = await prizePool.getEmptyRangeDetail(1);

      expect(emptyRangeDetails1.start).to.equal("1392000000000000000001");

      expect(emptyRangeDetails1.end).to.equal("1399000000000000000000");

      emptyRangeIndex = await prizePool.emptyRangesIndex(
        emptyRangeDetails1.end
      );

      expect(emptyRangeIndex).to.equal(1);

      await forward(150);

      await prizePool.bigShuffle([0]);

      const totalEligibleForThisDraw =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketNumber = await prizePool.totalTicketNumber();

      expect(totalEligibleForThisDraw).to.equal("1392000000000000000000");
      expect(totalTicketNumber).to.equal("1392000000000000000000");

      totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(1);

      const emptyRangeDetails0After = await prizePool.getEmptyRangeDetail(0);

      expect(emptyRangeDetails0After.start).to.equal("1111000000000000000001");

      expect(emptyRangeDetails0After.end).to.equal("1242000000000000000000");

      // U9 previously had -> 1408-1411 now it has changed to 1099-1102
      const user9Details = await prizePool.getRangeDetails(user9.address, 0);

      expect(user9Details.start).to.equal(emptyRangeDetails0.start);
      expect(user9Details.end).to.equal(
        emptyRangeDetails0.start.add("3000000000000000000").sub(1)
      );

      // previous Ending range will be current total eligible tickets number
      let user9EndingRangeDetails = await prizePool.getDetailsFromEndingRange(
        "1411000000000000000000"
      );

      expect(user9EndingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      const totalUser9Ranges = await prizePool.totalUserRanges(user9.address);

      expect(totalUser9Ranges).to.equal(1);

      user9EndingRangeDetails = await prizePool.endingRangeToUser(
        emptyRangeDetails0.start.add("3000000000000000000").sub(1)
      );

      expect(user9EndingRangeDetails.userAddress).to.equal(user9.address);

      expect(user9EndingRangeDetails.start).to.equal(emptyRangeDetails0.start);

      expect(user9EndingRangeDetails.indexInUserRanges).to.equal(0);

      // U7 previously had -> 1399-1408 now it has changed to 1102-1111
      let user7Details = await prizePool.getRangeDetails(user7.address, 1);

      expect(user7Details.start).to.equal(
        emptyRangeDetails0.start.add("3000000000000000000")
      );
      expect(user7Details.end).to.equal(
        emptyRangeDetails0.start
          .add("3000000000000000000")
          .add("9000000000000000000")
          .sub(1)
      );

      // previous Ending range will be current total eligible tickets number
      let user7EndingRangeDetails = await prizePool.getDetailsFromEndingRange(
        "1408000000000000000000"
      );

      expect(user7EndingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      let totalUser7Ranges = await prizePool.totalUserRanges(user7.address);

      expect(totalUser7Ranges).to.equal(2);

      user7EndingRangeDetails = await prizePool.endingRangeToUser(
        emptyRangeDetails0.start
          .add("3000000000000000000")
          .add("9000000000000000000")
          .sub(1)
      );

      expect(user7EndingRangeDetails.userAddress).to.equal(user7.address);

      expect(user7EndingRangeDetails.start).to.equal(
        emptyRangeDetails0.start.add("3000000000000000000")
      );

      expect(user7EndingRangeDetails.indexInUserRanges).to.equal(1);

      //U7 previously had -> 1387-1392 it will remain unchanged
      user7Details = await prizePool.getRangeDetails(user7.address, 0);

      expect(user7Details.end).to.equal(totalEligibleForThisDraw);

      totalUser7Ranges = await prizePool.totalUserRanges(user7.address);

      expect(totalUser7Ranges).to.equal(2);

      user7EndingRangeDetails = await prizePool.endingRangeToUser(
        totalEligibleForThisDraw
      );

      expect(user7EndingRangeDetails.userAddress).to.equal(user7.address);

      expect(user7EndingRangeDetails.start).to.equal(user7Details.start);

      expect(user7EndingRangeDetails.indexInUserRanges).to.equal(0);

      //U1 previously had -> 1385-1387 now it remain unchanged
      let user1Details = await prizePool.getRangeDetails(user1.address, 2);

      expect(user1Details.end).to.equal(user7Details.start.sub(1));

      const totalUser1Ranges = await prizePool.totalUserRanges(user1.address);

      expect(totalUser1Ranges).to.equal(3);

      let user1EndingRangeDetails = await prizePool.endingRangeToUser(
        user7Details.start.sub(1)
      );

      expect(user1EndingRangeDetails.userAddress).to.equal(user1.address);

      expect(user1EndingRangeDetails.start).to.equal(user1Details.start);

      expect(user1EndingRangeDetails.indexInUserRanges).to.equal(2);

      let endingDetails = await prizePool.getDetailsFromEndingRange(
        "1385000000000000000000"
      );

      expect(endingDetails.userAddress).to.equal(user5.address);
      expect(endingDetails.indexInUserRanges).to.equal(0);
      expect(endingDetails.start).to.equal("1351000000000000000001");
    });

    it("Shuffle when there are eligible and non eligible slots and there is any empty slot in between", async () => {
      await multipleEligibleStakesSetupForShuffle();

      await forward(50);

      await multipleNonEligibleStakesForShuffle();

      const totalEligibleTicketsBefore =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsBefore = await prizePool.totalTicketNumber();

      expect(totalEligibleTicketsBefore).to.equal("1385000000000000000000");
      expect(totalTicketsBefore).to.equal("1693000000000000000000");

      let ethAmount = "17";
      const user1UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

      // Making  slot empty
      await prizePool
        .connect(deployer)
        .burnTickets(user1.address, user1UnstakeWeiAmount);

      ethAmount = "80";
      const user3UnstakeWeiAmount = ethers.utils.parseEther(ethAmount);

      // Making  slot empty
      await prizePool
        .connect(deployer)
        .burnTickets(user3.address, user3UnstakeWeiAmount);

      await forward(100);

      let totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(2);

      let emptyRanges0 = await prizePool.getEmptyRangeDetail(0);

      expect(emptyRanges0.start).to.equal("1312000000000000000001");
      expect(emptyRanges0.end).to.equal("1329000000000000000000");

      const emptyRanges1 = await prizePool.getEmptyRangeDetail(1);

      expect(emptyRanges1.start).to.equal("1162000000000000000001");
      expect(emptyRanges1.end).to.equal("1242000000000000000000");

      let index0 = await prizePool.emptyRangesIndex("1329000000000000000000");
      expect(index0).to.equal(0);

      const index1 = await prizePool.emptyRangesIndex("1242000000000000000000");
      expect(index1).to.equal(1);

      await prizePool.bigShuffle([1]);

      totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(4);

      emptyRanges0 = await prizePool.getEmptyRangeDetail(0);

      expect(emptyRanges0.start).to.equal("1312000000000000000001");
      expect(emptyRanges0.end).to.equal("1329000000000000000000");

      index0 = await prizePool.emptyRangesIndex("1329000000000000000000");
      expect(index0).to.equal(0);

      let emptyRanges2 = await prizePool.getEmptyRangeDetail(2);

      expect(emptyRanges2.start).to.equal("1351000000000000000001");
      expect(emptyRanges2.end).to.equal("1385000000000000000000");

      const index2 = await prizePool.emptyRangesIndex("1385000000000000000000");
      expect(index2).to.equal(2);

      const user5Ranges = await prizePool.totalUserRanges(user5.address);
      expect(user5Ranges).to.equal(3);
      let rangeDetails = await prizePool.getRangeDetails(user5.address, 0);

      expect(rangeDetails.start).to.equal("1162000000000000000001");
      expect(rangeDetails.end).to.equal("1196000000000000000000");

      let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        rangeDetails.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user5.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(0);
      expect(endingRangeDetails.start).to.equal(rangeDetails.start);

      const emptyRanges3 = await prizePool.getEmptyRangeDetail(3);

      expect(emptyRanges3.start).to.equal("1329000000000000000001");
      expect(emptyRanges3.end).to.equal("1351000000000000000000");

      const index3 = await prizePool.emptyRangesIndex("1351000000000000000000");
      expect(index3).to.equal(3);

      const user4Ranges = await prizePool.totalUserRanges(user4.address);
      expect(user4Ranges).to.equal(2);
      rangeDetails = await prizePool.getRangeDetails(user4.address, 0);

      expect(rangeDetails.start).to.equal("1196000000000000000001");
      expect(rangeDetails.end).to.equal("1218000000000000000000");

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        rangeDetails.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user4.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(0);
      expect(endingRangeDetails.start).to.equal(rangeDetails.start);

      const emptyRanges4 = await prizePool.getEmptyRangeDetail(1);

      expect(emptyRanges4.start).to.equal("1218000000000000000001");
      expect(emptyRanges4.end).to.equal("1242000000000000000000");

      let index4 = await prizePool.emptyRangesIndex("1242000000000000000000");
      expect(index4).to.equal(1);

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRanges4.end
      );

      expect(endingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        emptyRanges4.start.sub(1)
      );

      expect(endingRangeDetails.userAddress).to.equal(user4.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(0);
      expect(endingRangeDetails.start).to.equal("1196000000000000000001");

      const totalTicketsAfter = await prizePool.totalTicketNumber();
      const totalEligibleTokenAfter =
        await prizePool.totalEligibleForThisDraw();

      //ALso remove empty slots in between and add to non eligible empty slots
      expect(totalEligibleTokenAfter).to.equal("1312000000000000000000");
      expect(totalTicketsAfter).to.equal("1693000000000000000000");
    });

    it("Shuffle when there are eligible and non eligible slots", async () => {
      await multipleEligibleStakesSetupForShuffle();

      await forward(50);

      await multipleNonEligibleStakesForShuffle();

      await unstakeEligibleForShuffle();

      const totalEligibleTicketsBefore =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsBefore = await prizePool.totalTicketNumber();

      expect(totalEligibleTicketsBefore).to.equal("1385000000000000000000");
      expect(totalTicketsBefore).to.equal("1693000000000000000000");

      await forward(100);

      let totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(2);

      let emptyRange1 = await prizePool.getEmptyRangeDetail(0);

      let emptyRange2 = await prizePool.getEmptyRangeDetail(1);

      expect(emptyRange1.start).to.equal("1007000000000000000001");
      expect(emptyRange1.end).to.equal("1012000000000000000000");

      let endingRange1Details = await prizePool.getDetailsFromEndingRange(
        emptyRange1.end
      );

      expect(endingRange1Details.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      expect(emptyRange2.start).to.equal("1233000000000000000001");
      expect(emptyRange2.end).to.equal("1242000000000000000000");

      let endingRange2Details = await prizePool.getDetailsFromEndingRange(
        emptyRange2.end
      );

      expect(endingRange2Details.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      // 107 - 112
      // 126 - 135

      await prizePool.bigShuffle([0, 1]);

      endingRange1Details = await prizePool.getDetailsFromEndingRange(
        emptyRange1.end
      );

      endingRange2Details = await prizePool.getDetailsFromEndingRange(
        emptyRange2.end
      );

      expect(endingRange1Details.userAddress).to.equal(user5.address);

      expect(endingRange1Details.start).to.equal(emptyRange1.start);

      expect(endingRange1Details.indexInUserRanges).to.equal(3);

      expect(endingRange2Details.userAddress).to.equal(user5.address);

      expect(endingRange2Details.start).to.equal(emptyRange2.start);

      expect(endingRange2Details.indexInUserRanges).to.equal(4);

      let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        totalEligibleTicketsBefore
      );

      expect(endingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      const totalEligibleTicketsAfter =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsAfter = await prizePool.totalTicketNumber();

      expect(totalEligibleTicketsAfter).to.equal(
        totalEligibleTicketsBefore.sub("14000000000000000000")
      );
      expect(totalTicketsAfter).to.equal(totalTicketsBefore);

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        totalEligibleTicketsAfter
      );

      expect(endingRangeDetails.userAddress).to.equal(user5.address);

      expect(endingRangeDetails.start).to.equal("1351000000000000000001");

      expect(endingRangeDetails.indexInUserRanges).to.equal(0);

      totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(2);

      emptyRange1 = await prizePool.getEmptyRangeDetail(0);

      emptyRange2 = await prizePool.getEmptyRangeDetail(1);

      expect(emptyRange2.start).to.equal("1380000000000000000001");
      expect(emptyRange2.end).to.equal("1385000000000000000000");

      expect(emptyRange1.start).to.equal("1371000000000000000001");
      expect(emptyRange1.end).to.equal("1380000000000000000000");

      const lastIndex1 = await prizePool.emptyRangesIndex(emptyRange1.end);
      const lastIndex2 = await prizePool.emptyRangesIndex(emptyRange2.end);

      expect(lastIndex1).to.equal(0);
      expect(lastIndex2).to.equal(1);
    });

    it("During shuffling it reaches to the empty slot", async () => {
      await multipleEligibleStakesSetupForShuffle();

      await forward(50);

      await multipleNonEligibleStakesForShuffle();

      const totalEligibleTicketsBefore =
        await prizePool.totalEligibleForThisDraw();
      const totalTicketsBefore = await prizePool.totalTicketNumber();

      expect(totalEligibleTicketsBefore).to.equal("1385000000000000000000");
      expect(totalTicketsBefore).to.equal("1693000000000000000000");

      await forward(100);
      const burnAmount = "150";
      const burnAmountInWei = ethers.utils.parseEther(burnAmount);

      await prizePool.burnTickets(user3.address, burnAmountInWei);

      expect(await prizePool.totalEligibleForThisDraw()).to.equal(
        "1242000000000000000000"
      );

      const totalRanges = await prizePool.totalEmptyRanges();

      expect(totalRanges).to.equal(4);

      const rangeDetial1 = await prizePool.getEmptyRangeDetail(0);

      expect(rangeDetial1.start).to.equal("1235000000000000000001");
      expect(rangeDetial1.end).to.equal("1242000000000000000000");

      const endingRangeDetial1 = await prizePool.endingRangeToUser(
        "1126000000000000000000"
      );

      expect(endingRangeDetial1.userAddress).to.equal(user5.address);

      expect(endingRangeDetial1.start).to.equal("1092000000000000000001");

      expect(endingRangeDetial1.indexInUserRanges).to.equal(0);

      const rangeDetail2 = await prizePool.getEmptyRangeDetail(1);

      expect(rangeDetail2.start).to.equal("1351000000000000000001");
      expect(rangeDetail2.end).to.equal("1385000000000000000000");

      const endingRangeDetial2 = await prizePool.endingRangeToUser(
        "1148000000000000000000"
      );

      expect(endingRangeDetial2.userAddress).to.equal(user4.address);

      expect(endingRangeDetial2.start).to.equal("1126000000000000000001");

      expect(endingRangeDetial2.indexInUserRanges).to.equal(0);

      const rangeDetail3 = await prizePool.getEmptyRangeDetail(2);

      expect(rangeDetail3.start).to.equal("1329000000000000000001");
      expect(rangeDetail3.end).to.equal("1351000000000000000000");

      let endingRangeToUser = await prizePool.getDetailsFromEndingRange(
        rangeDetail3.end
      );
      expect(endingRangeToUser.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      const endingRangeDetial3 = await prizePool.endingRangeToUser(
        "1235000000000000000000"
      );

      expect(endingRangeDetial3.userAddress).to.equal(user1.address);

      expect(endingRangeDetial3.start).to.equal("1148000000000000000001");

      expect(endingRangeDetial3.indexInUserRanges).to.equal(1);

      const rangeDetail4 = await prizePool.getEmptyRangeDetail(3);

      expect(rangeDetail4.start).to.equal("1242000000000000000001");
      expect(rangeDetail4.end).to.equal("1329000000000000000000");

      endingRangeToUser = await prizePool.getDetailsFromEndingRange(
        rangeDetail4.end
      );
      expect(endingRangeToUser.userAddress).to.equal(
        ethers.constants.AddressZero
      );
    });

    it("Non eligible slots shuffling", async () => {
      await multipleEligibleStakesSetupForShuffle();

      await forward(50);

      await multipleNonEligibleStakesForShuffle();

      const cooldownDuration = await prizePool.COOLDOWN_DURATION();

      await forward(Number(cooldownDuration));

      const totalEligibleForThisDraw =
        await prizePool.totalEligibleForThisDraw();
      const totalTickets = await prizePool.totalTicketNumber();

      expect(totalEligibleForThisDraw).to.equal("1385000000000000000000");
      expect(totalTickets).to.equal("1693000000000000000000");

      const ethAmount = "20";
      const unstakeWeiAmount = ethers.utils.parseEther(ethAmount);

      let user6Ranges = await prizePool.totalUserRanges(user6.address);
      expect(user6Ranges).to.equal(1);

      const user6RangeDetailsBefore = await prizePool.getRangeDetails(
        user6.address,
        0
      );

      expect(user6RangeDetailsBefore.start).to.equal("1575000000000000000001");
      expect(user6RangeDetailsBefore.end).to.equal("1663000000000000000000");

      let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        user6RangeDetailsBefore.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user6.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(0);
      expect(endingRangeDetails.start).to.equal(user6RangeDetailsBefore.start);

      let user5Ranges = await prizePool.totalUserRanges(user5.address);

      expect(user5Ranges).to.equal(3);

      await prizePool.burnTickets(user6.address, unstakeWeiAmount);

      user6Ranges = await prizePool.totalUserRanges(user6.address);
      expect(user6Ranges).to.equal(1);

      const user6RangeDetailsAfter = await prizePool.getRangeDetails(
        user6.address,
        0
      );

      expect(user6RangeDetailsAfter.start).to.equal("1575000000000000000001");
      expect(user6RangeDetailsAfter.end).to.equal("1643000000000000000000");

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        user6RangeDetailsAfter.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user6.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(0);
      expect(endingRangeDetails.start).to.equal(user6RangeDetailsAfter.start);

      user5Ranges = await prizePool.totalUserRanges(user5.address);

      expect(user5Ranges).to.equal(4);

      const user5Ranges3 = await prizePool.getRangeDetails(user5.address, 3);

      expect(user5Ranges3.start).to.equal(user6RangeDetailsAfter.end.add(1));
      expect(user5Ranges3.end).to.equal(user6RangeDetailsBefore.end);

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        user6RangeDetailsBefore.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user5.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(3);
      expect(endingRangeDetails.start).to.equal(user5Ranges3.start);

      const totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(0);

      const totalTicketsAfter = await prizePool.totalTicketNumber();

      expect(totalTicketsAfter.add(unstakeWeiAmount)).to.equal(totalTickets);
    });

    it("Non eligible shuffling empty slots in between during shuffling(2)", async () => {
      await multipleEligibleStakesSetupForShuffle();

      await forward(50);

      await multipleNonEligibleStakesForShuffle();

      const totalEligibleForThisDraw =
        await prizePool.totalEligibleForThisDraw();
      const totalTickets = await prizePool.totalTicketNumber();

      expect(totalEligibleForThisDraw).to.equal("1385000000000000000000");
      expect(totalTickets).to.equal("1693000000000000000000");

      let ethAmount = "88";
      const unstakeWeiAmount = ethers.utils.parseEther(ethAmount);

      let user6Ranges = await prizePool.totalUserRanges(user6.address);
      expect(user6Ranges).to.equal(1);

      const user6RangeDetailsBefore = await prizePool.getRangeDetails(
        user6.address,
        0
      );

      expect(user6RangeDetailsBefore.start).to.equal("1575000000000000000001");
      expect(user6RangeDetailsBefore.end).to.equal("1663000000000000000000");

      let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        user6RangeDetailsBefore.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user6.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(0);
      expect(endingRangeDetails.start).to.equal(user6RangeDetailsBefore.start);

      await prizePool.burnTickets(user6.address, unstakeWeiAmount);

      user6Ranges = await prizePool.totalUserRanges(user6.address);
      expect(user6Ranges).to.equal(0);

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        user6RangeDetailsBefore.end
      );

      expect(endingRangeDetails.userAddress).to.equal(
        ethers.constants.AddressZero
      );

      let totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(1);

      const emptyRangeDetails = await prizePool.getEmptyRangeDetail(0);

      expect(emptyRangeDetails.start).to.equal(user6RangeDetailsBefore.start);
      expect(emptyRangeDetails.end).to.equal(user6RangeDetailsBefore.end);

      const user4Ranges = await prizePool.totalUserRanges(user4.address);
      expect(user4Ranges).to.equal(2);

      const user4RangeDetailsBefore = await prizePool.getRangeDetails(
        user4.address,
        1
      );

      expect(user4RangeDetailsBefore.start).to.equal("1385000000000000000001");
      expect(user4RangeDetailsBefore.end).to.equal("1425000000000000000000");

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        user4RangeDetailsBefore.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user4.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(1);
      expect(endingRangeDetails.start).to.equal(user4RangeDetailsBefore.start);

      const cooldownDuration = await prizePool.COOLDOWN_DURATION();

      await forward(Number(cooldownDuration));

      ethAmount = "31";
      const unstakeWeiAmount4 = ethers.utils.parseEther(ethAmount);

      await prizePool.burnTickets(user4.address, unstakeWeiAmount4);

      const user4Range = await prizePool.totalUserRanges(user4.address);

      expect(user4Range).to.equal(2);

      const user4RangeDetail = await prizePool.getRangeDetails(
        user4.address,
        1
      );

      expect(user4RangeDetail.start).to.equal("1385000000000000000001");
      expect(user4RangeDetail.end).to.equal("1394000000000000000000");

      const endingUser4Details = await prizePool.getDetailsFromEndingRange(
        user4RangeDetail.end
      );

      expect(endingUser4Details.userAddress).to.equal(user4.address);
      expect(endingUser4Details.indexInUserRanges).to.equal(1);
      expect(endingUser4Details.start).to.equal(user4RangeDetail.start);

      totalEmptyRanges = await prizePool.totalEmptyRanges();

      expect(totalEmptyRanges).to.equal(0);

      const totalTicketNumber = await prizePool.totalTicketNumber();

      expect(totalTicketNumber).to.equal(
        totalTickets.sub(unstakeWeiAmount).sub(unstakeWeiAmount4)
      );

      const user5Ranges = await prizePool.totalUserRanges(user5.address);
      expect(user5Ranges).to.equal(4);

      let user5Range3 = await prizePool.getRangeDetails(user5.address, 2);

      expect(user5Range3.start).to.equal("1394000000000000000001");
      expect(user5Range3.end).to.equal("1424000000000000000000");

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        user5Range3.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user5.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(2);
      expect(endingRangeDetails.start).to.equal(user5Range3.start);

      user5Range3 = await prizePool.getRangeDetails(user5.address, 3);

      expect(user5Range3.start).to.equal("1424000000000000000001");
      expect(user5Range3.end).to.equal("1425000000000000000000");

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        user5Range3.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user5.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(3);
      expect(endingRangeDetails.start).to.equal(user5Range3.start);
    });

    it("Shuffling eligible and non eligible both(1)", async () => {
      await multipleEligibleStakesSetupForShuffle();

      await forward(50);

      await multipleNonEligibleStakesForShuffle();

      const cooldownDuration = await prizePool.COOLDOWN_DURATION();

      await forward(Number(cooldownDuration));

      const totalEligibleForThisDraw =
        await prizePool.totalEligibleForThisDraw();
      const totalTickets = await prizePool.totalTicketNumber();

      expect(totalEligibleForThisDraw).to.equal("1385000000000000000000");
      expect(totalTickets).to.equal("1693000000000000000000");

      const ethAmount = "62";
      const unstakeWeiAmount = ethers.utils.parseEther(ethAmount);

      let totalUserRanges = await prizePool.totalUserRanges(user4.address);
      expect(totalUserRanges).to.equal(2);

      const firstUser4Range = await prizePool.getRangeDetails(user4.address, 0);

      expect(firstUser4Range.start).to.equal("1329000000000000000001");

      expect(firstUser4Range.end).to.equal("1351000000000000000000");

      const SecondUser4Range = await prizePool.getRangeDetails(
        user4.address,
        1
      );

      expect(SecondUser4Range.start).to.equal("1385000000000000000001");

      expect(SecondUser4Range.end).to.equal("1425000000000000000000");

      let user6Ranges = await prizePool.totalUserRanges(user6.address);
      expect(user6Ranges).to.equal(1);

      let user6Range = await prizePool.getRangeDetails(user6.address, 0);

      expect(user6Range.start).to.equal("1575000000000000000001");
      expect(user6Range.end).to.equal("1663000000000000000000");

      await prizePool.burnTickets(user4.address, unstakeWeiAmount);

      totalUserRanges = await prizePool.totalUserRanges(user4.address);
      expect(totalUserRanges).to.equal(0);

      const totalEligibleForThisDrawAfter =
        await prizePool.totalEligibleForThisDraw();

      // 22000000000000000000 from eligible
      expect(totalEligibleForThisDraw).to.equal(
        totalEligibleForThisDrawAfter.add("22000000000000000000")
      );

      const totalEmptyRanges = await prizePool.totalEmptyRanges();
      expect(totalEmptyRanges).to.equal(1);

      const thirdEmpty = await prizePool.getEmptyRangeDetail(0);

      expect(thirdEmpty.start).to.equal("1363000000000000000001");
      expect(thirdEmpty.end).to.equal("1385000000000000000000");

      const endingRangeIndex = await prizePool.emptyRangesIndex(thirdEmpty.end);
      expect(endingRangeIndex).to.equal(0);

      const user5Ranges = await prizePool.totalUserRanges(user5.address);
      expect(user5Ranges).to.equal(4);

      const firstRange = await prizePool.getRangeDetails(user5.address, 0);

      expect(firstRange.start).to.equal("1351000000000000000001");
      expect(firstRange.end).to.equal("1363000000000000000000");

      let endingRangeDetail = await prizePool.getDetailsFromEndingRange(
        firstRange.end
      );

      expect(endingRangeDetail.userAddress).to.equal(user5.address);
      expect(endingRangeDetail.indexInUserRanges).to.equal(0);
      expect(endingRangeDetail.start).to.equal(firstRange.start);

      const secondRange = await prizePool.getRangeDetails(user5.address, 1);

      expect(secondRange.start).to.equal("1425000000000000000001");
      expect(secondRange.end).to.equal("1575000000000000000000");

      endingRangeDetail = await prizePool.getDetailsFromEndingRange(
        secondRange.end
      );

      expect(endingRangeDetail.userAddress).to.equal(user5.address);
      expect(endingRangeDetail.indexInUserRanges).to.equal(1);
      expect(endingRangeDetail.start).to.equal(secondRange.start);

      const ThirdRange = await prizePool.getRangeDetails(user5.address, 2);

      expect(ThirdRange.start).to.equal("1385000000000000000001");
      expect(ThirdRange.end).to.equal("1415000000000000000000");

      endingRangeDetail = await prizePool.getDetailsFromEndingRange(
        ThirdRange.end
      );

      expect(endingRangeDetail.userAddress).to.equal(user5.address);
      expect(endingRangeDetail.indexInUserRanges).to.equal(2);
      expect(endingRangeDetail.start).to.equal(ThirdRange.start);

      const fourthRange = await prizePool.getRangeDetails(user5.address, 3);

      expect(fourthRange.start).to.equal("1329000000000000000001");
      expect(fourthRange.end).to.equal("1351000000000000000000");

      endingRangeDetail = await prizePool.getDetailsFromEndingRange(
        fourthRange.end
      );

      expect(endingRangeDetail.userAddress).to.equal(user5.address);
      expect(endingRangeDetail.indexInUserRanges).to.equal(3);
      expect(endingRangeDetail.start).to.equal(fourthRange.start);

      user6Ranges = await prizePool.totalUserRanges(user6.address);
      expect(user6Ranges).to.equal(2);

      user6Range = await prizePool.getRangeDetails(user6.address, 0);

      expect(user6Range.start).to.equal("1575000000000000000001");
      expect(user6Range.end).to.equal("1653000000000000000000");

      endingRangeDetail = await prizePool.getDetailsFromEndingRange(
        user6Range.end
      );

      expect(endingRangeDetail.userAddress).to.equal(user6.address);
      expect(endingRangeDetail.indexInUserRanges).to.equal(0);
      expect(endingRangeDetail.start).to.equal(user6Range.start);

      user6Range = await prizePool.getRangeDetails(user6.address, 1);

      expect(user6Range.start).to.equal("1415000000000000000001");
      expect(user6Range.end).to.equal("1425000000000000000000");

      endingRangeDetail = await prizePool.getDetailsFromEndingRange(
        user6Range.end
      );

      expect(endingRangeDetail.userAddress).to.equal(user6.address);
      expect(endingRangeDetail.indexInUserRanges).to.equal(1);
      expect(endingRangeDetail.start).to.equal(user6Range.start);

      const totalTicketsAfter = await prizePool.totalTicketNumber();

      // 40000000000000000000 from eligible
      expect(totalTickets).to.equal(
        totalTicketsAfter.add("40000000000000000000")
      );
    });

    it("Shuffling eligible and non eligible both(2) ", async () => {
      await multipleEligibleStakesSetupForShuffle();

      await forward(50);

      await multipleNonEligibleStakesForShuffle();

      const cooldownDuration = await prizePool.COOLDOWN_DURATION();

      await forward(Number(cooldownDuration));

      const totalEligibleForThisDraw =
        await prizePool.totalEligibleForThisDraw();
      const totalTickets = await prizePool.totalTicketNumber();

      expect(totalEligibleForThisDraw).to.equal("1385000000000000000000");
      expect(totalTickets).to.equal("1693000000000000000000");

      const ethAmount = "214";
      const unstakeWeiAmount = ethers.utils.parseEther(ethAmount);

      const totalUserRanges = await prizePool.totalUserRanges(user5.address);
      expect(totalUserRanges).to.equal(3);

      const firstRange = await prizePool.getRangeDetails(user5.address, 0);

      expect(firstRange.start).to.equal("1351000000000000000001");
      expect(firstRange.end).to.equal("1385000000000000000000");

      let endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        firstRange.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user5.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(0);
      expect(endingRangeDetails.start).to.equal(firstRange.start);

      const secondRange = await prizePool.getRangeDetails(user5.address, 1);

      expect(secondRange.start).to.equal("1425000000000000000001");
      expect(secondRange.end).to.equal("1575000000000000000000");

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        secondRange.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user5.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(1);
      expect(endingRangeDetails.start).to.equal(secondRange.start);

      const thirdRange = await prizePool.getRangeDetails(user5.address, 2);

      expect(thirdRange.start).to.equal("1663000000000000000001");
      expect(thirdRange.end).to.equal("1693000000000000000000");

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        thirdRange.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user5.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(2);
      expect(endingRangeDetails.start).to.equal(thirdRange.start);

      await prizePool.burnTickets(user5.address, unstakeWeiAmount);

      const totalEligibleForThisDrawAfter =
        await prizePool.totalEligibleForThisDraw();

      // 34000000000000000000 are being removed from eligible slots
      expect(totalEligibleForThisDrawAfter).to.equal(
        totalEligibleForThisDraw.sub("34000000000000000000")
      );

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        totalEligibleForThisDrawAfter
      );

      expect(endingRangeDetails.userAddress).to.equal(user4.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(0);

      const totalEmptyRanges = await prizePool.totalEmptyRanges();
      expect(totalEmptyRanges).to.equal(0);

      const user6Ranges = await prizePool.totalUserRanges(user6.address);

      expect(user6Ranges).to.equal(2);

      let user6Details = await prizePool.getRangeDetails(user6.address, 0);
      expect(user6Details.start).to.equal("1425000000000000000001");
      expect(user6Details.end).to.equal("1479000000000000000000");

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        user6Details.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user6.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(0);
      expect(endingRangeDetails.start).to.equal(user6Details.start);

      user6Details = await prizePool.getRangeDetails(user6.address, 1);

      expect(user6Details.start).to.equal("1351000000000000000001");
      expect(user6Details.end).to.equal("1385000000000000000000");

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        user6Details.end
      );

      expect(endingRangeDetails.userAddress).to.equal(user6.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(1);
      expect(endingRangeDetails.start).to.equal(user6Details.start);

      const totalTicketsAfter = await prizePool.totalTicketNumber();

      // 30+88+62+34
      expect(totalTicketsAfter).to.equal(
        totalTickets.sub("214000000000000000000")
      );

      endingRangeDetails = await prizePool.getDetailsFromEndingRange(
        totalTicketsAfter
      );

      expect(endingRangeDetails.userAddress).to.equal(user6.address);
      expect(endingRangeDetails.indexInUserRanges).to.equal(0);
      expect(endingRangeDetails.start).to.equal("1425000000000000000001");
    });
  });

  describe("Draw and winner functionality", () => {
    beforeEach(async () => {
      WinWin = await ethers.getContractFactory("WinToken");
      winToken = await WinWin.deploy("10000000000000");
      rewardToken1 = await WinWin.deploy("100000000000");
      rewardToken2 = await WinWin.deploy("100000000000");

      const lastTimestamp = (await waffle.provider.getBlock("latest"))
        .timestamp;

      WinStakingPool = await ethers.getContractFactory("WinStakingPool");

      winStakingPool = await WinStakingPool.deploy(
        winToken.address,
        lastTimestamp,
        "1000000000"
      );

      await winToken.transfer(winStakingPool.address, "1000000000");

      PrizePoolContract = await ethers.getContractFactory(
        "PrizePool",
        deployer
      );
      const prizeDistribution = [6000, 900, 600, 300, 100, 2100];
      prizePool = await PrizePoolContract.deploy(
        lastTimestamp + 50,
        deployer.address,
        prizeDistribution
      );

      RandomNumberContract = await ethers.getContractFactory("RandomNumber");
      randomNumber = await RandomNumberContract.deploy([
        deployer.address,
        prizePool.address,
      ]);

      await prizePool.setRandomNumber(randomNumber.address);

      await winStakingPool.setPrizePoolAddress(prizePool.address);

      await prizePool.connect(deployer).addRewardToken(rewardToken1.address);

      await prizePool.connect(deployer).addRewardToken(rewardToken2.address);

      let transferAmount = BigNumber.from("2000000000000000000000");

      await winToken.transfer(user1.address, transferAmount);
      await winToken.transfer(user2.address, transferAmount);
      await winToken.transfer(user3.address, transferAmount);

      let approvalAmount = BigNumber.from("100000000000000000000000000");

      await rewardToken1.approve(prizePool.address, approvalAmount);

      await rewardToken2.approve(prizePool.address, approvalAmount);

      await winToken
        .connect(user1)
        .approve(winStakingPool.address, approvalAmount);
      await winToken
        .connect(user2)
        .approve(winStakingPool.address, approvalAmount);
      await winToken
        .connect(user3)
        .approve(winStakingPool.address, approvalAmount);

      await prizePool.addPrizes(rewardToken1.address, "100000000000");
      await prizePool.addPrizes(rewardToken2.address, "400000000000");
    });

    it("claimWinning() function (require(invalid tier))", async () => {
      await expect(
        prizePool.claimWinning(user1.address, 1, [], [], 5)
      ).to.be.revertedWith("invalid tier");
    });

    it("ClaimWinning() function (require(draw not called))", async () => {
      const drawCount = await prizePool.drawCount();

      expect(await prizePool.drawCalled(drawCount)).to.equal(false);

      await expect(prizePool.claimWinning(user1.address, 1, [], [], 4)).to.be
        .reverted;
    });

    it("claimWinning() function (require(expired))", async () => {
      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.connect(user1).drawRandomNumber([]);

      const cooldownPeriod = await prizePool.COOLDOWN_DURATION();

      await forward(Number(cooldownPeriod));

      await expect(
        prizePool.claimWinning(user1.address, 1, [], [], 4)
      ).to.be.revertedWith("expired");
    });

    it("ClaimWinning() function (require(random number not fulfilled))", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);

      await expect(
        prizePool.claimWinning(user1.address, 1, [], [], 0)
      ).to.be.revertedWith("random number not fulfilled");
    });

    it("ClaimWinning() function (require(already a winner))", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      const randomNumbers = [
        "47968907019725692296446756416",
        "8828405098722274280464243240",
        "12572427517295820388507734763",
        "64995255806640244372499813186",
        "82063738418827343373433610258",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1814896833389218531772657897244",
        "3535541496863910026625995974365",
        "3159778153535706640243193897975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x6e2ec5c4366b2bc8eef5df9bae814316f401d216be8fe9841ff5d26325376ae2",
        "0x2f1d97ceb0c31fb6f21c4c73978deeb79ff84b8f12cef21a2e0201fd9e574646",
        "0xaeb16a90e4cda32af8ec3f750578248252ca24a7c236f3d47d87cfde8469f3e5",
        "0x453628d98c03a2ab7bc2ba9647478d40a97472a3255c08c795c4610ab8b31e5b",
        "0x9f7162ecb0b65868a1808a8fd4e5053fc63134d07b6429cdac931cb4449984e6",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xa7ad7ecb34cb43a0b5128c9a504dca0e680d9fa549b98ed1d2c406cda173f6fe",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0x9c1726a13e3fad634819e91f4517b32ed8d99097213b96cd6691e8cda33682eb",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);

      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      await prizePool.claimWinning(user1.address, 1, [], [], 0);

      await expect(
        prizePool.claimWinning(user1.address, 1, [], [], 0)
      ).to.be.revertedWith("already a winner");

      await expect(
        prizePool.claimWinning(user1.address, 1, [], [], 1)
      ).to.be.revertedWith("already a winner");
    });

    it("ClaimWinning() function (require(not a winner))", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      const randomNumbers = [
        "47968907019725692296446756416",
        "8828405098722274280464243240",
        "12572427517295820388507734763",
        "64995255806640244372499813186",
        "82063738418827343373433610258",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1814896833389218531772657897244",
        "3535541496863910026625995974365",
        "3159778153535706640243193897975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x6e2ec5c4366b2bc8eef5df9bae814316f401d216be8fe9841ff5d26325376ae2",
        "0x2f1d97ceb0c31fb6f21c4c73978deeb79ff84b8f12cef21a2e0201fd9e574646",
        "0xaeb16a90e4cda32af8ec3f750578248252ca24a7c236f3d47d87cfde8469f3e5",
        "0x453628d98c03a2ab7bc2ba9647478d40a97472a3255c08c795c4610ab8b31e5b",
        "0x9f7162ecb0b65868a1808a8fd4e5053fc63134d07b6429cdac931cb4449984e6",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xa7ad7ecb34cb43a0b5128c9a504dca0e680d9fa549b98ed1d2c406cda173f6fe",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0x9c1726a13e3fad634819e91f4517b32ed8d99097213b96cd6691e8cda33682eb",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);

      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      await prizePool.claimWinning(user1.address, 1, [], [], 0);

      await expect(
        prizePool.claimWinning(user2.address, 0, [user2.address], [0], 0)
      ).to.be.revertedWith("not a winner");

      await expect(
        prizePool.claimWinning(
          user2.address,
          0,

          [user1.address, user2.address],
          [0],
          0
        )
      ).to.be.revertedWith("not a winner");

      await expect(
        prizePool.claimWinning(
          user2.address,
          0,

          [
            user1.address,
            user1.address,
            user1.address,
            user1.address,
            user3.address,
          ],
          [0],
          0
        )
      ).to.be.revertedWith("not a winner");
    });

    it("ClaimWinning() function (require(not valid lengths))", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      const randomNumbers = [
        "47968907019725692296446756416",
        "8828405098722274280464243240",
        "12572427517295820388507734763",
        "64995255806640244372499813186",
        "82063738418827343373433610258",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1814896833389218531772657897244",
        "3535541496863910026625995974365",
        "3159778153535706640243193897975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x6e2ec5c4366b2bc8eef5df9bae814316f401d216be8fe9841ff5d26325376ae2",
        "0x2f1d97ceb0c31fb6f21c4c73978deeb79ff84b8f12cef21a2e0201fd9e574646",
        "0xaeb16a90e4cda32af8ec3f750578248252ca24a7c236f3d47d87cfde8469f3e5",
        "0x453628d98c03a2ab7bc2ba9647478d40a97472a3255c08c795c4610ab8b31e5b",
        "0x9f7162ecb0b65868a1808a8fd4e5053fc63134d07b6429cdac931cb4449984e6",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xa7ad7ecb34cb43a0b5128c9a504dca0e680d9fa549b98ed1d2c406cda173f6fe",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0x9c1726a13e3fad634819e91f4517b32ed8d99097213b96cd6691e8cda33682eb",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);

      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      await prizePool.claimWinning(user1.address, 1, [], [], 0);

      await expect(
        prizePool.claimWinning(user2.address, 0, [user1.address], [], 0)
      ).to.be.revertedWith("not valid lengths");

      await expect(
        prizePool.claimWinning(
          user2.address,
          0,

          [user1.address, user1.address],
          [0],
          0
        )
      ).to.be.revertedWith("not valid lengths");
    });

    it("ClaimWinning() function (require(tier already won))", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      const randomNumbers = [
        "47968907019725692296446756416",
        "8828405098722274280464243240",
        "12572427517295820388507734763",
        "64995255806640244372499813186",
        "82063738418827343373433610258",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1814896833389218531772657897244",
        "3535541496863910026625995974365",
        "3159778153535706640243193897975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x6e2ec5c4366b2bc8eef5df9bae814316f401d216be8fe9841ff5d26325376ae2",
        "0x2f1d97ceb0c31fb6f21c4c73978deeb79ff84b8f12cef21a2e0201fd9e574646",
        "0xaeb16a90e4cda32af8ec3f750578248252ca24a7c236f3d47d87cfde8469f3e5",
        "0x453628d98c03a2ab7bc2ba9647478d40a97472a3255c08c795c4610ab8b31e5b",
        "0x9f7162ecb0b65868a1808a8fd4e5053fc63134d07b6429cdac931cb4449984e6",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xa7ad7ecb34cb43a0b5128c9a504dca0e680d9fa549b98ed1d2c406cda173f6fe",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0x9c1726a13e3fad634819e91f4517b32ed8d99097213b96cd6691e8cda33682eb",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);

      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      const draw = await prizePool.drawCount();

      expect(await prizePool.tierWinner(draw.sub(1), 0)).to.equal(
        ethers.constants.AddressZero
      );

      await prizePool.claimWinning(user1.address, 1, [], [], 0);

      expect(await prizePool.tierWinner(draw.sub(1), 0)).to.equal(
        user1.address
      );

      await expect(
        prizePool.claimWinning(user2.address, 1, [], [], 0)
      ).to.be.revertedWith("tier already won");
    });

    it("ClaimWinning() function (require(exceeding limit))", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      const randomNumbers = [
        "47968907019725692296446756416",
        "8828405098722274280464243240",
        "12572427517295820388507734763",
        "64995255806640244372499813186",
        "82063738418827343373433610258",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1814896833389218531772657897244",
        "3535541496863910026625995974365",
        "3159778153535706640243193897975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x6e2ec5c4366b2bc8eef5df9bae814316f401d216be8fe9841ff5d26325376ae2",
        "0x2f1d97ceb0c31fb6f21c4c73978deeb79ff84b8f12cef21a2e0201fd9e574646",
        "0xaeb16a90e4cda32af8ec3f750578248252ca24a7c236f3d47d87cfde8469f3e5",
        "0x453628d98c03a2ab7bc2ba9647478d40a97472a3255c08c795c4610ab8b31e5b",
        "0x9f7162ecb0b65868a1808a8fd4e5053fc63134d07b6429cdac931cb4449984e6",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xa7ad7ecb34cb43a0b5128c9a504dca0e680d9fa549b98ed1d2c406cda173f6fe",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0x9c1726a13e3fad634819e91f4517b32ed8d99097213b96cd6691e8cda33682eb",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);

      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      const draw = await prizePool.drawCount();

      expect(await prizePool.tierWinner(draw.sub(1), 0)).to.equal(
        ethers.constants.AddressZero
      );

      await prizePool.claimWinning(user1.address, 1, [], [], 0);

      await expect(
        prizePool.claimWinning(
          user2.address,
          0,
          [
            user1.address,
            user1.address,
            user1.address,
            user1.address,
            user1.address,
          ],
          [1, 2, 3, 4, 5],
          1
        )
      ).to.be.revertedWith("exceeding limit");
    });

    it("ClaimWinning() function calculating winning index again because winning index user is already a winner", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      const randomNumbers = [
        "47968907019725692296446756416",
        "8828405098722274280464243240",
        "12572427517295820388507734763",
        "64995255806640244372499813186",
        "82063738418827343373433610258",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1814896833389218531772657897244",
        "3535541496863910026625995974365",
        "3159778153535706640243193897975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x6e2ec5c4366b2bc8eef5df9bae814316f401d216be8fe9841ff5d26325376ae2",
        "0x2f1d97ceb0c31fb6f21c4c73978deeb79ff84b8f12cef21a2e0201fd9e574646",
        "0xaeb16a90e4cda32af8ec3f750578248252ca24a7c236f3d47d87cfde8469f3e5",
        "0x453628d98c03a2ab7bc2ba9647478d40a97472a3255c08c795c4610ab8b31e5b",
        "0x9f7162ecb0b65868a1808a8fd4e5053fc63134d07b6429cdac931cb4449984e6",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xa7ad7ecb34cb43a0b5128c9a504dca0e680d9fa549b98ed1d2c406cda173f6fe",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0x9c1726a13e3fad634819e91f4517b32ed8d99097213b96cd6691e8cda33682eb",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);

      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      await prizePool.claimWinning(user1.address, 1, [], [], 0);

      await prizePool.claimWinning(
        user3.address,
        0,
        [user1.address, user1.address, user1.address],
        [1, 0, 0],
        1
      );
    });

    it("ClaimWinning() function calculating winning index again because winning index is an empty index", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const rewardAmount1 = BigNumber.from("100000000000");
      const rewardAmount2 = BigNumber.from("400000000000");

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      const randomNumbers = [
        "47968907019725692296446756416",
        "8828405098722274280464243240",
        "12572427517295820388507734763",
        "64995255806640244372499813186",
        "82063738418827343373433610258",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1857240000000000000000000",
        "3535541496863910026625995974365",
        "8269778153686906740243193898975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x6e2ec5c4366b2bc8eef5df9bae814316f401d216be8fe9841ff5d26325376ae2",
        "0x2f1d97ceb0c31fb6f21c4c73978deeb79ff84b8f12cef21a2e0201fd9e574646",
        "0xaeb16a90e4cda32af8ec3f750578248252ca24a7c236f3d47d87cfde8469f3e5",
        "0x453628d98c03a2ab7bc2ba9647478d40a97472a3255c08c795c4610ab8b31e5b",
        "0x9f7162ecb0b65868a1808a8fd4e5053fc63134d07b6429cdac931cb4449984e6",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xe625245df9a2593c8d138eb3c4bfec8ae4781cbc358dd5e5fdc88d1142c1af90",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0xf405764e4d780b0909e0d0e16743537fa01ee834f113d57b62269b96f19b91f1",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);

      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      expect(await rewardToken1.balanceOf(user1.address)).to.equal("0");
      expect(await rewardToken2.balanceOf(user1.address)).to.equal("0");

      await prizePool.claimWinning(user1.address, 1, [], [], 0);

      let tierPercentage = await prizePool.prizeDistributionsPercentage(0);

      expect(await rewardToken1.balanceOf(user1.address)).to.equal(
        rewardAmount1.mul(tierPercentage).div("10000")
      );
      expect(await rewardToken2.balanceOf(user1.address)).to.equal(
        rewardAmount2.mul(tierPercentage).div("10000")
      );

      expect(await rewardToken1.balanceOf(user3.address)).to.equal("0");
      expect(await rewardToken2.balanceOf(user3.address)).to.equal("0");

      await prizePool.claimWinning(
        user3.address,
        0,
        [user1.address, user1.address, user1.address],
        [0, 0, 0],
        1
      );

      tierPercentage = await prizePool.prizeDistributionsPercentage(1);

      expect(await rewardToken1.balanceOf(user3.address)).to.equal(
        rewardAmount1.mul(tierPercentage).div("10000")
      );
      expect(await rewardToken2.balanceOf(user3.address)).to.equal(
        rewardAmount2.mul(tierPercentage).div("10000")
      );

      const burnAmount = "20";
      const weiAmount = ethers.utils.parseEther(burnAmount);
      await prizePool.burnTickets(user4.address, weiAmount);

      const emptyRangeDetails = await prizePool.getEmptyRangeDetail(0);
      expect(emptyRangeDetails.start).to.equal("1331000000000000000001");
      expect(emptyRangeDetails.end).to.equal("1351000000000000000000");

      let draw = await prizePool.drawCount();
      expect(await prizePool.tierWinner(draw.sub(1), 2)).to.equal(
        ethers.constants.AddressZero
      );

      expect(await prizePool.isWinner(draw.sub(1), user2.address)).to.equal(
        false
      );

      expect(await rewardToken1.balanceOf(user2.address)).to.equal("0");
      expect(await rewardToken2.balanceOf(user2.address)).to.equal("0");

      await prizePool.claimWinning(
        user2.address,
        0,
        [
          user1.address,
          user1.address,
          ethers.constants.AddressZero,
          user3.address,
        ],
        [0, 1, 0, 0],
        2
      );
      draw = await prizePool.drawCount();
      expect(await prizePool.tierWinner(draw.sub(1), 2)).to.equal(
        user2.address
      );

      expect(await prizePool.isWinner(draw.sub(1), user2.address)).to.equal(
        true
      );

      tierPercentage = await prizePool.prizeDistributionsPercentage(2);

      expect(await rewardToken1.balanceOf(user2.address)).to.equal(
        rewardAmount1.mul(tierPercentage).div("10000")
      );
      expect(await rewardToken2.balanceOf(user2.address)).to.equal(
        rewardAmount2.mul(tierPercentage).div("10000")
      );
    });

    it("ClaimWinning() function when some winning indexes are zero", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const rewardAmount1 = BigNumber.from("100000000000");
      const rewardAmount2 = BigNumber.from("400000000000");

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      const randomNumbers = [
        "6925000000000000000000",
        "277000000000000000000000",
        "277000000000000000000000",
        "11204650000000000000000000",
        "47968907019725692296446756416",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1857240000000000000000000",
        "3535541496863910026625995974365",
        "8269778153686906740243193898975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x01c2a3cc9cd0091e3e20ba392653b255bd6ad0151e983756d5f1ab8875944f2d",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0x6e2ec5c4366b2bc8eef5df9bae814316f401d216be8fe9841ff5d26325376ae2",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xe625245df9a2593c8d138eb3c4bfec8ae4781cbc358dd5e5fdc88d1142c1af90",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0xf405764e4d780b0909e0d0e16743537fa01ee834f113d57b62269b96f19b91f1",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);
      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      expect(await rewardToken1.balanceOf(user1.address)).to.equal("0");
      expect(await rewardToken2.balanceOf(user1.address)).to.equal("0");

      await prizePool.claimWinning(
        user1.address,
        1,
        [
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
        ],
        [0, 0, 0, 0],
        0
      );

      const tierPercentage = await prizePool.prizeDistributionsPercentage(0);

      expect(await rewardToken1.balanceOf(user1.address)).to.equal(
        rewardAmount1.mul(tierPercentage).div("10000")
      );
      expect(await rewardToken2.balanceOf(user1.address)).to.equal(
        rewardAmount2.mul(tierPercentage).div("10000")
      );
    });

    it("users can claim prizes according to their balance at the ending draw time", async () => {
      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      const stakeAmount1 = BigNumber.from("1000000000000000000");

      const stakeAmount2 = BigNumber.from("5000000000000000");
      const stakeAmount3 = BigNumber.from("70000000000000000");

      await prizePool.connect(deployer).setStakingPool(winStakingPool.address);

      await winStakingPool.connect(user1).stake(stakeAmount1, [], [], true);

      await winStakingPool.connect(user2).stake(stakeAmount2, [], [], true);

      await winStakingPool.connect(user3).stake(stakeAmount3, [], [], true);

      const rewardAmount1 = BigNumber.from("100000000000");
      const rewardAmount2 = BigNumber.from("400000000000");

      const user1Reward1Balance = await rewardToken1.balanceOf(user1.address);
      const user1Reward2Balance = await rewardToken2.balanceOf(user1.address);

      await expect(
        prizePool.connect(user1).claimPrizes([0], user1.address)
      ).to.be.revertedWith("early");

      await expect(
        prizePool.connect(user1).drawRandomNumber([], [])
      ).to.be.revertedWith("early");

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      await prizePool.connect(user1).drawRandomNumber([], []);

      await expect(
        prizePool.connect(user1).claimPrizes([0], user1.address)
      ).to.be.revertedWith("early");

      const cooldownPeriod = await prizePool.COOLDOWN_DURATION();

      await forward(Number(cooldownPeriod));

      expect(await prizePool.drawRewardsClaimed(0, user1.address)).to.equal(
        false
      );

      await prizePool.connect(user1).claimPrizes([0], user1.address);

      const user1Reward1BalanceAfter = await rewardToken1.balanceOf(
        user1.address
      );
      const user1Reward2BalanceAfter = await rewardToken2.balanceOf(
        user1.address
      );
      const cycleStartTime = await prizePool.cycleStartTimestamp();

      const userBalance = await winStakingPool.getBalanceAt(
        user1.address,
        cycleStartTime + cycleDuration
      );

      const totalSupply = await winStakingPool.getTotalSupplyAt(
        cycleStartTime + cycleDuration
      );

      expect(user1Reward1BalanceAfter.sub(user1Reward1Balance)).to.equal(
        rewardAmount1.mul(userBalance).div(totalSupply)
      );

      expect(user1Reward2BalanceAfter.sub(user1Reward2Balance)).to.equal(
        rewardAmount2.mul(userBalance).div(totalSupply)
      );

      expect(await prizePool.drawRewardsClaimed(0, user1.address)).to.equal(
        true
      );

      await expect(
        prizePool.connect(user1).claimPrizes([0], user1.address)
      ).to.be.revertedWith("already claimed for the draw");

      const user2Reward1Balance = await rewardToken1.balanceOf(user2.address);
      const user2Reward2Balance = await rewardToken2.balanceOf(user2.address);

      expect(await prizePool.drawRewardsClaimed(0, user2.address)).to.equal(
        false
      );

      await prizePool.connect(user1).claimPrizes([0], user2.address);

      expect(await prizePool.drawRewardsClaimed(0, user2.address)).to.equal(
        true
      );

      const user2Reward1BalanceAfter = await rewardToken1.balanceOf(
        user2.address
      );
      const user2Reward2BalanceAfter = await rewardToken2.balanceOf(
        user2.address
      );

      const user2Balance = await winStakingPool.getBalanceAt(
        user2.address,
        cycleStartTime + cycleDuration
      );

      expect(user2Reward1BalanceAfter.sub(user2Reward1Balance)).to.equal(
        rewardAmount1.mul(user2Balance).div(totalSupply)
      );

      expect(user2Reward2BalanceAfter.sub(user2Reward2Balance)).to.equal(
        rewardAmount2.mul(user2Balance).div(totalSupply)
      );

      const user3Reward1Balance = await rewardToken1.balanceOf(user3.address);
      const user3Reward2Balance = await rewardToken2.balanceOf(user3.address);

      expect(await prizePool.drawRewardsClaimed(0, user3.address)).to.equal(
        false
      );

      await prizePool.connect(user1).claimPrizes([0], user3.address);

      expect(await prizePool.drawRewardsClaimed(0, user3.address)).to.equal(
        true
      );

      const user3Reward1BalanceAfter = await rewardToken1.balanceOf(
        user3.address
      );
      const user3Reward2BalanceAfter = await rewardToken2.balanceOf(
        user3.address
      );

      const user3Balance = await winStakingPool.getBalanceAt(
        user3.address,
        cycleStartTime + cycleDuration
      );

      expect(user3Reward1BalanceAfter.sub(user3Reward1Balance)).to.equal(
        rewardAmount1.mul(user3Balance).div(totalSupply)
      );

      expect(user3Reward2BalanceAfter.sub(user3Reward2Balance)).to.equal(
        rewardAmount2.mul(user3Balance).div(totalSupply)
      );
    });

    it("Can not call draw random before the draw date/30 days", async () => {
      const cycleStartTime = await prizePool.cycleStartTimestamp();
      const cycleDuration = await prizePool.CYCLE_DURATION();

      const lastTimestamp = (await waffle.provider.getBlock("latest"))
        .timestamp;

      expect(lastTimestamp).to.lessThan(cycleStartTime + cycleDuration);
      await expect(prizePool.drawRandomNumber([])).to.be.revertedWith("early");
    });

    it("Can call draw random on the draw date/30 days", async () => {
      //For testing adding 3 random numbers

      await multipleEligibleStakes();

      await unstakeEligible();

      await forward(50);

      await multipleNonEligibleStakes();

      const cycleStartTime = await prizePool.cycleStartTimestamp();
      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(Number(cycleDuration));

      const lastTimestamp = (await waffle.provider.getBlock("latest"))
        .timestamp;

      expect(lastTimestamp).to.greaterThan(cycleStartTime + cycleDuration);

      let randomNumbers = await prizePool.getLastDrawRandomNumbers();
      expect(randomNumbers.length).to.equal(0);

      let totalEligibleForThisDraw = await prizePool.totalEligibleForThisDraw();
      let totalTickets = await prizePool.totalTicketNumber();

      let lastDrawEligibleCount = await prizePool.lastDrawEligibleCount();

      expect(totalEligibleForThisDraw).to.equal("222000000000000000000");
      expect(totalTickets).to.equal("530000000000000000000");

      // It is first draw that's why previous count is 0
      expect(lastDrawEligibleCount).to.equal(0);

      const hashes = [
        "0x76ebf5cdbcf30f8ce5c578384f4d688392a870fe336d022c311753c60b01a225",
        "0xf1247f728f9135837575e0a3399f851e71d68d0902f0f09fa0638b5d44be8d7f",
        "0x8e2ba574dcafba49e79b283a9eddfff45efac4e2e0c770e3b2b931f919c76094",
        "0x76ebf5cdbcf30f8ce5c578384f4d688392a870fe336d022c311753c60b01a225",
        "0xf1247f728f9135837575e0a3399f851e71d68d0902f0f09fa0638b5d44be8d7f",
        "0x8e2ba574dcafba49e79b283a9eddfff45efac4e2e0c770e3b2b931f919c76094",
        "0x76ebf5cdbcf30f8ce5c578384f4d688392a870fe336d022c311753c60b01a225",
        "0xf1247f728f9135837575e0a3399f851e71d68d0902f0f09fa0638b5d44be8d7f",
        "0x8e2ba574dcafba49e79b283a9eddfff45efac4e2e0c770e3b2b931f919c76094",
        "0x76ebf5cdbcf30f8ce5c578384f4d688392a870fe336d022c311753c60b01a225",
        "0xf1247f728f9135837575e0a3399f851e71d68d0902f0f09fa0638b5d44be8d7f",
        "0x8e2ba574dcafba49e79b283a9eddfff45efac4e2e0c770e3b2b931f919c76094",
        "0x76ebf5cdbcf30f8ce5c578384f4d688392a870fe336d022c311753c60b01a225",
        "0xf1247f728f9135837575e0a3399f851e71d68d0902f0f09fa0638b5d44be8d7f",
        "0x8e2ba574dcafba49e79b283a9eddfff45efac4e2e0c770e3b2b931f919c76094",
        "0x76ebf5cdbcf30f8ce5c578384f4d688392a870fe336d022c311753c60b01a225",
        "0xf1247f728f9135837575e0a3399f851e71d68d0902f0f09fa0638b5d44be8d7f",
        "0x8e2ba574dcafba49e79b283a9eddfff45efac4e2e0c770e3b2b931f919c76094",
        "0x76ebf5cdbcf30f8ce5c578384f4d688392a870fe336d022c311753c60b01a225",
        "0xf1247f728f9135837575e0a3399f851e71d68d0902f0f09fa0638b5d44be8d7f",
        "0x8e2ba574dcafba49e79b283a9eddfff45efac4e2e0c770e3b2b931f919c76094",
        "0x76ebf5cdbcf30f8ce5c578384f4d688392a870fe336d022c311753c60b01a225",
        "0xf1247f728f9135837575e0a3399f851e71d68d0902f0f09fa0638b5d44be8d7f",
        "0x8e2ba574dcafba49e79b283a9eddfff45efac4e2e0c770e3b2b931f919c76094",
        "0x76ebf5cdbcf30f8ce5c578384f4d688392a870fe336d022c311753c60b01a225",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);

      lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.revealHash(lastRequestId, [
        "1452415",
        "23676217",
        "38267627",
        "1452415",
        "23676217",
        "38267627",
        "1452415",
        "23676217",
        "38267627",
        "1452415",
        "23676217",
        "38267627",
        "1452415",
        "23676217",
        "38267627",
        "1452415",
        "23676217",
        "38267627",
        "1452415",
        "23676217",
        "38267627",
        "1452415",
        "23676217",
        "38267627",
        "1452415",
      ]);
      await prizePool.claimWinning(user1.address, 0, [], [], 0);

      totalEligibleForThisDraw = await prizePool.totalEligibleForThisDraw();
      totalTickets = await prizePool.totalTicketNumber();

      lastDrawEligibleCount = await prizePool.lastDrawEligibleCount();

      expect(totalEligibleForThisDraw).to.equal("530000000000000000000");
      expect(totalTickets).to.equal("530000000000000000000");

      // It is first draw that's why count is equal to previous totalELigibleTickets

      expect(lastDrawEligibleCount).to.equal("222000000000000000000");

      randomNumbers = await prizePool.getLastDrawRandomNumbers();

      expect(randomNumbers.length).to.equal(25);

      const cycleStartTimestamp =
        await prizePool.getCurrentCycleStartTimestamp();
      const currentCycleEndingTimestamp =
        await prizePool.getCurrentCycleEndingTimestamp();

      // Cycyle start time wil also be updated

      expect(cycleStartTime + cycleDuration).to.equal(cycleStartTimestamp);

      expect(cycleStartTime + cycleDuration * 2).to.equal(
        currentCycleEndingTimestamp
      );
    });

    it("ClaimWinning() function should allow claiming tiers sequentially only", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      const randomNumbers = [
        "6925000000000000000000",
        "277000000000000000000000",
        "277000000000000000000000",
        "11204650000000000000000000",
        "47968907019725692296446756416",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1857240000000000000000000",
        "3535541496863910026625995974365",
        "8269778153686906740243193898975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x01c2a3cc9cd0091e3e20ba392653b255bd6ad0151e983756d5f1ab8875944f2d",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0x6e2ec5c4366b2bc8eef5df9bae814316f401d216be8fe9841ff5d26325376ae2",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xe625245df9a2593c8d138eb3c4bfec8ae4781cbc358dd5e5fdc88d1142c1af90",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0xf405764e4d780b0909e0d0e16743537fa01ee834f113d57b62269b96f19b91f1",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);
      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      expect(await rewardToken1.balanceOf(user1.address)).to.equal("0");
      expect(await rewardToken2.balanceOf(user1.address)).to.equal("0");

      await expect(
        prizePool.claimWinning(user1.address, 0, [], [], 1)
      ).to.be.revertedWith("verify or claim for previous tier first");

      await expect(
        prizePool.claimWinning(user1.address, 0, [], [], 2)
      ).to.be.revertedWith("verify or claim for previous tier first");

      await expect(
        prizePool.claimWinning(user1.address, 0, [], [], 3)
      ).to.be.revertedWith("verify or claim for previous tier first");

      await expect(
        prizePool.claimWinning(user1.address, 0, [], [], 4)
      ).to.be.revertedWith("verify or claim for previous tier first");
    });

    it("ClaimWinning() function should allow claiming tiers sequentially only if not verify previous tier", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const rewardAmount1 = BigNumber.from("100000000000");
      const rewardAmount2 = BigNumber.from("400000000000");

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      const randomNumbers = [
        "6925000000000000000000",
        "277000000000000000000000",
        "277000000000000000000000",
        "11204650000000000000000000",
        "11204650000000000000000000",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1857240000000000000000000",
        "3535541496863910026625995974365",
        "8269778153686906740243193898975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x01c2a3cc9cd0091e3e20ba392653b255bd6ad0151e983756d5f1ab8875944f2d",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xe625245df9a2593c8d138eb3c4bfec8ae4781cbc358dd5e5fdc88d1142c1af90",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0xf405764e4d780b0909e0d0e16743537fa01ee834f113d57b62269b96f19b91f1",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);
      await prizePool.drawRandomNumber([]);
      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      expect(await rewardToken1.balanceOf(user1.address)).to.equal("0");
      expect(await rewardToken2.balanceOf(user1.address)).to.equal("0");

      await expect(
        prizePool.claimWinning(user1.address, 0, [], [], 1)
      ).to.be.revertedWith("verify or claim for previous tier first");

      await prizePool.verifyNoWinnerForTier(
        0,
        [
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
        ],
        [0, 0, 0, 0, 0]
      );

      let draw = await prizePool.drawCount();

      let verifiedZeroTier = await prizePool.tierVerifiedForNoWinner(
        draw.sub(1),
        0
      );

      expect(verifiedZeroTier).to.equal(true);

      await prizePool.claimWinning(user1.address, 0, [], [], 1);

      const tierPercentage = await prizePool.prizeDistributionsPercentage(1);

      expect(await rewardToken1.balanceOf(user1.address)).to.equal(
        rewardAmount1.mul(tierPercentage).div("10000")
      );
      expect(await rewardToken2.balanceOf(user1.address)).to.equal(
        rewardAmount2.mul(tierPercentage).div("10000")
      );
    });

    it("ClaimWinning() if verified for one tier does not mean you can claim any tier.Can claim tier only after that", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      const randomNumbers = [
        "6925000000000000000000",
        "277000000000000000000000",
        "277000000000000000000000",
        "11204650000000000000000000",
        "11204650000000000000000000",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1857240000000000000000000",
        "3535541496863910026625995974365",
        "8269778153686906740243193898975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x01c2a3cc9cd0091e3e20ba392653b255bd6ad0151e983756d5f1ab8875944f2d",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xe625245df9a2593c8d138eb3c4bfec8ae4781cbc358dd5e5fdc88d1142c1af90",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0xf405764e4d780b0909e0d0e16743537fa01ee834f113d57b62269b96f19b91f1",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);
      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      expect(await rewardToken1.balanceOf(user1.address)).to.equal("0");
      expect(await rewardToken2.balanceOf(user1.address)).to.equal("0");

      await expect(
        prizePool.claimWinning(user1.address, 0, [], [], 1)
      ).to.be.revertedWith("verify or claim for previous tier first");

      await prizePool.verifyNoWinnerForTier(
        0,
        [
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
        ],
        [0, 0, 0, 0, 0]
      );

      let draw = await prizePool.drawCount();

      let verifiedZeroTier = await prizePool.tierVerifiedForNoWinner(
        draw.sub(1),
        0
      );

      expect(verifiedZeroTier).to.equal(true);

      //Verified for zero tier and not claiming for tier 2
      //Should not be allowed as only allowed tier is 1
      await expect(
        prizePool.claimWinning(user1.address, 0, [], [], 2)
      ).to.be.revertedWith("verify or claim for previous tier first");
    });

    it("verifyNoWinnerForTier() can only be called after draw has been called", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      await expect(prizePool.verifyNoWinnerForTier(0, [], [])).to.be.reverted;

      const randomNumbers = [
        "6925000000000000000000",
        "277000000000000000000000",
        "277000000000000000000000",
        "11204650000000000000000000",
        "11204650000000000000000000",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1857240000000000000000000",
        "3535541496863910026625995974365",
        "8269778153686906740243193898975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x01c2a3cc9cd0091e3e20ba392653b255bd6ad0151e983756d5f1ab8875944f2d",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xe625245df9a2593c8d138eb3c4bfec8ae4781cbc358dd5e5fdc88d1142c1af90",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0xf405764e4d780b0909e0d0e16743537fa01ee834f113d57b62269b96f19b91f1",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);
      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      await prizePool.verifyNoWinnerForTier(
        0,
        [
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
        ],
        [0, 0, 0, 0, 0]
      );
    });

    it("verifyNoWinnerForTier() can only be called during the claiming period that means before cooldown ends", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      await expect(prizePool.verifyNoWinnerForTier(0, [], [])).to.be.reverted;

      const randomNumbers = [
        "6925000000000000000000",
        "277000000000000000000000",
        "277000000000000000000000",
        "11204650000000000000000000",
        "11204650000000000000000000",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1857240000000000000000000",
        "3535541496863910026625995974365",
        "8269778153686906740243193898975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x01c2a3cc9cd0091e3e20ba392653b255bd6ad0151e983756d5f1ab8875944f2d",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xe625245df9a2593c8d138eb3c4bfec8ae4781cbc358dd5e5fdc88d1142c1af90",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0xf405764e4d780b0909e0d0e16743537fa01ee834f113d57b62269b96f19b91f1",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];
      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);
      await prizePool.drawRandomNumber([]);
      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      const cooldownDuration = await prizePool.COOLDOWN_DURATION();

      await forward(cooldownDuration);

      await expect(
        prizePool.verifyNoWinnerForTier(
          0,
          [
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
          ],
          [0, 0, 0, 0, 0]
        )
      ).to.be.revertedWith("expired");
    });

    it("verifyNoWinnerForTier() if a tier has already been claimed should not allow verifying after that", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      await expect(prizePool.verifyNoWinnerForTier(0, [], [])).to.be.reverted;

      const randomNumbers = [
        "6926000000000000000000",
        "277000000000000000000000",
        "277000000000000000000000",
        "11204650000000000000000000",
        "11204650000000000000000000",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1857240000000000000000000",
        "3535541496863910026625995974365",
        "8269778153686906740243193898975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x796769826140de0801e420bc663500b4811b8e3eabe4ca5c7b5ebf557fc8250a",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xe625245df9a2593c8d138eb3c4bfec8ae4781cbc358dd5e5fdc88d1142c1af90",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0xf405764e4d780b0909e0d0e16743537fa01ee834f113d57b62269b96f19b91f1",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];
      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);
      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      await prizePool.claimWinning(user1.address, 0, [], [], 0);

      await expect(
        prizePool.verifyNoWinnerForTier(
          0,
          [
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
          ],
          [0, 0, 0, 0, 0]
        )
      ).to.be.revertedWith("tier already won or verified");
    });

    it("verifyNoWinnerForTier() if a tier has already been verified should not allow verifying again", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      await expect(prizePool.verifyNoWinnerForTier(0, [], [])).to.be.reverted;

      const randomNumbers = [
        "6925000000000000000000",
        "277000000000000000000000",
        "277000000000000000000000",
        "11204650000000000000000000",
        "11204650000000000000000000",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1857240000000000000000000",
        "3535541496863910026625995974365",
        "8269778153686906740243193898975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x01c2a3cc9cd0091e3e20ba392653b255bd6ad0151e983756d5f1ab8875944f2d",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xe625245df9a2593c8d138eb3c4bfec8ae4781cbc358dd5e5fdc88d1142c1af90",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0xf405764e4d780b0909e0d0e16743537fa01ee834f113d57b62269b96f19b91f1",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);
      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);
      let draw = await prizePool.drawCount();

      let verifiedZeroTier = await prizePool.tierVerifiedForNoWinner(
        draw.sub(1),
        0
      );

      expect(verifiedZeroTier).to.equal(false);

      await prizePool.verifyNoWinnerForTier(
        0,
        [
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
        ],
        [0, 0, 0, 0, 0]
      );

      draw = await prizePool.drawCount();

      verifiedZeroTier = await prizePool.tierVerifiedForNoWinner(
        draw.sub(1),
        0
      );

      expect(verifiedZeroTier).to.equal(true);

      await expect(
        prizePool.verifyNoWinnerForTier(
          0,
          [
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
          ],
          [0, 0, 0, 0, 0]
        )
      ).to.be.revertedWith("tier already won or verified");
    });

    it("verifyNoWinnerForTier() parameters should be of same length and of 5 length", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      await expect(prizePool.verifyNoWinnerForTier(0, [], [])).to.be.reverted;

      const randomNumbers = [
        "6925000000000000000000",
        "277000000000000000000000",
        "277000000000000000000000",
        "11204650000000000000000000",
        "11204650000000000000000000",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1857240000000000000000000",
        "3535541496863910026625995974365",
        "8269778153686906740243193898975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x01c2a3cc9cd0091e3e20ba392653b255bd6ad0151e983756d5f1ab8875944f2d",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xe625245df9a2593c8d138eb3c4bfec8ae4781cbc358dd5e5fdc88d1142c1af90",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0xf405764e4d780b0909e0d0e16743537fa01ee834f113d57b62269b96f19b91f1",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);
      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);
      let draw = await prizePool.drawCount();

      let verifiedZeroTier = await prizePool.tierVerifiedForNoWinner(
        draw.sub(1),
        0
      );

      expect(verifiedZeroTier).to.equal(false);

      await expect(
        prizePool.verifyNoWinnerForTier(
          0,
          [
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
          ],
          [0, 0, 0, 0, 0]
        )
      ).to.be.revertedWith("not valid lengths");

      await expect(
        prizePool.verifyNoWinnerForTier(
          0,
          [
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
          ],
          [0, 0, 0, 0]
        )
      ).to.be.revertedWith("not valid lengths");

      draw = await prizePool.drawCount();

      verifiedZeroTier = await prizePool.tierVerifiedForNoWinner(
        draw.sub(1),
        0
      );

      expect(verifiedZeroTier).to.equal(false);
    });

    it("verifyNoWinnerForTier() Should not verify wrongly for a tier when there is winner and it says there is no winner and pass false winner", async () => {
      await multipleEligibleStakesSetupForShuffle();

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      await expect(prizePool.verifyNoWinnerForTier(0, [], [])).to.be.reverted;

      const randomNumbers = [
        "6925000000000000000000",
        "277000000000000000000000",
        "277000000000000000000000",
        "11204650000000000000000000",
        "52704650000000000000000000",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1857240000000000000000000",
        "3535541496863910026625995974365",
        "8269778153686906740243193898975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x01c2a3cc9cd0091e3e20ba392653b255bd6ad0151e983756d5f1ab8875944f2d",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0xfe45a39e521816f27e5290afb2088d02e398934babf42c23c8e38f81b05a056a",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xe625245df9a2593c8d138eb3c4bfec8ae4781cbc358dd5e5fdc88d1142c1af90",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0xf405764e4d780b0909e0d0e16743537fa01ee834f113d57b62269b96f19b91f1",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);
      await prizePool.drawRandomNumber([]);
      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      // I am making verifying tier 0 for no winners by giving all correct values
      let draw = await prizePool.drawCount();

      let verifiedZeroTier = await prizePool.tierVerifiedForNoWinner(
        draw.sub(1),
        0
      );

      expect(verifiedZeroTier).to.equal(false);

      await expect(
        prizePool.verifyNoWinnerForTier(
          0,
          [
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            ethers.constants.AddressZero,
            user2.address,
          ],
          [0, 0, 0, 0, 0]
        )
      ).to.be.revertedWith("not a winner");
    });

    it("verifyNoWinnerForTier() pass incorrect empty slots and try to make verify for the tier", async () => {
      await multipleEligibleStakesSetupForShuffle();

      let ethAmount = "500";
      const user1WeiAmount = ethers.utils.parseEther(ethAmount);
      await prizePool.burnTickets(user1.address, user1WeiAmount);

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      await expect(prizePool.verifyNoWinnerForTier(0, [], [])).to.be.reverted;

      const randomNumbers = [
        "6925000000000000000000",
        "277000000000000000000000",
        "277000000000000000000000",
        "11204650000000000000000000",
        "82704650000000000000000000",
        "1257000000000000000000",
        "1287000000000000000000",
        "1310000000000000000000",
        "608000000000000000000",
        "978000000000000000000",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1857240000000000000000000",
        "3535541496863910026625995974365",
        "8269778153686906740243193898975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x01c2a3cc9cd0091e3e20ba392653b255bd6ad0151e983756d5f1ab8875944f2d",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0xbffa6df2f067b30f2f612ad43863ba77067d244a79c3ca152e8ca8852836c185",
        "0x4bb03861160ec300938ddec795f6635867dd50c69d0def43145e06fde56d6b17",
        "0x7ef6184bfcf9688bc7720760048f79895c60591a71c502d1e871c8d707b09893",
        "0xa8f0169278a47d65be3bc3fb2ebdb46dd70da795d7e4d3f0cb2df1d17af51ba2",
        "0x46456179e1885c7bb869a8eb68d1d01cad51e077442d6d3a35f522a17c140300",
        "0xbebbb66b5eb83065323b019604550463c3cfded13441dbd7934dfb8c19a96907",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xe625245df9a2593c8d138eb3c4bfec8ae4781cbc358dd5e5fdc88d1142c1af90",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0xf405764e4d780b0909e0d0e16743537fa01ee834f113d57b62269b96f19b91f1",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];

      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);
      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      let draw = await prizePool.drawCount();

      let verifiedFirstTier = await prizePool.tierVerifiedForNoWinner(
        draw.sub(1),
        1
      );

      expect(verifiedFirstTier).to.equal(false);

      //Wrong slots
      await prizePool.verifyNoWinnerForTier(
        1,
        [
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
        ],
        [0, 1, 0, 1, 1]
      );

      draw = await prizePool.drawCount();

      verifiedFirstTier = await prizePool.tierVerifiedForNoWinner(
        draw.sub(1),
        1
      );

      expect(verifiedFirstTier).to.equal(false);

      //Now correct slots are provided
      await prizePool.verifyNoWinnerForTier(
        1,
        [
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
        ],
        [0, 0, 0, 1, 1]
      );

      draw = await prizePool.drawCount();

      verifiedFirstTier = await prizePool.tierVerifiedForNoWinner(
        draw.sub(1),
        1
      );

      expect(verifiedFirstTier).to.equal(true);
    });

    it("verifyNoWinnerForTier() pass incorrect winners and try to make verify for the tier", async () => {
      await multipleEligibleStakesSetupForShuffle();

      let ethAmount = "500";
      const user1WeiAmount = ethers.utils.parseEther(ethAmount);
      await prizePool.burnTickets(user1.address, user1WeiAmount);

      const cycleDuration = await prizePool.CYCLE_DURATION();

      await forward(cycleDuration + 50);

      await expect(prizePool.verifyNoWinnerForTier(0, [], [])).to.be.reverted;

      const randomNumbers = [
        "6925000000000000000000",
        "277000000000000000000000",
        "277000000000000000000000",
        "11204650000000000000000000",
        "25085586756630847703603398496",
        "65085586756630847703603398496",
        "12819207754275499439580709820",
        "9352451075977251988780742997604",
        "1593422928313014613442850612604",
        "7364215914823915768858861409971",
        "394981079594363675034394173048",
        "950132974311111096288802602754",
        "1857240000000000000000000",
        "3535541496863910026625995974365",
        "8269778153686906740243193898975",
        "6306209508754077664982814565285",
        "8774902160313977274617322797017",
        "3824189755307345143015127324047",
        "4930739227748112414400573045448",
        "2627782082167087372085577524745",
        "6970567439027578284016292878264",
        "613884450045723799518142070728",
        "1973342870131264665877888190185",
        "5210609155211827652857275606740",
        "5541817341787405630580242253650",
      ];

      const hashes = [
        "0x01c2a3cc9cd0091e3e20ba392653b255bd6ad0151e983756d5f1ab8875944f2d",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0xac30a3dcd8f0e109ec3fc6afff84b0c5b361aa849a03631e497af713dfd8d1e5",
        "0x5f0646f23ee07cce023984252ed0bb6909a00afc73fc319a27250ab0cd32d29f",
        "0xa8a41bf6d7a2bae037f62c6d397bb5650969f13fcf0821c81736ada9ed114ff3",
        "0xc874cfe5f144615b821d75e6b016ca475beddef0146838dfb0a144ef82ae0029",
        "0xcd5276a729c36f9e1e82e2e8f86789c216e76704f2a93389704d089abf8f7446",
        "0x5c3ac1c498eac70557bedaecfdee4a7750c380333a17d54e13b8b6fe1b504104",
        "0xa35671e0622b33f711f3dfb3e4578e6e2901c36e5331b12495bd7cfeada961f3",
        "0x408c4a8d0a720d22a5f4f50f6a3ba68df9b95449c6b7f7fcb296057e4e778ed4",
        "0x8fd08421df14a697c39c0b7dfd3544ffeb37fd7e1b393c7dc6ab7e8b852f50a1",
        "0xd94537fdd3c1f0075861a09c576550300415ad19e8ceb27367738a2056dc782e",
        "0xe625245df9a2593c8d138eb3c4bfec8ae4781cbc358dd5e5fdc88d1142c1af90",
        "0xdc032912b551f36d3f95a62d5b2baff9751c1cedaf554dec1ea35ac80ec57b61",
        "0xf405764e4d780b0909e0d0e16743537fa01ee834f113d57b62269b96f19b91f1",
        "0x2a6d8654bc46a735735162d9bcf124db3a7e211ba89d15e6cd72c8057dc0fb94",
        "0xd99a1c145231ee867910adcb562f4dfdb7d1614e5aec5c3d4bd86b4cdfbe55ba",
        "0xbffab2a574a26cbd7beb7039302b735014ac51618c479659203600caf27c52a8",
        "0x5287339e1b6cf6c29a4ce1060a3967bbf717f4d2ed6a63595af810b587c78332",
        "0x4e4cdacb7863b153e3a1e2cebc92dec7bef25223fd20a4ea05759ece4da9c912",
        "0xbff961d3f8043794f7f429e2a296dc6edea876c48b4c46e6906385a33f0e2351",
        "0x2315f14063b251c818fd96147183438a5311ac353d23ee6d0f738ba300410bdf",
        "0x0a9a2e6f17e2b52cf69111c0a50d28ee3fb791fafcd6475abed2b131366391fb",
        "0x1e351757c7c9a8a9d909ab00385268da844cef2c640cb444da7a316bf420f5b0",
        "0x9e20a627e13ef1bb7187d9ab20cec6b40e879821384ab0cd0a697d9c64975b32",
      ];
      let lastRequestId = await randomNumber.lastRequestId();

      await randomNumber.commitHash(lastRequestId.add(1), hashes);

      await prizePool.drawRandomNumber([]);
      lastRequestId = await randomNumber.lastRequestId();
      await randomNumber.revealHash(lastRequestId, randomNumbers);

      await prizePool.claimWinning(
        user1.address,
        0,
        [
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
        ],
        [0, 0, 0, 1],
        0
      );

      await prizePool.claimWinning(
        user3.address,
        0,
        [
          ethers.constants.AddressZero,
          ethers.constants.AddressZero,
          user1.address,
        ],
        [1, 1, 0],
        1
      );

      let draw = await prizePool.drawCount();

      let verifiedFirstTier = await prizePool.tierVerifiedForNoWinner(
        draw.sub(1),
        1
      );

      expect(verifiedFirstTier).to.equal(false);

      //Now incorrect winners and slots are provided
      await prizePool.verifyNoWinnerForTier(
        2,
        [
          user1.address,
          ethers.constants.AddressZero,
          user1.address,
          user3.address,
          user3.address,
        ],
        [0, 1, 0, 0, 0]
      );

      draw = await prizePool.drawCount();

      verifiedFirstTier = await prizePool.tierVerifiedForNoWinner(
        draw.sub(1),
        1
      );

      expect(verifiedFirstTier).to.equal(false);
    });
  });

  describe("Rewards functionality", () => {
    beforeEach(async () => {
      WinWin = await ethers.getContractFactory("WinToken");
      winToken = await WinWin.deploy("10000000000000");
      rewardToken1 = await WinWin.deploy("100000000000");
      rewardToken2 = await WinWin.deploy("100000000000");

      const lastTimestamp = (await waffle.provider.getBlock("latest"))
        .timestamp;

      WinStakingPool = await ethers.getContractFactory("WinStakingPool");

      winStakingPool = await WinStakingPool.deploy(
        winToken.address,
        lastTimestamp,
        "1000000000"
      );

      PrizePoolContract = await ethers.getContractFactory(
        "PrizePool",
        deployer
      );
      const prizeDistribution = [6000, 900, 600, 300, 100, 2100];
      prizePool = await PrizePoolContract.deploy(
        lastTimestamp + 50,
        deployer.address,
        prizeDistribution
      );

      await winStakingPool.setPrizePoolAddress(prizePool.address);

      await prizePool.connect(deployer).addRewardToken(rewardToken1.address);
    });

    it("Only owner can add reward tokens", async () => {
      expect(await prizePool.owner()).to.equal(deployer.address);
      await expect(
        prizePool.connect(user1).addRewardToken(rewardToken1.address)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Owner can add reward tokens", async () => {
      expect(await prizePool.owner()).to.equal(deployer.address);

      expect(
        await prizePool.isRewardTokenSupported(rewardToken2.address)
      ).to.equal(false);

      await prizePool.connect(deployer).addRewardToken(rewardToken2.address);

      expect(
        await prizePool.isRewardTokenSupported(rewardToken2.address)
      ).to.equal(true);

      expect(await prizePool.rewardTokens(1)).to.equal(rewardToken2.address);
    });

    it("Anyone can add prizes", async () => {
      const prizePoolRewardToken1Balance = await rewardToken1.balanceOf(
        prizePool.address
      );

      const currentDraw = await prizePool.drawCount();

      const previousBalance = await prizePool.totalRewardTokensForTheDraw(
        currentDraw,
        rewardToken1.address
      );

      const addedAmount = BigNumber.from("100000");
      await rewardToken1.approve(prizePool.address, addedAmount);

      await prizePool.addPrizes(rewardToken1.address, addedAmount);

      const prizePoolRewardToken1BalanceAfter = await rewardToken1.balanceOf(
        prizePool.address
      );

      const currentBalance = await prizePool.totalRewardTokensForTheDraw(
        currentDraw,
        rewardToken1.address
      );

      expect(currentBalance.sub(previousBalance)).to.equal(addedAmount);

      expect(
        prizePoolRewardToken1BalanceAfter.sub(prizePoolRewardToken1Balance)
      ).to.equal(addedAmount);
    });

    it("Only supported tokens reward can be added", async () => {
      expect(
        await prizePool.isRewardTokenSupported(rewardToken2.address)
      ).to.equal(false);

      await expect(
        prizePool.addPrizes(rewardToken2.address, "100")
      ).to.be.revertedWith("reward token not supported");
    });
  });

  describe("Restricted functions", () => {
    beforeEach(async () => {
      WinWin = await ethers.getContractFactory("WinToken");
      winToken = await WinWin.deploy("10000000000000");
      rewardToken1 = await WinWin.deploy("100000000000");
      rewardToken2 = await WinWin.deploy("100000000000");
      rewardToken3 = await WinWin.deploy("100000000000");

      const lastTimestamp = (await waffle.provider.getBlock("latest"))
        .timestamp;

      WinStakingPool = await ethers.getContractFactory("WinStakingPool");
      winStakingPool = await WinStakingPool.deploy(
        winToken.address,
        lastTimestamp,
        "1000000000"
      );

      PrizePoolContract = await ethers.getContractFactory(
        "PrizePool",
        deployer
      );

      const prizeDistribution = [6000, 900, 600, 300, 100, 2100];
      prizePool = await PrizePoolContract.deploy(
        lastTimestamp + 50,
        deployer.address,
        prizeDistribution
      );
      RandomNumberContract = await ethers.getContractFactory("RandomNumber");
      randomNumber = await RandomNumberContract.deploy([
        deployer.address,
        prizePool.address,
      ]);

      await prizePool.setRandomNumber(randomNumber.address);

      await winStakingPool.setPrizePoolAddress(prizePool.address);

      await prizePool.connect(deployer).addRewardToken(rewardToken1.address);

      await prizePool.connect(deployer).addRewardToken(rewardToken2.address);

      const transferAmount = BigNumber.from("100000000000000000000");

      await winToken.transfer(user1.address, transferAmount);

      await winToken.transfer(user2.address, transferAmount);

      await winToken.transfer(user3.address, transferAmount);

      const approvalAmount = BigNumber.from("10000000000000000000");

      await rewardToken1.approve(prizePool.address, approvalAmount);

      await rewardToken2.approve(prizePool.address, approvalAmount);

      await winToken
        .connect(user1)
        .approve(winStakingPool.address, approvalAmount);
      await winToken
        .connect(user2)
        .approve(winStakingPool.address, approvalAmount);
      await winToken
        .connect(user3)
        .approve(winStakingPool.address, approvalAmount);

      await prizePool.addPrizes(rewardToken1.address, "100000000000");
      await prizePool.addPrizes(rewardToken2.address, "400000000000");
    });

    it("can not set zero random address", async () => {
      const randomAddress = await prizePool.randomNumberAddress();

      expect(randomAddress).to.equal(randomNumber.address);

      await expect(
        prizePool.setRandomNumber(ethers.constants.AddressZero)
      ).to.be.revertedWith("Not valid address");
    });

    it("can not set zero staking pool address", async () => {
      let stakingPoolAddress = await prizePool.stakingPool();

      expect(stakingPoolAddress).to.equal(deployer.address);

      await expect(
        prizePool.setStakingPool(ethers.constants.AddressZero)
      ).to.be.revertedWith("Not valid address");

      await prizePool.setStakingPool(winStakingPool.address);

      stakingPoolAddress = await prizePool.stakingPool();

      expect(stakingPoolAddress).to.equal(winStakingPool.address);
    });

    it("can not add already supported reward token", async () => {
      let supported = await prizePool.isRewardTokenSupported(
        rewardToken1.address
      );
      expect(supported).to.equal(true);

      await expect(
        prizePool.addRewardToken(rewardToken1.address)
      ).to.be.revertedWith("reward token already supported");

      supported = await prizePool.isRewardTokenSupported(rewardToken3.address);

      expect(supported).to.equal(false);

      await prizePool.addRewardToken(rewardToken3.address);

      supported = await prizePool.isRewardTokenSupported(rewardToken3.address);

      expect(supported).to.equal(true);
    });
  });
});
