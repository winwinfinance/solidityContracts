import hre, { ethers, waffle } from "hardhat";
import { BigNumber, Contract, ContractFactory } from "ethers";
import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import { expect } from "chai";
import axios from "axios";
import { setBalance } from "@nomicfoundation/hardhat-network-helpers";

async function forward(seconds: any) {
  const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;
  await waffle.provider.send("evm_setNextBlockTimestamp", [
    lastTimestamp + seconds,
  ]);
  await waffle.provider.send("evm_mine", []);
}

describe("Loan Strategy test", () => {
  let deployer: SignerWithAddress;
  let user1: SignerWithAddress;
  let buyAndBurn: SignerWithAddress;
  let abi: any;
  let erc20Abi: any;
  let WinWin: ContractFactory;
  let winToken: Contract;
  let WinStakingPool: ContractFactory;
  let winStakingPool: Contract;
  let StakingPool: ContractFactory;
  let loanStakingPool: Contract;
  let LoanStrategy: ContractFactory;
  let loanStrategy: Contract;
  let PrizePool: ContractFactory;
  let winPrizePool: Contract;
  let loanPrizePool: Contract;
  let tokenSupply: BigNumber;
  const routerAddress = "0x98bf93ebf5c380C0e6Ae8e192A7e2AE08edAcc02";
  const WPLSAddress = "0xA1077a294dDE1B09bB078844df40758a5D0f9a27";
  const LOANAddress = "0x9159f1D2a9f51998Fc9Ab03fbd8f265ab14A1b3B";
  const llLOANStakingAddress = "0x853F0CD4B0083eDf7cFf5Ad9A296f02Ffb71C995";
  const USDLAddress = "0x0dEEd1486bc52aA0d3E6f8849cEC5adD6598A162";
  let routerInstance: any;
  let loanInstance: any;
  let usdlInstance: any;
  let WPLSInstance: any;

  beforeEach(async () => {
    if (!abi) {
      [deployer, user1, buyAndBurn] = await ethers.getSigners();
      const initialBalance = ethers.utils.parseEther("10000000000000000");

      await setBalance(deployer.address, initialBalance);
      await setBalance(user1.address, initialBalance);
      await setBalance(buyAndBurn.address, initialBalance);
      erc20Abi = await hre.artifacts.readArtifact(
        "@openzeppelin/contracts/token/ERC20/IERC20.sol:IERC20"
      );
      abi = await axios.get(
        `https://api.etherscan.io/api?module=contract&action=getabi&address=0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D&apikey=${process.env.ETHERSCAN_API_KEY}`
      );

      let path = [WPLSAddress, LOANAddress];

      routerInstance = new ethers.Contract(
        routerAddress,
        abi.data.result,
        deployer
      );
      let options = { value: ethers.utils.parseEther("100000000.0") };

      await routerInstance.swapExactETHForTokens(
        0,
        path,
        user1.address,
        "10000000000000",
        options
      );

      path = [WPLSAddress, USDLAddress];

      options = { value: ethers.utils.parseEther("100000000.0") };

      await routerInstance.swapExactETHForTokens(
        0,
        path,
        user1.address,
        "10000000000000",
        options
      );

      loanInstance = new ethers.Contract(LOANAddress, erc20Abi.abi, user1);

      usdlInstance = new ethers.Contract(USDLAddress, erc20Abi.abi, user1);

      WPLSInstance = new ethers.Contract(WPLSAddress, erc20Abi.abi, user1);
    }
    tokenSupply = BigNumber.from("100000000000000");
    WinWin = await ethers.getContractFactory("WinToken");
    winToken = await WinWin.deploy(tokenSupply);

    const block = await hre.ethers.provider.getBlock("latest");
    const totalRewards: BigNumber = BigNumber.from("10000000000000000000");

    WinStakingPool = await ethers.getContractFactory(
      "WinStakingPool",
      deployer
    );

    winStakingPool = await WinStakingPool.deploy(
      winToken.address,
      block.timestamp,
      totalRewards
    );
    await winToken.transfer(winStakingPool.address, totalRewards);

    StakingPool = await ethers.getContractFactory("YieldStakingPool", deployer);
    loanStakingPool = await StakingPool.deploy(LOANAddress);

    PrizePool = await ethers.getContractFactory("PrizePool", deployer);

    const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;

    const prizeDistribution = [6000, 900, 600, 300, 100, 2100];

    loanPrizePool = await PrizePool.deploy(
      lastTimestamp + 100,
      loanStakingPool.address,
      prizeDistribution
    );

    winPrizePool = await PrizePool.deploy(
      lastTimestamp + 100,
      winStakingPool.address,
      prizeDistribution
    );

    await loanStakingPool.setPrizePoolAddress(loanPrizePool.address);

    await winStakingPool.setPrizePoolAddress(winPrizePool.address);

    await winPrizePool.addRewardToken(USDLAddress);

    await loanPrizePool.addRewardToken(USDLAddress);

    await winPrizePool.addRewardToken(WPLSAddress);

    await loanPrizePool.addRewardToken(WPLSAddress);

    const distributionAdresses = [
      loanPrizePool.address,
      user1.address, // Setting user1 address for testing
      winPrizePool.address,
      winStakingPool.address,
      buyAndBurn.address,
    ];

    const distributionShares = [6000, 3000, 600, 300, 100];
    LoanStrategy = await ethers.getContractFactory("LOANStrategy", deployer);
    loanStrategy = await LoanStrategy.deploy(
      LOANAddress,
      USDLAddress,
      llLOANStakingAddress,
      distributionAdresses,
      distributionShares
    );

    await loanStakingPool.addReward(USDLAddress, loanStrategy.address);

    await loanStakingPool.addReward(WPLSAddress, loanStrategy.address);

    await winStakingPool.addReward(USDLAddress, loanStrategy.address);

    await winStakingPool.addReward(WPLSAddress, loanStrategy.address);

    await loanInstance
      .connect(user1)
      .approve(loanStakingPool.address, "10000000000000");

    await loanInstance
      .connect(user1)
      .approve(loanStrategy.address, "100000000000000000");
  });

  describe("Restricted functions test", () => {
    it("Can not 'Deposit' as deployer has no access", async function () {
      await expect(
        loanStrategy.connect(deployer).deposit(1000)
      ).to.be.revertedWith("Not WinLOANStaking");
    });

    it("Can not 'Withdraw' as deployer has no access", async function () {
      await expect(
        loanStrategy.connect(deployer).withdraw(1000)
      ).to.be.revertedWith("Not WinLOANStaking");
    });

    it("Successfully 'Distributed rewards", async function () {
      const loanTokenValue = 1000000;
      const transferAmount: BigNumber = ethers.utils.parseEther("1");
      await usdlInstance
        .connect(user1)
        .transfer(loanStrategy.address, transferAmount);

      await user1.sendTransaction({
        to: loanStrategy.address,
        value: transferAmount,
      });

      await loanStrategy.connect(user1).deposit(loanTokenValue);
      const distributionAddress = [
        loanPrizePool.address,
        loanStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];
      await loanStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      const loanStakingPoolBalance = await usdlInstance.balanceOf(
        loanStakingPool.address
      );

      const loanStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
        loanStakingPool.address
      );

      const loanPrizePoolInitialUSDLBalance = await usdlInstance.balanceOf(
        loanPrizePool.address
      );

      const loanPrizePoolPLSBalance = await await WPLSInstance.balanceOf(
        loanPrizePool.address
      );

      const winPrizePoolInitialUSDLBalance = await usdlInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPLSBalance = await await WPLSInstance.balanceOf(
        winPrizePool.address
      );

      const winStakingInitialUSDLBalance = await usdlInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingWPLSBalance = await WPLSInstance.balanceOf(
        winStakingPool.address
      );

      const buyAndBurnInitialUSDLBalance = await usdlInstance.balanceOf(
        buyAndBurn.address
      );

      const buyAndBurnPLSBalance = await buyAndBurn.getBalance();
      await forward(268000);

      await loanStrategy.connect(deployer).claimAndDistributeRewards();

      const loanStakingPoolBalanceAfterRewards = await usdlInstance.balanceOf(
        loanStakingPool.address
      );

      const currentStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
        loanStakingPool.address
      );

      const loanStakingPoolPercentage =
        await loanStrategy.getLoanStakingPercent();

      const totalPercent = await loanStrategy.TOTAL_PERCENT();

      expect(
        loanStakingPoolBalanceAfterRewards.sub(loanStakingPoolBalance)
      ).to.be.equal(
        transferAmount.mul(loanStakingPoolPercentage).div(totalPercent)
      );

      expect(
        currentStakingPoolWPLSBalance.sub(loanStakingPoolWPLSBalance)
      ).to.be.equal(
        transferAmount.mul(loanStakingPoolPercentage).div(totalPercent)
      );

      const loanPrizePoolUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        loanPrizePool.address
      );

      const currentLoanPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        loanPrizePool.address
      );

      const loanPrizePoolPercentage =
        await loanStrategy.getLoanPrizePoolPercent();

      expect(
        loanPrizePoolUSDLBalanceAfterRewards.sub(
          loanPrizePoolInitialUSDLBalance
        )
      ).to.be.equal(
        transferAmount.mul(loanPrizePoolPercentage).div(totalPercent)
      );

      expect(
        currentLoanPrizePoolPLSBalance.sub(loanPrizePoolPLSBalance)
      ).to.be.equal(
        transferAmount.mul(loanPrizePoolPercentage).div(totalPercent)
      );

      const winPrizePoolUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        winPrizePool.address
      );

      const currentWinPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPercentage =
        await loanStrategy.getWinPrizePoolPercent();

      expect(
        winPrizePoolUSDLBalanceAfterRewards.sub(winPrizePoolInitialUSDLBalance)
      ).to.be.equal(
        transferAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      expect(
        currentWinPrizePoolPLSBalance.sub(winPrizePoolPLSBalance)
      ).to.be.equal(
        transferAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      const winStakingUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        winStakingPool.address
      );

      const currentWinStakingPLSBalance = await WPLSInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingPercentage = await loanStrategy.getWinStakingPercent();

      expect(
        winStakingUSDLBalanceAfterRewards.sub(winStakingInitialUSDLBalance)
      ).to.be.equal(transferAmount.mul(winStakingPercentage).div(totalPercent));

      expect(
        currentWinStakingPLSBalance.sub(winStakingWPLSBalance)
      ).to.be.equal(transferAmount.mul(winStakingPercentage).div(totalPercent));

      const buyAndBurnUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        buyAndBurn.address
      );
      const currentBuyAndBurnPLSBalance = await buyAndBurn.getBalance();
      const buyAndBurnPercentage = await loanStrategy.getBuyAndBurnPercent();

      expect(
        buyAndBurnUSDLBalanceAfterRewards.sub(buyAndBurnInitialUSDLBalance)
      ).to.be.equal(transferAmount.mul(buyAndBurnPercentage).div(totalPercent));

      expect(currentBuyAndBurnPLSBalance.sub(buyAndBurnPLSBalance)).to.be.equal(
        transferAmount.mul(buyAndBurnPercentage).div(totalPercent)
      );
    });

    it("Can not change addresses. Only deployer has the permission", async function () {
      const distributionAddress = [
        loanPrizePool.address,
        loanStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];
      await expect(
        loanStrategy
          .connect(user1)
          .changeDistributionAddresses(distributionAddress)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Successfully changed address.", async function () {
      let distributionAddress = [
        user1.address,
        loanStakingPool.address,
        user1.address,
        user1.address,
        user1.address,
      ];
      await loanStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      expect(await loanStrategy.getWinLOANStakingAddress()).to.equal(
        loanStakingPool.address
      );

      expect(await loanStrategy.getWinStakingAddress()).to.equal(user1.address);

      expect(await loanStrategy.getLoanPrizePoolAddress()).to.equal(
        user1.address
      );

      expect(await loanStrategy.getBuyAndBurnAddress()).to.equal(user1.address);

      expect(await loanStrategy.getWinPrizePoolAddress()).to.equal(
        user1.address
      );
      distributionAddress = [
        loanPrizePool.address,
        loanStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];
      await loanStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);
    });
    it("Can not change shares. Only deployer has the permission.", async function () {
      const distributionShares = [7000, 2000, 700, 200, 100];

      await expect(
        loanStrategy
          .connect(user1)
          .updateDistributionPercentages(distributionShares)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });
    it("Distribution shares sum should be equal to 100%", async function () {
      const distributionShares = [7000, 2000, 700, 200, 50];
      await expect(
        loanStrategy.updateDistributionPercentages(distributionShares)
      ).to.be.revertedWith("Sum of shares is not 10000.");
    });
    it("Successfully updated distribution shares.", async function () {
      let distributionShares = [7000, 2000, 700, 200, 100];
      await loanStrategy.updateDistributionPercentages(distributionShares);
      expect(await loanStrategy.getLoanPrizePoolPercent()).to.equal(7000);
      expect(await loanStrategy.getLoanStakingPercent()).to.equal(2000);
      expect(await loanStrategy.getWinPrizePoolPercent()).to.equal(700);
      expect(await loanStrategy.getWinStakingPercent()).to.equal(200);
      expect(await loanStrategy.getBuyAndBurnPercent()).to.equal(100);
      // reveting the change
      distributionShares = [6000, 3000, 600, 300, 100];
      await loanStrategy.updateDistributionPercentages(distributionShares);
    });
    it("Can not send stuck tokens. Only deployer has the permission.", async function () {
      await expect(
        loanStrategy
          .connect(user1)
          .inCaseTokensGetStuck(LOANAddress, 7000, user1.address)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });
  });

  describe("Deposit and withdraw functionality test", () => {
    it("Successful 'Deposit'", async function () {
      const loanTokenValue = 3000000;
      const user1LOANBalance = await loanInstance.balanceOf(user1.address);

      await loanStrategy.connect(user1).deposit(loanTokenValue);

      const user1LOANBalanceAfterDeposit = await loanInstance.balanceOf(
        user1.address
      );

      expect(await loanStrategy.getWantLockedTotal()).to.equal(loanTokenValue);

      expect(await loanStrategy.getTotalStakedBalance()).to.equal(
        loanTokenValue
      );

      // let us consider user1 address as LOAN staking contract of WinWin.
      expect(user1LOANBalanceAfterDeposit).to.equal(
        BigInt(user1LOANBalance) - BigInt(loanTokenValue)
      );
    });

    it("Successful 'Withdraw'", async function () {
      const loanTokenValue = 1000000;

      await loanStrategy.connect(user1).deposit(loanTokenValue);

      const user1LOANBalance = await loanInstance.balanceOf(user1.address);

      await loanStrategy.connect(user1).withdraw(loanTokenValue);

      const user1LOANBalanceAfterWithdraw = await loanInstance.balanceOf(
        user1.address
      );

      expect(await loanStrategy.getWantLockedTotal()).to.equal(0);

      // let us consider user1 address as LOAN staking contract of WinWin.
      expect(user1LOANBalanceAfterWithdraw).to.equal(
        BigInt(user1LOANBalance) + BigInt(loanTokenValue)
      );
    });
  });

  describe("Recover token testcases", () => {
    it("Owner can not send LOAN Tokens.", async function () {
      await expect(
        loanStrategy
          .connect(deployer)
          .inCaseTokensGetStuck(LOANAddress, 7000, user1.address)
      ).to.be.revertedWith("Can not send LOAN tokens");
    });

    it("Owner can not send USDL Tokens.", async function () {
      await expect(
        loanStrategy.inCaseTokensGetStuck(USDLAddress, 7000, user1.address)
      ).to.be.revertedWith("Can not send USDL tokens");
    });

    it("Owner can not send WPLS Tokens.", async function () {
      await expect(
        loanStrategy.inCaseTokensGetStuck(WPLSAddress, 7000, user1.address)
      ).to.be.revertedWith("Can not send WPLS tokens");
    });

    it("deployer can recover other tokens", async function () {
      const transferAmount: BigNumber = BigNumber.from("1000000");
      await winToken.transfer(loanStrategy.address, transferAmount);

      const previousBalance = await winToken.balanceOf(user1.address);

      await loanStrategy.inCaseTokensGetStuck(
        winToken.address,
        transferAmount,
        user1.address
      );

      const currentBalance = await winToken.balanceOf(user1.address);

      expect(currentBalance.sub(previousBalance)).to.equal(transferAmount);
    });
  });
  describe("Automation Test", () => {
    it("Successfully 'Distributed rewards' while staking", async function () {
      await loanStakingPool.modifyStrategyAddress(loanStrategy.address);
      const loanTokenValue = 1000000;
      const transferAmount: BigNumber = ethers.utils.parseEther("1");

      await usdlInstance
        .connect(user1)
        .transfer(loanStrategy.address, transferAmount);

      await user1.sendTransaction({
        to: loanStrategy.address,
        value: transferAmount,
      });

      await loanStrategy.connect(user1).deposit(loanTokenValue);
      const distributionAddress = [
        loanPrizePool.address,
        loanStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];
      await loanStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      const loanStakingPoolBalance = await usdlInstance.balanceOf(
        loanStakingPool.address
      );

      const loanStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
        loanStakingPool.address
      );

      const loanPrizePoolInitialUSDLBalance = await usdlInstance.balanceOf(
        loanPrizePool.address
      );

      const loanPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        loanPrizePool.address
      );

      const winPrizePoolInitialUSDLBalance = await usdlInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        winPrizePool.address
      );

      const winStakingInitialUSDLBalance = await usdlInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingWPLSBalance = await WPLSInstance.balanceOf(
        winStakingPool.address
      );

      const buyAndBurnInitialUSDLBalance = await usdlInstance.balanceOf(
        buyAndBurn.address
      );

      const buyAndBurnPLSBalance = await buyAndBurn.getBalance();

      await forward(86400);

      await loanStakingPool.connect(user1).stake("100000000", [], [], true);

      const loanStakingPoolBalanceAfterRewards = await usdlInstance.balanceOf(
        loanStakingPool.address
      );

      const currentStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
        loanStakingPool.address
      );

      const loanStakingPoolPercentage =
        await loanStrategy.getLoanStakingPercent();

      const totalPercent = await loanStrategy.TOTAL_PERCENT();

      expect(
        loanStakingPoolBalanceAfterRewards.sub(loanStakingPoolBalance)
      ).to.be.equal(
        transferAmount.mul(loanStakingPoolPercentage).div(totalPercent)
      );

      expect(
        currentStakingPoolWPLSBalance.sub(loanStakingPoolWPLSBalance)
      ).to.be.equal(
        transferAmount.mul(loanStakingPoolPercentage).div(totalPercent)
      );

      const loanPrizePoolUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        loanPrizePool.address
      );

      const currentLoanPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        loanPrizePool.address
      );

      const loanPrizePoolPercentage =
        await loanStrategy.getLoanPrizePoolPercent();

      expect(
        loanPrizePoolUSDLBalanceAfterRewards.sub(
          loanPrizePoolInitialUSDLBalance
        )
      ).to.be.equal(
        transferAmount.mul(loanPrizePoolPercentage).div(totalPercent)
      );

      expect(
        currentLoanPrizePoolPLSBalance.sub(loanPrizePoolPLSBalance)
      ).to.be.equal(
        transferAmount.mul(loanPrizePoolPercentage).div(totalPercent)
      );

      const winPrizePoolUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        winPrizePool.address
      );

      const currentWinPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPercentage =
        await loanStrategy.getWinPrizePoolPercent();

      expect(
        winPrizePoolUSDLBalanceAfterRewards.sub(winPrizePoolInitialUSDLBalance)
      ).to.be.equal(
        transferAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      expect(
        currentWinPrizePoolPLSBalance.sub(winPrizePoolPLSBalance)
      ).to.be.equal(
        transferAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      const winStakingUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        winStakingPool.address
      );

      const currentWinStakingPLSBalance = await WPLSInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingPercentage = await loanStrategy.getWinStakingPercent();

      expect(
        winStakingUSDLBalanceAfterRewards.sub(winStakingInitialUSDLBalance)
      ).to.be.equal(transferAmount.mul(winStakingPercentage).div(totalPercent));

      expect(
        currentWinStakingPLSBalance.sub(winStakingWPLSBalance)
      ).to.be.equal(transferAmount.mul(winStakingPercentage).div(totalPercent));

      const buyAndBurnUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        buyAndBurn.address
      );
      const currentBuyAndBurnPLSBalance = await buyAndBurn.getBalance();
      const buyAndBurnPercentage = await loanStrategy.getBuyAndBurnPercent();

      expect(
        buyAndBurnUSDLBalanceAfterRewards.sub(buyAndBurnInitialUSDLBalance)
      ).to.be.equal(transferAmount.mul(buyAndBurnPercentage).div(totalPercent));

      expect(currentBuyAndBurnPLSBalance.sub(buyAndBurnPLSBalance)).to.be.equal(
        transferAmount.mul(buyAndBurnPercentage).div(totalPercent)
      );
    });
    it("Successfully 'Distributed rewards' while unstaking", async function () {
      await loanStakingPool.modifyStrategyAddress(loanStrategy.address);
      const loanTokenValue = 1000000;
      const transferAmount: BigNumber = ethers.utils.parseEther("1");

      await usdlInstance
        .connect(user1)
        .transfer(loanStrategy.address, transferAmount);

      await user1.sendTransaction({
        to: loanStrategy.address,
        value: transferAmount,
      });

      await loanStrategy.connect(user1).deposit(loanTokenValue);
      const distributionAddress = [
        loanPrizePool.address,
        loanStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];
      await loanStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      const loanStakingPoolBalance = await usdlInstance.balanceOf(
        loanStakingPool.address
      );

      const loanStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
        loanStakingPool.address
      );

      const loanPrizePoolInitialUSDLBalance = await usdlInstance.balanceOf(
        loanPrizePool.address
      );

      const loanPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        loanPrizePool.address
      );

      const winPrizePoolInitialUSDLBalance = await usdlInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        winPrizePool.address
      );

      const winStakingInitialUSDLBalance = await usdlInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingWPLSBalance = await WPLSInstance.balanceOf(
        winStakingPool.address
      );

      const buyAndBurnInitialUSDLBalance = await usdlInstance.balanceOf(
        buyAndBurn.address
      );

      const buyAndBurnPLSBalance = await buyAndBurn.getBalance();

      await loanStakingPool.connect(user1).stake("100000000", [], [], true);

      await forward(86400);

      await loanStakingPool.connect(user1).unstake("100000000");

      const loanStakingPoolBalanceAfterRewards = await usdlInstance.balanceOf(
        loanStakingPool.address
      );

      const currentStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
        loanStakingPool.address
      );

      const loanStakingPoolPercentage =
        await loanStrategy.getLoanStakingPercent();

      const totalPercent = await loanStrategy.TOTAL_PERCENT();

      expect(
        loanStakingPoolBalanceAfterRewards.sub(loanStakingPoolBalance)
      ).to.be.equal(
        transferAmount.mul(loanStakingPoolPercentage).div(totalPercent)
      );

      expect(
        currentStakingPoolWPLSBalance.sub(loanStakingPoolWPLSBalance)
      ).to.be.equal(
        transferAmount.mul(loanStakingPoolPercentage).div(totalPercent)
      );

      const loanPrizePoolUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        loanPrizePool.address
      );

      const currentLoanPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        loanPrizePool.address
      );

      const loanPrizePoolPercentage =
        await loanStrategy.getLoanPrizePoolPercent();

      expect(
        loanPrizePoolUSDLBalanceAfterRewards.sub(
          loanPrizePoolInitialUSDLBalance
        )
      ).to.be.equal(
        transferAmount.mul(loanPrizePoolPercentage).div(totalPercent)
      );

      expect(
        currentLoanPrizePoolPLSBalance.sub(loanPrizePoolPLSBalance)
      ).to.be.equal(
        transferAmount.mul(loanPrizePoolPercentage).div(totalPercent)
      );

      const winPrizePoolUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        winPrizePool.address
      );

      const currentWinPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPercentage =
        await loanStrategy.getWinPrizePoolPercent();

      expect(
        winPrizePoolUSDLBalanceAfterRewards.sub(winPrizePoolInitialUSDLBalance)
      ).to.be.equal(
        transferAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      expect(
        currentWinPrizePoolPLSBalance.sub(winPrizePoolPLSBalance)
      ).to.be.equal(
        transferAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      const winStakingUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        winStakingPool.address
      );

      const currentWinStakingPLSBalance = await WPLSInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingPercentage = await loanStrategy.getWinStakingPercent();

      expect(
        winStakingUSDLBalanceAfterRewards.sub(winStakingInitialUSDLBalance)
      ).to.be.equal(transferAmount.mul(winStakingPercentage).div(totalPercent));

      expect(
        currentWinStakingPLSBalance.sub(winStakingWPLSBalance)
      ).to.be.equal(transferAmount.mul(winStakingPercentage).div(totalPercent));

      const buyAndBurnUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        buyAndBurn.address
      );
      const currentBuyAndBurnPLSBalance = await buyAndBurn.getBalance();
      const buyAndBurnPercentage = await loanStrategy.getBuyAndBurnPercent();

      expect(
        buyAndBurnUSDLBalanceAfterRewards.sub(buyAndBurnInitialUSDLBalance)
      ).to.be.equal(transferAmount.mul(buyAndBurnPercentage).div(totalPercent));

      expect(currentBuyAndBurnPLSBalance.sub(buyAndBurnPLSBalance)).to.be.equal(
        transferAmount.mul(buyAndBurnPercentage).div(totalPercent)
      );
    });
    it("Successfully 'Distributed rewards' while calling claimAndDistributeRewards()", async function () {
      await loanStakingPool.modifyStrategyAddress(loanStrategy.address);
      const loanTokenValue = 1000000;
      const transferAmount: BigNumber = ethers.utils.parseEther("1");

      await usdlInstance
        .connect(user1)
        .transfer(loanStrategy.address, transferAmount);

      await user1.sendTransaction({
        to: loanStrategy.address,
        value: transferAmount,
      });

      await loanStrategy.connect(user1).deposit(loanTokenValue);
      const distributionAddress = [
        loanPrizePool.address,
        loanStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];
      await loanStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      const loanStakingPoolBalance = await usdlInstance.balanceOf(
        loanStakingPool.address
      );

      const loanStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
        loanStakingPool.address
      );

      const loanPrizePoolInitialUSDLBalance = await usdlInstance.balanceOf(
        loanPrizePool.address
      );

      const loanPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        loanPrizePool.address
      );

      const winPrizePoolInitialUSDLBalance = await usdlInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        winPrizePool.address
      );

      const winStakingInitialUSDLBalance = await usdlInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingWPLSBalance = await WPLSInstance.balanceOf(
        winStakingPool.address
      );

      const buyAndBurnInitialUSDLBalance = await usdlInstance.balanceOf(
        buyAndBurn.address
      );

      const buyAndBurnPLSBalance = await buyAndBurn.getBalance();

      await forward(268000);

      await loanStrategy.connect(deployer).claimAndDistributeRewards();

      const loanStakingPoolBalanceAfterRewards = await usdlInstance.balanceOf(
        loanStakingPool.address
      );

      const currentStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
        loanStakingPool.address
      );

      const loanStakingPoolPercentage =
        await loanStrategy.getLoanStakingPercent();

      const totalPercent = await loanStrategy.TOTAL_PERCENT();

      expect(
        loanStakingPoolBalanceAfterRewards.sub(loanStakingPoolBalance)
      ).to.be.equal(
        transferAmount.mul(loanStakingPoolPercentage).div(totalPercent)
      );

      expect(
        currentStakingPoolWPLSBalance.sub(loanStakingPoolWPLSBalance)
      ).to.be.equal(
        transferAmount.mul(loanStakingPoolPercentage).div(totalPercent)
      );

      const loanPrizePoolUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        loanPrizePool.address
      );

      const currentLoanPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        loanPrizePool.address
      );

      const loanPrizePoolPercentage =
        await loanStrategy.getLoanPrizePoolPercent();

      expect(
        loanPrizePoolUSDLBalanceAfterRewards.sub(
          loanPrizePoolInitialUSDLBalance
        )
      ).to.be.equal(
        transferAmount.mul(loanPrizePoolPercentage).div(totalPercent)
      );

      expect(
        currentLoanPrizePoolPLSBalance.sub(loanPrizePoolPLSBalance)
      ).to.be.equal(
        transferAmount.mul(loanPrizePoolPercentage).div(totalPercent)
      );

      const winPrizePoolUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        winPrizePool.address
      );

      const currentWinPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPercentage =
        await loanStrategy.getWinPrizePoolPercent();

      expect(
        winPrizePoolUSDLBalanceAfterRewards.sub(winPrizePoolInitialUSDLBalance)
      ).to.be.equal(
        transferAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      expect(
        currentWinPrizePoolPLSBalance.sub(winPrizePoolPLSBalance)
      ).to.be.equal(
        transferAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      const winStakingUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        winStakingPool.address
      );

      const currentWinStakingPLSBalance = await WPLSInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingPercentage = await loanStrategy.getWinStakingPercent();

      expect(
        winStakingUSDLBalanceAfterRewards.sub(winStakingInitialUSDLBalance)
      ).to.be.equal(transferAmount.mul(winStakingPercentage).div(totalPercent));

      expect(
        currentWinStakingPLSBalance.sub(winStakingWPLSBalance)
      ).to.be.equal(transferAmount.mul(winStakingPercentage).div(totalPercent));

      const buyAndBurnUSDLBalanceAfterRewards = await usdlInstance.balanceOf(
        buyAndBurn.address
      );
      const currentBuyAndBurnPLSBalance = await buyAndBurn.getBalance();
      const buyAndBurnPercentage = await loanStrategy.getBuyAndBurnPercent();

      expect(
        buyAndBurnUSDLBalanceAfterRewards.sub(buyAndBurnInitialUSDLBalance)
      ).to.be.equal(transferAmount.mul(buyAndBurnPercentage).div(totalPercent));

      expect(currentBuyAndBurnPLSBalance.sub(buyAndBurnPLSBalance)).to.be.equal(
        transferAmount.mul(buyAndBurnPercentage).div(totalPercent)
      );
    });
  });

  describe("Loan strategy integeration test", () => {
    it("can not set zero address as strategy address", async () => {
      await expect(
        loanStakingPool
          .connect(deployer)
          .modifyStrategyAddress("0x0000000000000000000000000000000000000000")
      ).to.be.revertedWith("Not valid address");
    });

    it("Update stategy contract address", async () => {
      await loanStakingPool
        .connect(deployer)
        .modifyStrategyAddress(loanStrategy.address);

      expect(await loanStakingPool.getStrategyAddress()).to.equal(
        loanStrategy.address
      );
    });

    it("New strategy address can not same as current strategy address", async () => {
      await loanStakingPool
        .connect(deployer)
        .modifyStrategyAddress(loanStrategy.address);
      await expect(
        loanStakingPool
          .connect(deployer)
          .modifyStrategyAddress(loanStrategy.address)
      ).to.be.revertedWith("This is current strategy address.");
    });

    it("Only admin can update stategy contract address", async () => {
      await expect(
        loanStakingPool
          .connect(user1)
          .modifyStrategyAddress(loanStrategy.address)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("User can stake successfully", async () => {
      const distributionAdresses = [
        loanPrizePool.address,
        loanStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];

      await loanStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAdresses);
      await loanStakingPool
        .connect(deployer)
        .modifyStrategyAddress(loanStrategy.address);
      const loanTokenValue = 3000000;

      const user1LOANBalance = await loanInstance.balanceOf(user1.address);

      await loanStakingPool.connect(user1).stake(loanTokenValue, [], [], true);

      const user1LOANBalanceAfterStake = await loanInstance.balanceOf(
        user1.address
      );

      expect(user1LOANBalanceAfterStake).to.equal(
        BigInt(user1LOANBalance) - BigInt(loanTokenValue)
      );

      const balance = await loanStakingPool.getBalance(
        user1.address,
        0,
        loanInstance.address
      );

      expect(balance._stakedAmount).to.equal(loanTokenValue);
    });

    it("user can unstake successfully", async () => {
      const distributionAdresses = [
        loanPrizePool.address,
        loanStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];

      await loanStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAdresses);
      await loanStakingPool
        .connect(deployer)
        .modifyStrategyAddress(loanStrategy.address);

      const stakeAmount = 3000000;

      await loanStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const unstakeAmount = 1000000;

      const user1LOANBalance = await loanInstance.balanceOf(user1.address);

      await loanStakingPool.connect(user1).unstake(unstakeAmount);

      const user1LOANBalanceAfterUnstake = await loanInstance.balanceOf(
        user1.address
      );

      expect(user1LOANBalanceAfterUnstake).to.equal(
        BigInt(user1LOANBalance) + BigInt(unstakeAmount)
      );

      const balance = await loanStakingPool.getBalance(
        user1.address,
        0,
        loanInstance.address
      );

      expect(balance._stakedAmount).to.equal(stakeAmount - unstakeAmount);
    });

    it("Successful 'claim' but can not access till one day", async function () {
      await expect(
        loanStrategy.connect(deployer).claimAndDistributeRewards()
      ).to.be.revertedWith("Wait till one-day since last claimed time");
    });
  });
});
