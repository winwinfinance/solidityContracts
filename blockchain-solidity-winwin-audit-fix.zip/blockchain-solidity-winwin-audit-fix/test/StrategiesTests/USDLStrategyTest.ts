import hre, { ethers, waffle } from "hardhat";
import { BigNumber, Contract, ContractFactory } from "ethers";
import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import { expect } from "chai";
import axios from "axios";
import { setBalance } from "@nomicfoundation/hardhat-network-helpers";

async function forward(seconds: any) {
  const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;
  await waffle.provider.send("evm_setNextBlockTimestamp", [
    lastTimestamp + seconds,
  ]);
  await waffle.provider.send("evm_mine", []);
}

describe("USDL Strategy test", () => {
  let deployer: SignerWithAddress;
  let user1: SignerWithAddress;
  let user2: SignerWithAddress;
  let buyAndBurn: SignerWithAddress;
  let abi: any;
  let erc20Abi: any;
  let WinWin: ContractFactory;
  let winToken: Contract;
  let WinStakingPool: ContractFactory;
  let winStakingPool: Contract;
  let UsdlStakingPool: ContractFactory;
  let usdlStakingPool: Contract;
  let usdlStrategy: Contract;
  let PrizePool: ContractFactory;
  let usdlPrizePool: Contract;
  let winPrizePool: Contract;
  const LOANAddress = "0x9159f1D2a9f51998Fc9Ab03fbd8f265ab14A1b3B";
  const llstabiltyPoolAddress = "0x7bFD406632483ad00c6EdF655E04De91A96f84bc";
  const USDLAddress = "0x0dEEd1486bc52aA0d3E6f8849cEC5adD6598A162";
  const routerAddress = "0x165C3410fC91EF562C50559f7d2289fEbed552d9";
  const WPLSAddress = "0xA1077a294dDE1B09bB078844df40758a5D0f9a27";
  const DAIAddress = "0xefD766cCb38EaF1dfd701853BFCe31359239F305";
  const frontendTagAddress = "0x0000000000000000000000000000000000000000";
  let routerInstance: any;
  let loanInstance: any;
  let usdlInstance: any;
  let stabilityPoolInstance: any;

  beforeEach(async () => {
    if (!abi) {
      [deployer, user1, buyAndBurn, user2] = await ethers.getSigners();

              // Set Ether balances
      const initialBalance = ethers.utils.parseEther("100000000000000"); 

      await setBalance(deployer.address, initialBalance);
      await setBalance(user1.address, initialBalance);
      await setBalance(user2.address, initialBalance);
      await setBalance(buyAndBurn.address, initialBalance);
      erc20Abi = await hre.artifacts.readArtifact(
        "@openzeppelin/contracts/token/ERC20/IERC20.sol:IERC20"
      );
      abi = await axios.get(
        `https://api.etherscan.io/api?module=contract&action=getabi&address=0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D&apikey=${process.env.ETHERSCAN_API_KEY}`
      );

      const stabilityPoolAbi = await axios.get(
        `https://api.etherscan.io/api?module=contract&action=getabi&address=0x66017D22b0f8556afDd19FC67041899Eb65a21bb&apikey=${process.env.ETHERSCAN_API_KEY}`
      );
      stabilityPoolInstance = new ethers.Contract(
        llstabiltyPoolAddress,
        stabilityPoolAbi.data.result,
        deployer
      );

      let path = [WPLSAddress, LOANAddress];

      // await hre.network.provider.send("hardhat_setBalance", [
      //   deployer.address,
      //   "0x100000000000000000000",
      // ]);

      routerInstance = new ethers.Contract(
        routerAddress,
        abi.data.result,
        deployer
      );
      let options = { value: ethers.utils.parseEther("10000000000.0") };

      await routerInstance.swapExactETHForTokens(
        0,
        path,
        user1.address,
        "10000000000000",
        options
      );

      path = [WPLSAddress, USDLAddress];

      options = { value: ethers.utils.parseEther("10000000000.0") };

      await routerInstance.swapExactETHForTokens(
        0,
        path,
        user1.address,
        "10000000000000",
        options
      );

      loanInstance = new ethers.Contract(LOANAddress, erc20Abi.abi, user1);

      usdlInstance = new ethers.Contract(USDLAddress, erc20Abi.abi, user1);
    }
    WinWin = await ethers.getContractFactory("WinToken");
    winToken = await WinWin.deploy("100000000000000");

    const block = await hre.ethers.provider.getBlock("latest");
    const totalRewards: BigNumber = BigNumber.from("10000000000000000000");

    WinStakingPool = await ethers.getContractFactory(
      "WinStakingPool",
      deployer
    );

    winStakingPool = await WinStakingPool.deploy(
      winToken.address,
      block.timestamp,
      totalRewards
    );
    await winToken.transfer(winStakingPool.address, totalRewards);

    UsdlStakingPool = await ethers.getContractFactory(
      "YieldStakingPool",
      deployer
    );
    usdlStakingPool = await UsdlStakingPool.deploy(USDLAddress);

    const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;

    PrizePool = await ethers.getContractFactory("PrizePool", deployer);

    const prizeDistribution = [6000, 900, 600, 300, 100, 2100];
    usdlPrizePool = await PrizePool.deploy(
      lastTimestamp + 100,
      usdlStakingPool.address,
      prizeDistribution
    );

    winPrizePool = await PrizePool.deploy(
      lastTimestamp + 100,
      winStakingPool.address,
      prizeDistribution
    );

    await winStakingPool.setPrizePoolAddress(winPrizePool.address);
    await usdlStakingPool.setPrizePoolAddress(usdlPrizePool.address);

    await winPrizePool.addRewardToken(loanInstance.address);
    await usdlPrizePool.addRewardToken(loanInstance.address);

    const distributionAddresses = [
      usdlPrizePool.address,
      user1.address,
      winPrizePool.address,
      winStakingPool.address,
      buyAndBurn.address,
    ];
    const distributionShares = [6000, 3000, 600, 300, 100];

    const usdlStrategyContract = await ethers.getContractFactory(
      "USDLStrategy",
      deployer
    );
    usdlStrategy = await usdlStrategyContract.deploy(
      routerAddress,
      LOANAddress,
      USDLAddress,
      llstabiltyPoolAddress,
      distributionAddresses,
      distributionShares
    );

    const path = [WPLSAddress, USDLAddress];
    await usdlStrategy.setSwapPath(path);

    await usdlStakingPool.addReward(LOANAddress, usdlStrategy.address);

    await winStakingPool.addReward(LOANAddress, usdlStrategy.address);

    await loanInstance
      .connect(user1)
      .approve(usdlStakingPool.address, "10000000000000000000");

    await loanInstance
      .connect(user1)
      .approve(usdlStrategy.address, "10000000000000000000000");
    await usdlInstance
      .connect(user1)
      .approve(usdlStakingPool.address, "1000000000000000000000000");
    await usdlInstance
      .connect(user1)
      .approve(usdlStrategy.address, "1000000000000000000000000000000000");
  });

  describe("Restricted functions test", () => {
    it("Can not 'Deposit' as owner has no access", async function () {
      await expect(
        usdlStrategy.connect(deployer).deposit(1000)
      ).to.be.revertedWith("Not WinUSDLStaking");
    });

    it("Can not 'Withdraw' as owner has no access", async function () {
      await expect(
        usdlStrategy.connect(deployer).withdraw(1000)
      ).to.be.revertedWith("Not WinUSDLStaking");
    });

    it("Successfully 'Distributed rewards", async function () {
      const usdlTokenValue = 1000000;

      await usdlStrategy.connect(user1).deposit(usdlTokenValue);

      const distributionAddress = [
        usdlPrizePool.address,
        usdlStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];
      await usdlStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      const stakingPoolBalance = await loanInstance.balanceOf(
        usdlStakingPool.address
      );

      const usdlPrizePoolInitialUSDLBalance = await loanInstance.balanceOf(
        usdlPrizePool.address
      );

      const winPrizePoolInitialUSDLBalance = await loanInstance.balanceOf(
        winPrizePool.address
      );

      const winStakingInitialUSDLBalance = await loanInstance.balanceOf(
        winStakingPool.address
      );

      const buyAndBurnInitialUSDLBalance = await loanInstance.balanceOf(
        buyAndBurn.address
      );

      await forward(268000);
      // accumulate the rewards without withdrawing USDL
      await usdlStrategy.connect(deployer).harvest();
      // loan rewards accumulated in contract after 1 day of deposit
      const rewardsAmount = await loanInstance.balanceOf(usdlStrategy.address);

      await usdlStrategy.connect(deployer).claimAndDistributeRewards();

      const stakingPoolBalanceAfterRewards = await loanInstance.balanceOf(
        usdlStakingPool.address
      );

      const stakingPoolPercentage = await usdlStrategy.getUSDLStakingPercent();

      const totalPercent = await usdlStrategy.TOTAL_PERCENT();

      expect(
        stakingPoolBalanceAfterRewards.sub(stakingPoolBalance)
      ).to.be.equal(rewardsAmount.mul(stakingPoolPercentage).div(totalPercent));

      const usdlPrizePoolUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        usdlPrizePool.address
      );

      const usdlPrizePoolPercentage =
        await usdlStrategy.getUSDLPrizePoolPercent();

      expect(
        usdlPrizePoolUSDLBalanceAfterRewards.sub(
          usdlPrizePoolInitialUSDLBalance
        )
      ).to.be.equal(
        rewardsAmount.mul(usdlPrizePoolPercentage).div(totalPercent)
      );

      const winPrizePoolUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPercentage =
        await usdlStrategy.getWinPrizePoolPercent();

      expect(
        winPrizePoolUSDLBalanceAfterRewards.sub(winPrizePoolInitialUSDLBalance)
      ).to.be.equal(
        rewardsAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      const winStakingUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingPercentage = await usdlStrategy.getWinStakingPercent();

      expect(
        winStakingUSDLBalanceAfterRewards.sub(winStakingInitialUSDLBalance)
      ).to.be.equal(rewardsAmount.mul(winStakingPercentage).div(totalPercent));

      const buyAndBurnUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        buyAndBurn.address
      );

      const buyAndBurnPercentage = await usdlStrategy.getBuyAndBurnPercent();

      expect(
        buyAndBurnUSDLBalanceAfterRewards.sub(buyAndBurnInitialUSDLBalance)
      ).to.be.equal(rewardsAmount.mul(buyAndBurnPercentage).div(totalPercent));
    });

    it("Can not change addresses. Only owner has the permission", async function () {
      const distributionAddress = [
        usdlPrizePool.address,
        usdlStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];
      await expect(
        usdlStrategy
          .connect(user1)
          .changeDistributionAddresses(distributionAddress)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Successfully changed address.", async function () {
      let distributionAddress = [
        user1.address,
        usdlStakingPool.address,
        user1.address,
        user1.address,
        user1.address,
      ];
      await usdlStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      expect(await usdlStrategy.getWinUSDLStakingAddress()).to.equal(
        usdlStakingPool.address
      );

      expect(await usdlStrategy.getFrontEndTagAddress()).to.equal(
        frontendTagAddress
      );
      expect(await usdlStrategy.getLOANTokenAddress()).to.equal(LOANAddress);
      expect(await usdlStrategy.getUSDLTokenAddress()).to.equal(USDLAddress);

      expect(await usdlStrategy.getWinPrizePoolAddress()).to.equal(
        user1.address
      );
      distributionAddress = [
        usdlPrizePool.address,
        user1.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];
      await usdlStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);
    });
    it("Can not change router address. Only owner has the permission.", async function () {
      await expect(
        usdlStrategy.connect(user1).setRouterAddress(user2.address)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });
    it("Owner can change Router Address", async function () {
      await expect(
        usdlStrategy.connect(deployer).setRouterAddress(user1.address)
      ).to.be.ok;
      // reverting back to original value for other tests
      await expect(
        usdlStrategy.connect(deployer).setRouterAddress(routerAddress)
      ).to.be.ok;
    });
    it("Can not change swap path. Only owner has the permission.", async function () {
      const newPath = [WPLSAddress, USDLAddress];
      await expect(
        usdlStrategy.connect(user1).setSwapPath(newPath)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });
    it("Owner can set swap path", async function () {
      const newPath = [WPLSAddress, USDLAddress];
      await expect(usdlStrategy.connect(deployer).setSwapPath(newPath)).to.be
        .ok;
    });
    it("should fail when swapping PLS to USDL with incorrect path", async function () {
      const usdlTokenValue = BigNumber.from("3000000000000000000");

      await usdlStrategy.connect(user1).deposit(usdlTokenValue);

      expect(await usdlStrategy.getPendingUSDLGain()).to.equal(usdlTokenValue);

      const newPath = [WPLSAddress, user1.address, USDLAddress];
      await usdlStrategy.connect(deployer).setSwapPath(newPath);

      await forward(300);

      // Transferring some PLS as PLS can only be gained on liquidation

      const transferAmount: BigNumber = ethers.utils.parseEther("1");

      await user1.sendTransaction({
        to: usdlStrategy.address,
        value: transferAmount,
      });
      try {
        // Act
        await usdlStrategy.harvest();
        // If the transaction does not revert, this line will be reached, causing the test to fail
        expect.fail("Transaction should have reverted");
      } catch (error) {
        // Assert
        expect(error.message).to.include(
          "Transaction reverted without a reason string"
        );
      }
    });
    it("should be able to swap PLS to USDL with 3 address path", async function () {
      const usdlTokenValue = BigNumber.from("3000000000000000000");

      await usdlStrategy.connect(user1).deposit(usdlTokenValue);

      expect(await usdlStrategy.getPendingUSDLGain()).to.equal(usdlTokenValue);

      const newPath = [WPLSAddress, DAIAddress, USDLAddress];
      await usdlStrategy.connect(deployer).setSwapPath(newPath);

      await forward(300);

      // Transferring some PLS as PLS can only be gained on liquidation

      const transferAmount: BigNumber = ethers.utils.parseEther("1");

      await user1.sendTransaction({
        to: usdlStrategy.address,
        value: transferAmount,
      });

      const result = await routerInstance.getAmountsOut(
        transferAmount,
        newPath
      );

      await usdlStrategy.harvest();

      expect(await usdlStrategy.getPendingUSDLGain()).to.equal(
        usdlTokenValue.add(result[2])
      );
    });
    it("Swap path must begin with WPLS", async function () {
      const newPath = [user1.address, USDLAddress];
      await expect(
        usdlStrategy.connect(deployer).setSwapPath(newPath)
      ).to.be.revertedWith("Starting token must be WPLS");
    });
    it("Swap path must end with USDL", async function () {
      const newPath = [WPLSAddress, user1.address];
      await expect(
        usdlStrategy.connect(deployer).setSwapPath(newPath)
      ).to.be.revertedWith("Ending token must be USDL");
    });
    it("Swap path can contain more than 2 addresses", async function () {
      const newPath = [WPLSAddress, user1.address, USDLAddress];
      await expect(usdlStrategy.connect(deployer).setSwapPath(newPath)).to.be
        .ok;
      // reverting back to original path
      const oldPath = [WPLSAddress, USDLAddress];
      await expect(usdlStrategy.connect(deployer).setSwapPath(oldPath)).to.be
        .ok;
    });
    it("Can not change shares. Only owner has the permission.", async function () {
      const distributionShares = [7000, 2000, 700, 200, 100];
      await expect(
        usdlStrategy
          .connect(user1)
          .updateDistributionPercentages(distributionShares)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Distribution shares sum should be equal to 100%", async function () {
      const distributionShares = [7000, 2000, 700, 200, 50];
      await expect(
        usdlStrategy.updateDistributionPercentages(distributionShares)
      ).to.be.revertedWith("Sum of shares is not 10000.");
    });

    it("Successfully updated distribution shares.", async function () {
      let distributionShares = [7000, 2000, 700, 200, 100];
      await usdlStrategy.updateDistributionPercentages(distributionShares);
      expect(await usdlStrategy.getUSDLPrizePoolPercent()).to.equal(7000);
      expect(await usdlStrategy.getUSDLStakingPercent()).to.equal(2000);
      expect(await usdlStrategy.getWinPrizePoolPercent()).to.equal(700);
      expect(await usdlStrategy.getWinStakingPercent()).to.equal(200);
      expect(await usdlStrategy.getBuyAndBurnPercent()).to.equal(100);

      // reverting the distribution change
      distributionShares = [6000, 3000, 600, 300, 100];
      await usdlStrategy.updateDistributionPercentages(distributionShares);
    });

    it("Can not send stuck tokens. Only owner has the permission.", async function () {
      await expect(
        usdlStrategy
          .connect(user1)
          .inCaseTokensGetStuck(LOANAddress, 7000, user1.address)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Only owner can update frontEndTag Address", async function () {
      await expect(
        usdlStrategy.connect(user1).updateFrontEndTag(deployer.address)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });
  });

  describe("Deposit and withdraw functionality test", () => {
    it("Successful 'Deposit'", async function () {
      const usdlTokenValue = 3000000;

      const user1USDLBalance = await usdlInstance.balanceOf(user1.address);

      await usdlStrategy.connect(user1).deposit(usdlTokenValue);

      const user1USDLBalanceAfterDeposit = await usdlInstance.balanceOf(
        user1.address
      );

      expect(await usdlStrategy.getPendingUSDLGain()).to.equal(usdlTokenValue);

      expect(user1USDLBalanceAfterDeposit).to.equal(
        BigInt(user1USDLBalance) - BigInt(usdlTokenValue)
      );
    });

    it("Successful 'Withdraw'", async function () {
      const usdlTokenValue = 1000000;

      await usdlStrategy.connect(user1).deposit(usdlTokenValue);

      const user1USDLBalance = await usdlInstance.balanceOf(user1.address);

      await usdlStrategy.connect(user1).withdraw(usdlTokenValue);

      const user1USDLBalanceAfterWithdraw = await usdlInstance.balanceOf(
        user1.address
      );

      expect(await usdlStrategy.getPendingUSDLGain()).to.equal(0);

      expect(user1USDLBalanceAfterWithdraw).to.equal(
        BigInt(user1USDLBalance) + BigInt(usdlTokenValue)
      );
    });

    it("During withdrawal , pls will be swapped to USDL to complete the withdrawal", async function () {
      const usdlTokenValue = 1000000;
      const transferAmount: BigNumber = ethers.utils.parseEther("1");

      await usdlStrategy.connect(user1).deposit(usdlTokenValue);
      await user1.sendTransaction({
        to: usdlStrategy.address,
        value: transferAmount,
      });

      await forward(1000);

      const usdlGainBefore = await usdlStrategy
        .connect(user1)
        .getPendingUSDLGain();

      const path = [WPLSAddress, USDLAddress];

      const result = await routerInstance.getAmountsOut(transferAmount, path);

      await usdlStrategy.connect(user1).withdraw(usdlTokenValue);

      const usdlGainAfter = await usdlStrategy
        .connect(user1)
        .getPendingUSDLGain();

      // swapping of pls increased the USDL balance which than staked to pool
      expect(usdlGainAfter).to.equal(
        usdlGainBefore.add(result[1]).sub(usdlTokenValue)
      );
    });

    it("If there no PLS gained , usdl will be withdrawn from stability pool", async function () {
      const usdlTokenValue = BigNumber.from("1000000");
      const initialBalance = await usdlInstance.balanceOf(user1.address);

      await usdlStrategy.connect(user1).deposit(usdlTokenValue);

      const usdlBalanceUserBefore = await usdlInstance.balanceOf(user1.address);

      await forward(1000);

      expect(await usdlStrategy.getPendingPLSGain()).to.equal(0);
      expect(await ethers.provider.getBalance(usdlStrategy.address)).to.equal(
        0
      );

      await usdlStrategy.connect(user1).withdraw(10000000);

      const usdlBalanceUserAfter = await usdlInstance.balanceOf(user1.address);

      expect(initialBalance).to.equal(
        usdlTokenValue.add(usdlBalanceUserBefore)
      );
      expect(usdlBalanceUserBefore.add(usdlTokenValue)).to.equal(
        BigInt(usdlBalanceUserAfter)
      );
    });
    it("Set frontend tag and deposit and gain LOAN rewards", async function () {
      await stabilityPoolInstance.registerFrontEnd("990000000000000000");
      await usdlStrategy.updateFrontEndTag(deployer.address);
      expect(await usdlStrategy.getFrontEndTagAddress()).to.equal(
        deployer.address
      );
      const usdlTokenValue = BigNumber.from("3000000000000000000");

      const user1USDLBalance = await usdlInstance.balanceOf(user1.address);

      await usdlStrategy.connect(user1).deposit(usdlTokenValue);
      const user1USDLBalanceAfterDeposit = await usdlInstance.balanceOf(
        user1.address
      );

      expect(await usdlStrategy.getPendingUSDLGain()).to.equal(usdlTokenValue);
      expect(user1USDLBalanceAfterDeposit).to.equal(
        user1USDLBalance.sub(usdlTokenValue)
      );

      expect(await usdlStrategy.getDepositorLoanGain()).to.equal(0);
      expect(await usdlStrategy.getFrontEndLOANGain()).to.equal(0);

      await forward(86400);

      await usdlInstance.connect(user1).transfer(user2.address, usdlTokenValue);

      await usdlInstance
        .connect(user2)
        .approve(llstabiltyPoolAddress, usdlTokenValue);

      await stabilityPoolInstance
        .connect(user2)
        .provideToSP(usdlTokenValue, ethers.constants.AddressZero);

      expect(await usdlStrategy.getDepositorLoanGain()).to.not.equal(0);
      expect(await usdlStrategy.getFrontEndLOANGain()).to.not.equal(0);
    });

    it("Gained loan will be distributed to frontend tag and remaining will be transferred to strategy", async function () {
      const usdlTokenValue = BigNumber.from("3000000000000000000");

      await usdlStrategy.connect(user1).deposit(usdlTokenValue);

      await forward(500);

      await usdlInstance.connect(user1).transfer(user2.address, usdlTokenValue);

      await usdlInstance
        .connect(user2)
        .approve(llstabiltyPoolAddress, usdlTokenValue);

      await stabilityPoolInstance
        .connect(user2)
        .provideToSP(usdlTokenValue, deployer.address);

      const strategyLoanBalance = await loanInstance.balanceOf(
        usdlStrategy.address
      );
      const ownerLoanBalance = await loanInstance.balanceOf(deployer.address);

      const pendingLoanForStrategy = await usdlStrategy.getDepositorLoanGain();

      const pendingLoanForFrontendStrategy =
        await usdlStrategy.getFrontEndLOANGain();

      await usdlStrategy.connect(user1).withdraw("100000000000000");

      const currentStrategyLoanBalance = await loanInstance.balanceOf(
        usdlStrategy.address
      );
      const currentOwnerLoanBalance = await loanInstance.balanceOf(
        deployer.address
      );

      expect(currentStrategyLoanBalance.sub(strategyLoanBalance)).to.equal(
        pendingLoanForStrategy
      );

      expect(
        currentOwnerLoanBalance.sub(pendingLoanForFrontendStrategy)
      ).to.equal(ownerLoanBalance);
    });

    it("Harvesting => claiming PLS swapping to usdl and staking", async function () {
      const usdlTokenValue = BigNumber.from("3000000000000000000");

      await usdlStrategy.connect(user1).deposit(usdlTokenValue);

      expect(await usdlStrategy.getPendingUSDLGain()).to.equal(usdlTokenValue);

      await forward(300);

      // Transferring some PLS as PLS can only be gained on liquidation

      const transferAmount: BigNumber = ethers.utils.parseEther("1");

      await user1.sendTransaction({
        to: usdlStrategy.address,
        value: transferAmount,
      });

      const path = [WPLSAddress, USDLAddress];

      const result = await routerInstance.getAmountsOut(transferAmount, path);

      await usdlStrategy.harvest();

      expect(await usdlStrategy.getPendingUSDLGain()).to.equal(
        usdlTokenValue.add(result[1])
      );
    });
  });

  describe("Recover token testcases", () => {
    it("Owner can not send LOAN Tokens.", async function () {
      await expect(
        usdlStrategy
          .connect(deployer)
          .inCaseTokensGetStuck(LOANAddress, 7000, user1.address)
      ).to.be.revertedWith("Can not send LOAN tokens");
    });

    it("Owner can not send USDL Tokens.", async function () {
      await expect(
        usdlStrategy.inCaseTokensGetStuck(USDLAddress, 7000, user1.address)
      ).to.be.revertedWith("Can not send USDL tokens");
    });

    it("Owner can not send WPLS Tokens.", async function () {
      await expect(
        usdlStrategy.inCaseTokensGetStuck(WPLSAddress, 7000, user1.address)
      ).to.be.revertedWith("Can not send WPLS tokens");
    });

    it("owner can recover other tokens", async function () {
      const transferAmount: BigNumber = BigNumber.from("1000000");
      await winToken.transfer(usdlStrategy.address, transferAmount);

      const previousBalance = await winToken.balanceOf(user1.address);

      await usdlStrategy.inCaseTokensGetStuck(
        winToken.address,
        transferAmount,
        user1.address
      );

      const currentBalance = await winToken.balanceOf(user1.address);

      expect(currentBalance.sub(previousBalance)).to.equal(transferAmount);
    });
  });
  describe("Automation Test", () => {
    it("Successfully 'Distributed rewards' while staking", async function () {
      await usdlStakingPool.modifyStrategyAddress(usdlStrategy.address);
      const usdlTokenValue = 1000000;

      await usdlStrategy.connect(user1).deposit(usdlTokenValue);

      const distributionAddress = [
        usdlPrizePool.address,
        usdlStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];
      await usdlStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      const stakingPoolBalance = await loanInstance.balanceOf(
        usdlStakingPool.address
      );

      const usdlPrizePoolInitialUSDLBalance = await loanInstance.balanceOf(
        usdlPrizePool.address
      );

      const winPrizePoolInitialUSDLBalance = await loanInstance.balanceOf(
        winPrizePool.address
      );

      const winStakingInitialUSDLBalance = await loanInstance.balanceOf(
        winStakingPool.address
      );

      const buyAndBurnInitialUSDLBalance = await loanInstance.balanceOf(
        buyAndBurn.address
      );

      await forward(268000);

      // accumlate the rewards without withdrawing USDL
      await usdlStrategy.connect(deployer).harvest();
      // loan rewards accumlated in contract after 1 day of deposit

      const rewardsAmount = await loanInstance.balanceOf(usdlStrategy.address);
      await usdlStakingPool.connect(user1).stake(usdlTokenValue, [], [], true);
      // await usdlStrategy.connect(deployer).claimAndDistributeRewards();

      const stakingPoolBalanceAfterRewards = await loanInstance.balanceOf(
        usdlStakingPool.address
      );

      const stakingPoolPercentage = await usdlStrategy.getUSDLStakingPercent();

      const totalPercent = await usdlStrategy.TOTAL_PERCENT();

      expect(
        stakingPoolBalanceAfterRewards.sub(stakingPoolBalance)
      ).to.be.equal(rewardsAmount.mul(stakingPoolPercentage).div(totalPercent));

      const usdlPrizePoolUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        usdlPrizePool.address
      );

      const usdlPrizePoolPercentage =
        await usdlStrategy.getUSDLPrizePoolPercent();

      expect(
        usdlPrizePoolUSDLBalanceAfterRewards.sub(
          usdlPrizePoolInitialUSDLBalance
        )
      ).to.be.equal(
        rewardsAmount.mul(usdlPrizePoolPercentage).div(totalPercent)
      );

      const winPrizePoolUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPercentage =
        await usdlStrategy.getWinPrizePoolPercent();

      expect(
        winPrizePoolUSDLBalanceAfterRewards.sub(winPrizePoolInitialUSDLBalance)
      ).to.be.equal(
        rewardsAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      const winStakingUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingPercentage = await usdlStrategy.getWinStakingPercent();

      expect(
        winStakingUSDLBalanceAfterRewards.sub(winStakingInitialUSDLBalance)
      ).to.be.equal(rewardsAmount.mul(winStakingPercentage).div(totalPercent));

      const buyAndBurnUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        buyAndBurn.address
      );

      const buyAndBurnPercentage = await usdlStrategy.getBuyAndBurnPercent();

      expect(
        buyAndBurnUSDLBalanceAfterRewards.sub(buyAndBurnInitialUSDLBalance)
      ).to.be.equal(rewardsAmount.mul(buyAndBurnPercentage).div(totalPercent));
    });
    it("Successfully 'Distributed rewards' while unstaking", async function () {
      await usdlStakingPool.modifyStrategyAddress(usdlStrategy.address);
      const usdlTokenValue = 1000000;

      await usdlStrategy.connect(user1).deposit(usdlTokenValue);

      const distributionAddress = [
        usdlPrizePool.address,
        usdlStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];
      await usdlStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      const stakingPoolBalance = await loanInstance.balanceOf(
        usdlStakingPool.address
      );

      const usdlPrizePoolInitialUSDLBalance = await loanInstance.balanceOf(
        usdlPrizePool.address
      );

      const winPrizePoolInitialUSDLBalance = await loanInstance.balanceOf(
        winPrizePool.address
      );

      const winStakingInitialUSDLBalance = await loanInstance.balanceOf(
        winStakingPool.address
      );

      const buyAndBurnInitialUSDLBalance = await loanInstance.balanceOf(
        buyAndBurn.address
      );

      await forward(268000);
      await usdlStrategy.connect(deployer).harvest();

      const rewardsAmount = await loanInstance.balanceOf(usdlStrategy.address);
      await usdlStakingPool.connect(user1).stake(usdlTokenValue, [], [], true);

      const stakingPoolBalanceAfterRewards = await loanInstance.balanceOf(
        usdlStakingPool.address
      );

      const stakingPoolPercentage = await usdlStrategy.getUSDLStakingPercent();

      const totalPercent = await usdlStrategy.TOTAL_PERCENT();

      expect(
        stakingPoolBalanceAfterRewards.sub(stakingPoolBalance)
      ).to.be.equal(rewardsAmount.mul(stakingPoolPercentage).div(totalPercent));

      const usdlPrizePoolUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        usdlPrizePool.address
      );

      const usdlPrizePoolPercentage =
        await usdlStrategy.getUSDLPrizePoolPercent();

      expect(
        usdlPrizePoolUSDLBalanceAfterRewards.sub(
          usdlPrizePoolInitialUSDLBalance
        )
      ).to.be.equal(
        rewardsAmount.mul(usdlPrizePoolPercentage).div(totalPercent)
      );

      const winPrizePoolUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPercentage =
        await usdlStrategy.getWinPrizePoolPercent();

      expect(
        winPrizePoolUSDLBalanceAfterRewards.sub(winPrizePoolInitialUSDLBalance)
      ).to.be.equal(
        rewardsAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      const winStakingUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingPercentage = await usdlStrategy.getWinStakingPercent();

      expect(
        winStakingUSDLBalanceAfterRewards.sub(winStakingInitialUSDLBalance)
      ).to.be.equal(rewardsAmount.mul(winStakingPercentage).div(totalPercent));

      const buyAndBurnUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        buyAndBurn.address
      );

      const buyAndBurnPercentage = await usdlStrategy.getBuyAndBurnPercent();

      expect(
        buyAndBurnUSDLBalanceAfterRewards.sub(buyAndBurnInitialUSDLBalance)
      ).to.be.equal(rewardsAmount.mul(buyAndBurnPercentage).div(totalPercent));
    });
    it("Successfully 'Distributed rewards' while calling claimAndDistributeRewards()", async function () {
      const usdlTokenValue = 1000000;

      await usdlStrategy.connect(user1).deposit(usdlTokenValue);

      const distributionAddress = [
        usdlPrizePool.address,
        usdlStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];
      await usdlStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      const PrizeCycleTimeBefore =
        await usdlStrategy.currentPrizeCycleStartTime();

      const stakingPoolBalance = await loanInstance.balanceOf(
        usdlStakingPool.address
      );

      const usdlPrizePoolInitialUSDLBalance = await loanInstance.balanceOf(
        usdlPrizePool.address
      );

      const winPrizePoolInitialUSDLBalance = await loanInstance.balanceOf(
        winPrizePool.address
      );

      const winStakingInitialUSDLBalance = await loanInstance.balanceOf(
        winStakingPool.address
      );

      const buyAndBurnInitialUSDLBalance = await loanInstance.balanceOf(
        buyAndBurn.address
      );

      await forward(86400);
      // accumlate the rewards without withdrawing USDL
      await usdlStrategy.connect(deployer).harvest();
      // loan rewards accumlated in contract after 1 day of deposit
      const rewardsAmount = await loanInstance.balanceOf(usdlStrategy.address);

      await usdlStrategy.connect(deployer).claimAndDistributeRewards();

      const PrizeCycleTimeAfter =
        await usdlStrategy.currentPrizeCycleStartTime();

      const stakingPoolBalanceAfterRewards = await loanInstance.balanceOf(
        usdlStakingPool.address
      );

      const stakingPoolPercentage = await usdlStrategy.getUSDLStakingPercent();

      const totalPercent = await usdlStrategy.TOTAL_PERCENT();

      expect(
        stakingPoolBalanceAfterRewards.sub(stakingPoolBalance)
      ).to.be.equal(rewardsAmount.mul(stakingPoolPercentage).div(totalPercent));

      expect(PrizeCycleTimeAfter.sub(PrizeCycleTimeBefore)).to.be.equal(86400);

      const usdlPrizePoolUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        usdlPrizePool.address
      );

      const usdlPrizePoolPercentage =
        await usdlStrategy.getUSDLPrizePoolPercent();

      expect(
        usdlPrizePoolUSDLBalanceAfterRewards.sub(
          usdlPrizePoolInitialUSDLBalance
        )
      ).to.be.equal(
        rewardsAmount.mul(usdlPrizePoolPercentage).div(totalPercent)
      );

      const winPrizePoolUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPercentage =
        await usdlStrategy.getWinPrizePoolPercent();

      expect(
        winPrizePoolUSDLBalanceAfterRewards.sub(winPrizePoolInitialUSDLBalance)
      ).to.be.equal(
        rewardsAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      const winStakingUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingPercentage = await usdlStrategy.getWinStakingPercent();

      expect(
        winStakingUSDLBalanceAfterRewards.sub(winStakingInitialUSDLBalance)
      ).to.be.equal(rewardsAmount.mul(winStakingPercentage).div(totalPercent));

      const buyAndBurnUSDLBalanceAfterRewards = await loanInstance.balanceOf(
        buyAndBurn.address
      );

      const buyAndBurnPercentage = await usdlStrategy.getBuyAndBurnPercent();

      expect(
        buyAndBurnUSDLBalanceAfterRewards.sub(buyAndBurnInitialUSDLBalance)
      ).to.be.equal(rewardsAmount.mul(buyAndBurnPercentage).div(totalPercent));
    });
  });
});
