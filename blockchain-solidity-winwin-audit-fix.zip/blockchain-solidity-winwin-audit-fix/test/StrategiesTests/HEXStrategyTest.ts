import { expect } from "chai";
import hre, { ethers, waffle } from "hardhat";
import { BigNumber, Contract, ContractFactory } from "ethers";
import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import axios from "axios";
import { setBalance } from "@nomicfoundation/hardhat-network-helpers";

async function forward(seconds: any) {
  const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;
  await waffle.provider.send("evm_setNextBlockTimestamp", [
    lastTimestamp + seconds,
  ]);
  await waffle.provider.send("evm_mine", []);
}

let deployer: SignerWithAddress;
let user1: SignerWithAddress;
let user2: SignerWithAddress;
let user3: SignerWithAddress;
let buyAndBurn: SignerWithAddress;
let abi: any;
let erc20Abi: any;
let hexAbi: any;
let WinWin: ContractFactory;
let winToken: Contract;
let WinStakingPool: ContractFactory;
let winStakingPool: Contract;
let HexStakingPool: ContractFactory;
let hexStakingPool: Contract;
let HexStrategy: ContractFactory;
let hexStrategy: Contract;
let PrizePool: ContractFactory;
let winPrizePool: Contract;
let hexPrizePool: Contract;
let rewardToken: Contract;
const HEXTokenAddress = "0x2b591e99afE9f32eAA6214f7B7629768c40Eeb39";
const routerAddress = "0x98bf93ebf5c380C0e6Ae8e192A7e2AE08edAcc02";
const WPLSAddress = "0xA1077a294dDE1B09bB078844df40758a5D0f9a27";
let routerInstance: any;
let hexTokenInstance: any;

async function setup() {
  if (!abi) {
    [deployer, user1, user2, user3, buyAndBurn] = await ethers.getSigners();

    // Set Ether balances
    const initialBalance = ethers.utils.parseEther("100000"); // Set initial balance to 1000 ETH

    await setBalance(deployer.address, initialBalance);
    await setBalance(user1.address, initialBalance);
    await setBalance(user2.address, initialBalance);
    await setBalance(user3.address, initialBalance);
    await setBalance(buyAndBurn.address, initialBalance);

    erc20Abi = await hre.artifacts.readArtifact(
      "@openzeppelin/contracts/token/ERC20/IERC20.sol:IERC20"
    );
    abi = await axios.get(
      `https://api.etherscan.io/api?module=contract&action=getabi&address=0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D&apikey=${process.env.ETHERSCAN_API_KEY}`
    );

    hexAbi = await axios.get(
      `https://api.etherscan.io/api?module=contract&action=getabi&address=${HEXTokenAddress}&apikey=${process.env.ETHERSCAN_API_KEY}`
    );

    const path = [WPLSAddress, HEXTokenAddress];

    routerInstance = new ethers.Contract(
      routerAddress,
      abi.data.result,
      deployer
    );
    const options = { value: ethers.utils.parseEther("5000.0") };

    await routerInstance
      .connect(user1)
      .swapExactETHForTokens(0, path, user1.address, "10000000000000", options);

    await routerInstance
      .connect(deployer)
      .swapExactETHForTokens(
        0,
        path,
        deployer.address,
        "10000000000000",
        options
      );

    await routerInstance
      .connect(user2)
      .swapExactETHForTokens(0, path, user2.address, "10000000000000", options);

    await routerInstance
      .connect(user3)
      .swapExactETHForTokens(0, path, user3.address, "10000000000000", options);
  }
  hexTokenInstance = new ethers.Contract(
    HEXTokenAddress,
    hexAbi.data.result,
    user1
  );

  WinWin = await ethers.getContractFactory("WinToken", deployer);
  const tokenSupply = 5000000000;
  winToken = await WinWin.deploy(tokenSupply);
  winToken.deployed();

  const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;

  rewardToken = await WinWin.connect(deployer).deploy(tokenSupply);
  rewardToken.deployed();

  WinStakingPool = await ethers.getContractFactory("WinStakingPool", deployer);

  const block = await hre.ethers.provider.getBlock("latest");

  winStakingPool = await WinStakingPool.deploy(
    winToken.address,
    block.timestamp,
    "10000000000"
  );
  winStakingPool.deployed();

  await winToken
    .connect(deployer)
    .transfer(winStakingPool.address, "10000000000");

  HexStakingPool = await ethers.getContractFactory("HexStakingPool", deployer);
  hexStakingPool = await HexStakingPool.deploy(HEXTokenAddress);
  hexStakingPool.deployed();

  PrizePool = await ethers.getContractFactory("PrizePool", deployer);

  const prizeDistribution = [6000, 900, 600, 300, 100, 2100];

  hexPrizePool = await PrizePool.deploy(
    lastTimestamp + 100,
    hexStakingPool.address,
    prizeDistribution
  );

  winPrizePool = await PrizePool.deploy(
    lastTimestamp + 100,
    winStakingPool.address,
    prizeDistribution
  );

  await hexStakingPool.setPrizePoolAddress(hexPrizePool.address);

  await winStakingPool.setPrizePoolAddress(winPrizePool.address);

  await winPrizePool.addRewardToken(hexTokenInstance.address);

  await hexPrizePool.addRewardToken(hexTokenInstance.address);

  HexStrategy = await ethers.getContractFactory("HEXStrategy", deployer);
  hexStrategy = await HexStrategy.deploy(
    HEXTokenAddress,
    [
      hexPrizePool.address,
      hexStakingPool.address,
      winPrizePool.address,
      winStakingPool.address,
      buyAndBurn.address,
    ],
    [6000, 3000, 600, 300, 100]
  );
  hexStrategy.deployed();

  await hexTokenInstance
    .connect(user1)
    .approve(hexPrizePool.address, "10000000000000000000");
  await hexTokenInstance
    .connect(user2)
    .approve(hexPrizePool.address, "100000000000000000");

  await hexTokenInstance
    .connect(user3)
    .approve(hexPrizePool.address, "100000000000000000");
  await hexTokenInstance
    .connect(user1)
    .approve(hexStrategy.address, "10000000000000000000");

  await hexTokenInstance
    .connect(user1)
    .approve(hexStakingPool.address, "10000000000000000000");

  await hexTokenInstance
    .connect(deployer)
    .approve(hexStakingPool.address, "100000000000000000");

  await hexTokenInstance
    .connect(user2)
    .approve(hexStakingPool.address, "100000000000000000");

  await hexTokenInstance
    .connect(user3)
    .approve(hexStakingPool.address, "100000000000000000");

  await hexStakingPool
    .connect(deployer)
    .modifyStrategyAddress(hexStrategy.address);

  await hexStakingPool.approveRewardDistributor(
    HEXTokenAddress,
    hexStrategy.address,
    true
  );

  await winStakingPool.addReward(HEXTokenAddress, hexStrategy.address);
}

describe("Hex Strategy test", () => {
  describe("Restricted functions test", () => {
    beforeEach(async () => {
      await setup();
    });

    it("Can not 'Deposit' as deployer has no access", async function () {
      await expect(
        hexStrategy.connect(deployer).deposit(1000)
      ).to.be.revertedWith("Not WinHEXStaking");
    });

    it("Can not 'Withdraw' as deployer has no access", async function () {
      await expect(
        hexStrategy.connect(deployer).withdraw(user1.address, 1000, 1000)
      ).to.be.revertedWith("Not WinHEXStaking");
    });

    it("Can not change addresses. Only deployer has the permission", async function () {
      await expect(
        hexStrategy
          .connect(user1)
          .changeDistributionAddresses([
            hexPrizePool.address,
            hexStakingPool.address,
            winPrizePool.address,
            winStakingPool.address,
            buyAndBurn.address,
          ])
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Successfully changed address.", async function () {
      await hexStrategy
        .connect(deployer)
        .changeDistributionAddresses([
          user1.address,
          winStakingPool.address,
          user1.address,
          user1.address,
          user1.address,
        ]);

      expect(await hexStrategy.getWinHEXStakingAddress()).to.equal(
        winStakingPool.address
      );

      expect(await hexStrategy.getWinStakingAddress()).to.equal(user1.address);

      expect(await hexStrategy.getWinPrizePoolAddress()).to.equal(
        user1.address
      );

      expect(await hexStrategy.getBuyAndBurnAddress()).to.equal(user1.address);

      expect(await hexStrategy.getWinPrizePoolAddress()).to.equal(
        user1.address
      );
      await hexStrategy
        .connect(deployer)
        .changeDistributionAddresses([
          hexPrizePool.address,
          user1.address,
          winPrizePool.address,
          winStakingPool.address,

          buyAndBurn.address,
        ]);
    });

    it("Can not change shares. Only deployer has the permission.", async function () {
      await expect(
        hexStrategy
          .connect(user1)
          .updateDistributionPercentages([7000, 2000, 700, 200, 100])
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Distribution shares sum should be equal to 100%", async function () {
      await expect(
        hexStrategy.updateDistributionPercentages([7000, 2000, 700, 200, 50])
      ).to.be.revertedWith("Sum of shares is not 10000.");
    });

    it("Successfully updated distribution percentages", async function () {
      await hexStrategy.updateDistributionPercentages([
        7000, 2000, 700, 200, 100,
      ]);
      expect(await hexStrategy.getHEXPrizePoolPercent()).to.equal(7000);
      expect(await hexStrategy.getHEXStakingPercent()).to.equal(2000);
      expect(await hexStrategy.getWinPrizePoolPercent()).to.equal(700);
      expect(await hexStrategy.getWinStakingPercent()).to.equal(200);
      expect(await hexStrategy.getBuyAndBurnPercent()).to.equal(100);

      await hexStrategy.updateDistributionPercentages([
        7100, 2000, 700, 200, 0,
      ]);

      expect(await hexStrategy.getHEXPrizePoolPercent()).to.equal(7100);
      expect(await hexStrategy.getHEXStakingPercent()).to.equal(2000);
      expect(await hexStrategy.getWinPrizePoolPercent()).to.equal(700);
      expect(await hexStrategy.getWinStakingPercent()).to.equal(200);
      expect(await hexStrategy.getBuyAndBurnPercent()).to.equal(0);

      // reverting the change
      await hexStrategy.updateDistributionPercentages([
        6000, 3000, 600, 300, 100,
      ]);
    });

    it("Can not send stuck tokens. Only deployer has the permission.", async function () {
      await expect(
        hexStrategy
          .connect(user1)
          .inCaseTokensGetStuck(HEXTokenAddress, 7000, user1.address)
      ).to.be.revertedWith("Ownable: caller is not the owner");
    });

    it("Owner can not send HEX Tokens.", async function () {
      await expect(
        hexStrategy.inCaseTokensGetStuck(HEXTokenAddress, 7000, user1.address)
      ).to.be.revertedWith("Can not send HEX tokens");
    });

    it("Recover tokens and transfer to deployer", async function () {
      const tokenSupply = 50000000;
      const transferAmount = 2000;
      rewardToken = await WinWin.connect(deployer).deploy(tokenSupply);
      rewardToken.deployed();

      await rewardToken
        .connect(deployer)
        .transfer(hexStrategy.address, transferAmount);

      const contractBalance: BigNumber = await rewardToken
        .connect(deployer)
        .balanceOf(hexStrategy.address);

      const deployerPreviousBalance: BigNumber = await rewardToken
        .connect(deployer)
        .balanceOf(deployer.address);

      await hexStrategy
        .connect(deployer)
        .inCaseTokensGetStuck(
          rewardToken.address,
          transferAmount,
          deployer.address
        );

      const deployerBalance: BigNumber = await rewardToken
        .connect(deployer)
        .balanceOf(deployer.address);

      expect(deployerPreviousBalance.add(contractBalance)).to.equal(
        deployerBalance
      );
    });

    it("can not set zero address as strategy address", async () => {
      await expect(
        hexStakingPool
          .connect(deployer)
          .modifyStrategyAddress("0x0000000000000000000000000000000000000000")
      ).to.be.revertedWith("Not valid address");
    });

    it("New strategy address can not be same as current strategy address", async () => {
      await expect(
        hexStakingPool
          .connect(deployer)
          .modifyStrategyAddress(hexStrategy.address)
      ).to.be.revertedWith("This is current strategy address.");
    });
  });

  describe("Deposit functionality test", () => {
    beforeEach(async () => {
      await setup();
    });

    it("can not deposit 0", async function () {
      await expect(
        hexStakingPool.connect(user1).stake(0, [], [], true)
      ).to.be.revertedWith("Cannot stake 0");
    });

    it("Successful 'Deposit'", async function () {
      const hexTokenValue = 3000000;
      const user1HEXBalance = await hexTokenInstance.balanceOf(user1.address);

      await hexStakingPool.connect(user1).stake(hexTokenValue, [], [], true);

      const user1HEXBalanceAfterDeposit = await hexTokenInstance.balanceOf(
        user1.address
      );

      const stakes = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakes).to.equal(1);

      // AS this is first day so deposit will be added to current cycle
      expect(await hexStrategy.currentCycle()).to.equal(hexTokenValue);
      // let us consider user1 address as HEX staking contract of WinWin.
      expect(user1HEXBalanceAfterDeposit).to.equal(
        BigInt(user1HEXBalance) - BigInt(hexTokenValue)
      );
    });
  });

  describe("stakeHEX() function test", () => {
    beforeEach(async () => {
      await setup();
    });

    it("First day stakeHEX() function test", async function () {
      const hexTokenDepositValue = 3000000;

      let currentHexStrategyBalance = await hexTokenInstance.stakeCount(
        hexStrategy.address
      );

      expect(currentHexStrategyBalance).to.equal(0);

      const block = await hre.ethers.provider.getBlock("latest");

      const deployedTime = await hexStrategy.deployedTime();

      await forward(
        Number(deployedTime.add(86400).sub(block.timestamp).sub(2))
      );

      await hexStakingPool
        .connect(user1)
        .stake(hexTokenDepositValue, [], [], true);

      const currentDay = await hexTokenInstance.currentDay();

      currentHexStrategyBalance = await hexTokenInstance.stakeCount(
        hexStrategy.address
      );

      expect(currentHexStrategyBalance).to.equal(1);

      const stakeDetails = await hexTokenInstance.stakeLists(
        hexStrategy.address,
        0
      );

      expect(stakeDetails.lockedDay).to.equal(currentDay.add(1));

      // AS it is first day so staked days will be 29
      expect(stakeDetails.stakedDays).to.equal(29);

      const currentCycle = await hexStrategy.currentCycle();
      expect(hexTokenDepositValue).to.equal(currentCycle);
    });

    it("Consecutive day stakeHEX() function test", async function () {
      const hexTokenDepositValue = 3000000;

      const deployedTime = await hexStrategy.deployedTime();

      let block = await hre.ethers.provider.getBlock("latest");

      // subtracting 2 seconds as stakeHex() function is called that will consume 1 second
      await forward(
        Number(deployedTime.add(86400).sub(block.timestamp).sub(2))
      );

      let currentHexStrategyBalance = await hexTokenInstance.stakeCount(
        hexStrategy.address
      );

      expect(currentHexStrategyBalance).to.equal(0);

      await hexStakingPool
        .connect(user1)
        .stake(hexTokenDepositValue, [], [], true);

      const currentDay = await hexTokenInstance.currentDay();

      currentHexStrategyBalance = await hexTokenInstance.stakeCount(
        hexStrategy.address
      );

      expect(currentHexStrategyBalance).to.equal(1);

      let stakeDetails = await hexTokenInstance.stakeLists(
        hexStrategy.address,
        0
      );

      expect(stakeDetails.lockedDay).to.equal(currentDay.add(1));

      // AS it is first day so staked days will be 29
      expect(stakeDetails.stakedDays).to.equal(29);

      let currentCycle = await hexStrategy.currentCycle();
      expect(hexTokenDepositValue).to.equal(currentCycle);

      await forward(30);

      // Now we are second day
      // Depositing more hex to stake it on hex token
      await hexStakingPool
        .connect(user1)
        .stake(hexTokenDepositValue, [], [], true);

      currentHexStrategyBalance = await hexTokenInstance.stakeCount(
        hexStrategy.address
      );

      expect(currentHexStrategyBalance).to.equal(2);

      stakeDetails = await hexTokenInstance.stakeLists(hexStrategy.address, 1);

      expect(stakeDetails.lockedDay).to.equal(currentDay.add(2));

      // AS it is second day so staked days will be 58
      // to make sure it can be be unstaked on next 30th day
      expect(stakeDetails.stakedDays).to.equal(58);

      // First stake will end on this 30th day so it should be included in current cycle
      currentCycle = await hexStrategy.currentCycle();
      expect(hexTokenDepositValue).to.equal(currentCycle);

      // Second stake will end on this 60th day so it should be included in next cycle
      const nextCycle = await hexStrategy.nextCycle();
      expect(hexTokenDepositValue).to.equal(nextCycle);

      await forward(86370);

      // Depositing more hex to stake it on hex token
      await hexStakingPool
        .connect(user1)
        .stake(hexTokenDepositValue, [], [], true);

      currentHexStrategyBalance = await hexTokenInstance.stakeCount(
        hexStrategy.address
      );

      expect(currentHexStrategyBalance).to.equal(3);

      stakeDetails = await hexTokenInstance.stakeLists(hexStrategy.address, 2);

      expect(stakeDetails.lockedDay).to.equal(currentDay.add(3));

      // AS it is second day so staked days will be 57
      // to make sure it can be be unstaked on next 30th day
      expect(stakeDetails.stakedDays).to.equal(57);

      // forwarding to 30th day
      block = await hre.ethers.provider.getBlock("latest");
      const thirtyDay = Number(
        deployedTime.add(86400 * 30).sub(block.timestamp)
      );
      await forward(thirtyDay);

      // Depositing more hex to stake it on hex token
      await hexStakingPool
        .connect(user1)
        .stake(hexTokenDepositValue, [], [], true);

      stakeDetails = await hexTokenInstance.stakeLists(hexStrategy.address, 2);

      expect(stakeDetails.lockedDay).to.equal(currentDay.add(31));

      expect(stakeDetails.stakedDays).to.equal(29);

      await forward(86400);

      // Depositing more hex to stake it on hex token
      await hexStakingPool
        .connect(user1)
        .stake(hexTokenDepositValue, [], [], true);

      stakeDetails = await hexTokenInstance.stakeLists(hexStrategy.address, 3);

      expect(stakeDetails.lockedDay).to.equal(currentDay.add(32));

      expect(stakeDetails.stakedDays).to.equal(58);
    });
  });

  describe("claimAndDistributeRewards() function test", async function () {
    beforeEach(async () => {
      await setup();
    });
    it("should unstake, claim rewards and distribute rewards after 30 days", async function () {
      const hexTokenDepositValue = 3000000;

      await hexStakingPool
        .connect(user1)
        .stake(hexTokenDepositValue, [], [], true);

      await forward(86400 * 30);

      let hexPoolRewardDetails = await hexStakingPool.getRewardData(
        HEXTokenAddress
      );

      let winRewardDetails = await winStakingPool.getRewardData(
        HEXTokenAddress
      );

      expect(hexPoolRewardDetails.rewardRate).to.equal(0);
      expect(winRewardDetails.rewardRate).to.equal(0);

      const hexPrizePoolHexBalance = await hexTokenInstance.balanceOf(
        hexPrizePool.address
      );

      const winPrizePoolHexBalance = await hexTokenInstance.balanceOf(
        winPrizePool.address
      );

      const buyAndBurnHexBalance = await hexTokenInstance.balanceOf(
        buyAndBurn.address
      );

      await hexStrategy.connect(deployer).claimAndDistributeRewards();

      hexPoolRewardDetails = await hexStakingPool.getRewardData(
        HEXTokenAddress
      );

      winRewardDetails = await winStakingPool.getRewardData(HEXTokenAddress);

      expect(hexPoolRewardDetails.rewardRate).to.not.equal(0);
      expect(winRewardDetails.rewardRate).to.not.equal(0);

      const hexPrizePoolHexBalanceAfter = await hexTokenInstance.balanceOf(
        hexPrizePool.address
      );

      const winPrizePoolHexBalanceAfter = await hexTokenInstance.balanceOf(
        winPrizePool.address
      );

      const buyAndBurnHexBalanceAfter = await hexTokenInstance.balanceOf(
        buyAndBurn.address
      );

      expect(
        winPrizePoolHexBalanceAfter.sub(winPrizePoolHexBalance)
      ).to.not.equal(0);

      expect(
        hexPrizePoolHexBalanceAfter.sub(hexPrizePoolHexBalance)
      ).to.not.equal(0);

      expect(buyAndBurnHexBalanceAfter.sub(buyAndBurnHexBalance)).to.not.equal(
        0
      );
    });

    it("Should unstake multiple stakes and claim rewards and distribute rewards after 30 days and 60 days", async function () {
      const hexTokenDepositValue = 3000000;

      const deployedTime = await hexStrategy.deployedTime();

      // all the deposit made today will be staked for 28 days as this is first day of HEX strategy contract.
      // Forwarding to (next starting day timestamp - 1 seconds)
      let block = await hre.ethers.provider.getBlock("latest");

      // subtract 2 seconds as stakeHex() function is called that will consume 1 second
      await forward(
        Number(deployedTime.add(86400).sub(block.timestamp).sub(2))
      );

      await hexStakingPool
        .connect(user1)
        .stake(hexTokenDepositValue, [], [], true);

      const currentDay = await hexTokenInstance.currentDay();

      let currentHexStrategyBalance = await hexTokenInstance.stakeCount(
        hexStrategy.address
      );

      expect(currentHexStrategyBalance).to.equal(1);

      let stakeDetails = await hexTokenInstance.stakeLists(
        hexStrategy.address,
        0
      );

      expect(stakeDetails.lockedDay).to.equal(currentDay.add(1));

      // AS it is first day so staked days will be 29
      expect(stakeDetails.stakedDays).to.equal(29);

      // First stake will end on this 30th day so it should be included in current cycle
      let currentCycle = await hexStrategy.currentCycle();
      expect(hexTokenDepositValue).to.equal(currentCycle);

      // Second stake will end on this 60th day so it should be included in next cycle
      let nextCycle = await hexStrategy.nextCycle();
      expect(0).to.equal(nextCycle);

      await forward(30);

      // Now we are second day
      // Depositing more hex to stake it on hex token
      await hexStakingPool
        .connect(user1)
        .stake(hexTokenDepositValue, [], [], true);

      currentHexStrategyBalance = await hexTokenInstance.stakeCount(
        hexStrategy.address
      );

      expect(currentHexStrategyBalance).to.equal(2);

      stakeDetails = await hexTokenInstance.stakeLists(hexStrategy.address, 1);

      expect(stakeDetails.lockedDay).to.equal(currentDay.add(2));

      // AS it is second day so staked days will be 58
      // to make sure it can be be unstaked on next 30th day
      expect(stakeDetails.stakedDays).to.equal(58);

      // first stake will end on this 30th day so it should be included in current cycle
      currentCycle = await hexStrategy.currentCycle();
      expect(hexTokenDepositValue).to.equal(currentCycle);

      // Second stake will end on this 60th day so it should be included in next cycle
      nextCycle = await hexStrategy.nextCycle();
      expect(hexTokenDepositValue).to.equal(nextCycle);

      await forward(86370);

      // Depositing more hex to stake it on hex token
      await hexStakingPool
        .connect(user1)
        .stake(hexTokenDepositValue, [], [], true);

      currentHexStrategyBalance = await hexTokenInstance.stakeCount(
        hexStrategy.address
      );

      expect(currentHexStrategyBalance).to.equal(3);

      stakeDetails = await hexTokenInstance.stakeLists(hexStrategy.address, 2);

      expect(stakeDetails.lockedDay).to.equal(currentDay.add(3));

      // AS it is second day so staked days will be 57
      // to make sure it can be be unstaked on next 30th day
      expect(stakeDetails.stakedDays).to.equal(57);

      // first stake will end on this 30th day so it should be included in current cycle
      currentCycle = await hexStrategy.currentCycle();
      expect(hexTokenDepositValue).to.equal(currentCycle);

      // Second and thirs stake will end on this 60th day so it should be included in next cycle
      nextCycle = await hexStrategy.nextCycle();
      expect(hexTokenDepositValue * 2).to.equal(nextCycle);

      // forwarding to 30th day
      block = await hre.ethers.provider.getBlock("latest");

      const thirtyDay = Number(
        deployedTime.add(86400 * 30).sub(block.timestamp)
      );

      await forward(thirtyDay);

      // Unstake all stakes which have completed thier stake duration

      let hexPoolRewardDetails = await hexStakingPool.getRewardData(
        HEXTokenAddress
      );

      let winRewardDetails = await winStakingPool.getRewardData(
        HEXTokenAddress
      );

      expect(hexPoolRewardDetails.rewardRate).to.equal(0);
      expect(winRewardDetails.rewardRate).to.equal(0);

      let hexPrizePoolHexBalance = await hexTokenInstance.balanceOf(
        hexPrizePool.address
      );

      let winPrizePoolHexBalance = await hexTokenInstance.balanceOf(
        winPrizePool.address
      );

      let buyAndBurnHexBalance = await hexTokenInstance.balanceOf(
        buyAndBurn.address
      );

      await hexStrategy.connect(deployer).claimAndDistributeRewards();

      hexPoolRewardDetails = await hexStakingPool.getRewardData(
        HEXTokenAddress
      );

      winRewardDetails = await winStakingPool.getRewardData(HEXTokenAddress);

      expect(hexPoolRewardDetails.rewardRate).to.not.equal(0);

      expect(winRewardDetails.rewardRate).to.not.equal(0);

      let hexPrizePoolHexBalanceAfter = await hexTokenInstance.balanceOf(
        hexPrizePool.address
      );

      let winPrizePoolHexBalanceAfter = await hexTokenInstance.balanceOf(
        winPrizePool.address
      );

      let buyAndBurnHexBalanceAfter = await hexTokenInstance.balanceOf(
        buyAndBurn.address
      );

      expect(
        winPrizePoolHexBalanceAfter.sub(winPrizePoolHexBalance)
      ).to.not.equal(0);

      expect(
        hexPrizePoolHexBalanceAfter.sub(hexPrizePoolHexBalance)
      ).to.not.equal(0);

      expect(buyAndBurnHexBalanceAfter.sub(buyAndBurnHexBalance)).to.not.equal(
        0
      );

      // Depositing more hex to stake it on hex token

      await forward(86400);

      await hexStakingPool
        .connect(user1)
        .stake(hexTokenDepositValue, [], [], true);

      stakeDetails = await hexTokenInstance.stakeLists(hexStrategy.address, 3);

      expect(stakeDetails.lockedDay).to.equal(currentDay.add(32));

      expect(stakeDetails.stakedDays).to.equal(58);

      await forward(86400);

      // Depositing more hex to stake it on hex token
      await hexStakingPool
        .connect(user1)
        .stake(hexTokenDepositValue, [], [], true);

      stakeDetails = await hexTokenInstance.stakeLists(hexStrategy.address, 4);

      expect(stakeDetails.lockedDay).to.equal(currentDay.add(33));
      expect(stakeDetails.stakedDays).to.equal(57);

      // forwarding to 60th day

      block = await hre.ethers.provider.getBlock("latest");

      const sixtyDay = Number(
        deployedTime.add(86400 * 60).sub(block.timestamp)
      );

      await forward(sixtyDay);

      hexPrizePoolHexBalance = await hexTokenInstance.balanceOf(
        hexPrizePool.address
      );

      winPrizePoolHexBalance = await hexTokenInstance.balanceOf(
        winPrizePool.address
      );

      buyAndBurnHexBalance = await hexTokenInstance.balanceOf(
        buyAndBurn.address
      );

      await hexStrategy.connect(deployer).claimAndDistributeRewards();

      const newHexPoolRewardDetails = await hexStakingPool.getRewardData(
        HEXTokenAddress
      );

      const newWinRewardDetails = await winStakingPool.getRewardData(
        HEXTokenAddress
      );

      expect(newHexPoolRewardDetails.rewardRate).to.not.equal(
        hexPoolRewardDetails.rewardRate
      );

      expect(newWinRewardDetails.rewardRate).to.not.equal(
        winRewardDetails.rewardRate
      );

      hexPrizePoolHexBalanceAfter = await hexTokenInstance.balanceOf(
        hexPrizePool.address
      );

      winPrizePoolHexBalanceAfter = await hexTokenInstance.balanceOf(
        winPrizePool.address
      );

      buyAndBurnHexBalanceAfter = await hexTokenInstance.balanceOf(
        buyAndBurn.address
      );

      expect(
        winPrizePoolHexBalanceAfter.sub(winPrizePoolHexBalance)
      ).to.not.equal(0);

      expect(
        hexPrizePoolHexBalanceAfter.sub(hexPrizePoolHexBalance)
      ).to.not.equal(0);

      expect(buyAndBurnHexBalanceAfter.sub(buyAndBurnHexBalance)).to.not.equal(
        0
      );
    }).timeout(50000);
  });

  describe("Withdraw queue", async function () {
    beforeEach(async () => {
      await setup();
    });

    it("Fulfilling withdraw queue during deposit", async function () {
      const stakeAmount = BigNumber.from("1000000");

      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const totalUser1Shares = await hexStakingPool.userShares(user1.address);

      const prevBalance = await hexTokenInstance.balanceOf(user1.address);
      await hexStakingPool.connect(user1).unstake(totalUser1Shares);
      let currentBalance = await hexTokenInstance.balanceOf(user1.address);

      // No change in balance as withdraw request is put in queue
      expect(currentBalance).to.equal(prevBalance);

      // Withdraw request will be put

      const length = await hexStrategy.getWithdrawQueueLength();

      expect(length).to.equal(1);

      await hexStakingPool
        .connect(user2)
        .stake(stakeAmount.mul(2), [], [], true);

      currentBalance = await hexTokenInstance.balanceOf(user1.address);

      expect(currentBalance.sub(prevBalance)).to.equal(stakeAmount);

      const currentTotalStaked = await hexStrategy.getCurrentTotalStake();

      expect(currentTotalStaked).to.equal(stakeAmount.mul(2).sub(stakeAmount));
    });

    it("Withdrawal when current staked is higher than withdrawl request but there are already some big withdraw request", async function () {
      let stakeAmount = BigNumber.from("1000000");

      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      const currentCycle = await hexStrategy.currentCycle();

      expect(currentCycle).to.equal(stakeAmount);

      let currentTotalStaked = await hexStrategy.getCurrentTotalStake();

      expect(currentTotalStaked).to.equal(0);

      const user1Balance = await hexTokenInstance.balanceOf(user1.address);
      // Putting a withdraw request
      await hexStakingPool.connect(user1).unstake("100000");

      let length = await hexStrategy.getWithdrawQueueLength();

      expect(length).to.equal(1);

      // Staking less token then requested withdraw
      stakeAmount = BigNumber.from("10000");

      await hexStakingPool.connect(user2).stake(stakeAmount, [], [], true);

      const user1BalanceAfterUser2Stake = await hexTokenInstance.balanceOf(
        user1.address
      );

      expect(user1Balance).to.equal(user1BalanceAfterUser2Stake);

      // withdraw request will still not be fulfilled

      currentTotalStaked = await hexStrategy.getCurrentTotalStake();

      expect(currentTotalStaked).to.equal(stakeAmount);

      const user2Balance = await hexTokenInstance.balanceOf(user2.address);
      await hexStakingPool.connect(user2).unstake("1000");

      // still withdrawal request of user 2 will be pending as there is already user 1 request pending

      length = await hexStrategy.getWithdrawQueueLength();

      expect(length).to.equal(2);

      let user2BalanceAfter = await hexTokenInstance.balanceOf(user2.address);

      expect(user2Balance).to.equal(user2BalanceAfter);

      // A deposit can fulfill all the withdraw request

      let totalUnstakeAmount = await hexStrategy.getWithdrawQueueAmount();

      expect(totalUnstakeAmount).to.equal("101000");

      stakeAmount = BigNumber.from("1000000");
      await hexStakingPool.connect(deployer).stake(stakeAmount, [], [], true);

      user2BalanceAfter = await hexTokenInstance.balanceOf(user2.address);

      expect(user2BalanceAfter.sub(user2Balance)).to.equal("1000");

      const user1BalanceAfter = await hexTokenInstance.balanceOf(user1.address);

      expect(user1BalanceAfter.sub(user1Balance)).to.equal("100000");

      totalUnstakeAmount = await hexStrategy.getWithdrawQueueAmount();

      expect(totalUnstakeAmount).to.equal("0");

      currentTotalStaked = await hexStrategy.getCurrentTotalStake();

      expect(currentTotalStaked).to.equal(
        stakeAmount.sub("101000").add("10000")
      );
    });

    it("Fulfill withdrawl request on claimAndDistribute()", async function () {
      const stakeAmount = BigNumber.from("1000000");

      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      // This stake will get staked in hex as this is first stake in the day
      const currentCycle = await hexStrategy.currentCycle();

      expect(currentCycle).to.equal(stakeAmount);

      // Staking less token then requested withdraw
      const stakeAmount2 = BigNumber.from("10000");

      await hexStakingPool.connect(user2).stake(stakeAmount2, [], [], true);

      const currentTotalStaked = await hexStrategy.getCurrentTotalStake();

      expect(currentTotalStaked).to.equal(stakeAmount2);

      const totalUser1Shares = await hexStakingPool.userShares(user1.address);
      const totalUser2Shares = await hexStakingPool.userShares(user2.address);

      await hexStakingPool.connect(user1).unstake(totalUser1Shares);
      await hexStakingPool.connect(user2).unstake(totalUser2Shares);

      // forward 30 days

      await forward(30 * 24 * 60 * 60);

      let withdrawQueueLength = await hexStrategy.getWithdrawQueueLength();

      let unstakeQueue = await hexStrategy.getWithdrawQueueAmount();

      let totalStakedAmount = await hexStrategy.getCurrentTotalStake();

      expect(withdrawQueueLength).to.equal(2);
      expect(unstakeQueue).to.equal(1010000);
      expect(totalStakedAmount).to.equal(stakeAmount2);

      await hexStrategy.connect(deployer).claimAndDistributeRewards();

      withdrawQueueLength = await hexStrategy.getWithdrawQueueLength();

      unstakeQueue = await hexStrategy.getWithdrawQueueAmount();

      totalStakedAmount = await hexStrategy.getCurrentTotalStake();

      expect(withdrawQueueLength).to.equal(0);
      expect(unstakeQueue).to.equal(0);

      expect(totalStakedAmount).to.equal(0);
    });
  });

  describe("Automation test", () => {
    beforeEach(async () => {
      await setup();
    });

    it("if no deposits for the day , then amount will remain there in the strategy", async function () {
      const stakeAmount = BigNumber.from("1000000");

      // this is first stake in the day so it will staked in the hex
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakeCount).to.equal(1);

      // another deposit in the same day

      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let currentStaked = await hexStrategy.getCurrentTotalStake();

      expect(currentStaked).to.equal(stakeAmount);

      // forwarding 2 days
      await forward(2 * 86400);

      // no user transaction are made so it will still be there in the strategy

      currentStaked = await hexStrategy.getCurrentTotalStake();

      expect(currentStaked).to.equal(stakeAmount);

      // whenever someone deposits it will stake

      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakeCount).to.equal(2);
    });

    it("if withdraw is made and total staked is greater than requested and stake for that day is not happend", async function () {
      const stakeAmount = BigNumber.from("1000000");

      // this is first stake in the day so it will staked in the hex
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakeCount).to.equal(1);

      // another deposit in the same day

      await hexStakingPool.connect(user2).stake(stakeAmount, [], [], true);

      let currentStaked = await hexStrategy.getCurrentTotalStake();

      expect(currentStaked).to.equal(stakeAmount);

      // forwarding 2 days
      await forward(2 * 86400);

      // no user transaction are made so it will still be there in the strategy

      currentStaked = await hexStrategy.getCurrentTotalStake();

      expect(currentStaked).to.equal(stakeAmount);

      // whenever someone withdraws it will stake remaining after fulfilling withdrawal

      const stakeAmount2 = BigNumber.from("100000");

      const user2Balance = await hexTokenInstance.balanceOf(user2.address);

      await hexStakingPool.connect(user2).unstake(stakeAmount2);

      const user2BalanceAfter = await hexTokenInstance.balanceOf(user2.address);

      stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakeCount).to.equal(2);

      const stake2Details = await hexTokenInstance.stakeLists(
        hexStrategy.address,
        1
      );

      expect(stake2Details.stakedHearts).to.equal(
        stakeAmount.sub(stakeAmount2)
      );

      expect(user2BalanceAfter.sub(user2Balance)).to.equal(stakeAmount2);
    });

    it("If after 30 days (claimAndDistribute), No user transaction happens", async function () {
      const stakeAmount = BigNumber.from("1000000");

      // this is first stake in the day so it will staked in the hex
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakeCount).to.equal(1);

      await forward(86400);

      const stakeAmount2 = BigNumber.from("1900000");

      // this is first stake in the day so it will staked in the hex
      await hexStakingPool.connect(user1).stake(stakeAmount2, [], [], true);

      stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakeCount).to.equal(2);

      let currentCycle = await hexStrategy.currentCycle();

      let nextCycle = await hexStrategy.nextCycle();

      expect(currentCycle).to.equal(stakeAmount);

      expect(nextCycle).to.equal(stakeAmount2);

      const currentCycleStartTime =
        await hexStrategy.currentPrizeCycleStartTime();

      // forwarding to 36th day
      await forward(35 * 86400);

      await hexStakingPool.connect(user2).stake(stakeAmount, [], [], true);

      const newCurrentCycleStartTime =
        await hexStrategy.currentPrizeCycleStartTime();

      expect(currentCycleStartTime.add(30 * 86400)).to.equal(
        newCurrentCycleStartTime
      );

      stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakeCount).to.equal(2);
      currentCycle = await hexStrategy.currentCycle();

      nextCycle = await hexStrategy.nextCycle();

      expect(currentCycle).to.equal(stakeAmount2);
    });

    it("if big withdraw request and current cycle stakes are not enough to fulfill that then all the unstake amount will remain in the contract and no stake will happen until it's satisfied", async function () {
      let stakeAmount = BigNumber.from("100000000");

      // this is first stake in the day so it will staked in the hex
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakeCount).to.equal(1);

      stakeAmount = BigNumber.from("1000000");

      // another deposit in the same day

      await hexStakingPool.connect(user2).stake(stakeAmount, [], [], true);

      let currentStaked = await hexStrategy.getCurrentTotalStake();

      expect(currentStaked).to.equal(stakeAmount);

      await forward(86400);

      // no user transaction are made so it will still be there in the strategy

      currentStaked = await hexStrategy.getCurrentTotalStake();

      expect(currentStaked).to.equal(stakeAmount);

      // whenever someone deposits it will stake

      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakeCount).to.equal(2);

      let nextCycle = await hexStrategy.nextCycle();
      let currentCycle = await hexStrategy.currentCycle();
      expect(nextCycle).to.equal("2000000");
      expect(currentCycle).to.equal(100000000);

      //User 1 is un staking it's whole shares
      await hexStakingPool.connect(user1).unstake("101000000");

      await forward(86400);

      stakeAmount = BigNumber.from("100000");

      await hexStakingPool.connect(user3).stake(stakeAmount, [], [], true);

      //Stake amount will remaining unchanged
      stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakeCount).to.equal(2);

      let currentStake = await hexStrategy.getCurrentTotalStake();
      expect(currentStake).to.equal(stakeAmount);

      let withdrawQueueAmount = await hexStrategy.getWithdrawQueueAmount();
      expect(withdrawQueueAmount).to.equal(101000000); //There were no rewards distributed yet so there will not rewards during unstake so only principle amount will be there

      //No change in cycle amount as this stake has not been staked in hex token contract
      nextCycle = await hexStrategy.nextCycle();
      currentCycle = await hexStrategy.currentCycle();
      expect(nextCycle).to.equal(2000000);
      expect(currentCycle).to.equal(100000000);

      await forward(28 * 86400);

      await hexStakingPool.connect(user3).stake(stakeAmount, [], [], true);

      //As it is 30th day now so the stakes will be un staked
      //There is only stake that will be un staked
      //Amount is around 100000000

      stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      //Stake count decreased but no new stake has been created
      expect(stakeCount).to.equal(1);

      let currentTotalStake = await hexStrategy.getCurrentTotalStake();

      // let totalCurrently = 100000000 + 100000 + 100000 + 171224; //171224 is yield received that is going to be re staked
      // expect(currentTotalStake).to.equal(totalCurrently);

      withdrawQueueAmount = await hexStrategy.getWithdrawQueueAmount();
      expect(withdrawQueueAmount).to.equal(101000000); //There were no rewards distributed yet so there will not rewards during unstake so only principle amount will be there

      //As currentTotalStale is less that's why it is not staked and held in strategy itself and wait for next stakes to cover this

      await forward(30 * 86400);

      //After 30 days all the remaining stakes will be un staked and withdraw request will be fulfilled and remaining amount will be staked again

      let user1BalanceBeforeWithdrawRequestCompletion =
        await hexTokenInstance.balanceOf(user1.address);
      await hexStrategy.claimAndDistributeRewards();
      let user1BalanceAfterWithdrawRequestCompletion =
        await hexTokenInstance.balanceOf(user1.address);

      expect(
        user1BalanceAfterWithdrawRequestCompletion.sub(
          user1BalanceBeforeWithdrawRequestCompletion
        )
      ).to.equal(withdrawQueueAmount);

      stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      //Stake count is still 1 as old stake is unstaked and new stake is created after fulfilling withdraw request
      expect(stakeCount).to.equal(1);

      currentTotalStake = await hexStrategy.getCurrentTotalStake();

      expect(currentTotalStake).to.equal(0); //As all amount is staked after fulfilling withdraw request

      withdrawQueueAmount = await hexStrategy.getWithdrawQueueAmount();
      expect(withdrawQueueAmount).to.equal(0); //No pending request

      nextCycle = await hexStrategy.nextCycle();
      currentCycle = await hexStrategy.currentCycle();
      expect(nextCycle).to.equal(0);
      expect(currentCycle).to.not.equal(0);

      //can't compare with a number because yield keep changing at different times

      //1000000+ 100000+100000+171224 + 6945
    });

    it("Maintaining current cycle and next cycle.If current cycle stakes are unstaked when next cycle is being completed then to calculate rewards use(currentCycle+nextCycle)", async function () {
      let stakeAmount = BigNumber.from("100000000");

      // this is first stake in the day so it will staked in the hex
      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      let stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakeCount).to.equal(1);

      stakeAmount = BigNumber.from("1000000");

      // another deposit in the same day

      await hexStakingPool.connect(user2).stake(stakeAmount, [], [], true);

      let currentStaked = await hexStrategy.getCurrentTotalStake();

      expect(currentStaked).to.equal(stakeAmount);

      await forward(86400);

      // no user transaction are made so it will still be there in the strategy

      currentStaked = await hexStrategy.getCurrentTotalStake();

      expect(currentStaked).to.equal(stakeAmount);

      // whenever someone deposits it will stake

      await hexStakingPool.connect(user1).stake(stakeAmount, [], [], true);

      stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakeCount).to.equal(2);

      let nextCycle = await hexStrategy.nextCycle();
      let currentCycle = await hexStrategy.currentCycle();
      expect(nextCycle).to.equal("2000000");
      expect(currentCycle).to.equal(100000000);

      await forward(86400);

      stakeAmount = BigNumber.from("100000");

      await hexStakingPool.connect(user3).stake(stakeAmount, [], [], true);

      //Stake amount will remaining unchanged
      stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakeCount).to.equal(3);

      let currentStake = await hexStrategy.getCurrentTotalStake();
      expect(currentStake).to.equal(0);

      //No change in cycle amount as this stake has not been staked in hex token contract
      nextCycle = await hexStrategy.nextCycle();
      currentCycle = await hexStrategy.currentCycle();
      expect(nextCycle).to.equal(2100000); // 1000000+1000000+100000
      expect(currentCycle).to.equal(100000000);

      await forward(58 * 86400);

      //Still there are three stakes .all are matured some were mature 30 days before and some matured today I will check those things here

      let currentDay = await hexTokenInstance.currentDay();

      let firstStake = await hexTokenInstance.stakeLists(
        hexStrategy.address,
        0
      );

      expect(firstStake.lockedDay + firstStake.stakedDays).to.equal(
        currentDay.sub(30)
      );

      let secondStake = await hexTokenInstance.stakeLists(
        hexStrategy.address,
        1
      );

      expect(secondStake.lockedDay + secondStake.stakedDays).to.equal(
        currentDay
      );

      let thirdStake = await hexTokenInstance.stakeLists(
        hexStrategy.address,
        2
      );

      expect(thirdStake.lockedDay + thirdStake.stakedDays).to.equal(currentDay);

      //After 58 days all the stakes (previous cycle and this cycle will be unstaked)

      await hexStrategy.claimAndDistributeRewards();

      //After calculating we are getting 41800 hex token as rewards

      //30% of it will restaked as a auto compounding 41800*0.3=> 12540

      //Now all will be combined and it will have 1 stake

      stakeCount = await hexTokenInstance.stakeCount(hexStrategy.address);

      expect(stakeCount).to.equal(1);

      let newStake = await hexTokenInstance.stakeLists(hexStrategy.address, 0);

      expect(newStake.lockedDay + newStake.stakedDays).to.equal(
        currentDay.add(30)
      );
      expect(newStake.lockedDay).to.equal(currentDay.add(1));

      expect(newStake.stakedHearts).to.not.equal("0"); // 100389607 this will keep changing according to number of tokens in the hex

      // 100000000+1000000+1000000+100000 => 102100000

      //It is less than the original staked amount because penalty occurs after 14 days when your stake is matured but not unstaked

      nextCycle = await hexStrategy.nextCycle();
      currentCycle = await hexStrategy.currentCycle();
      expect(nextCycle).to.equal(0);
      expect(currentCycle).to.equal(newStake.stakedHearts);
    });
  });
});
