import { expect } from "chai";
import hre, { ethers, waffle } from "hardhat";
import { BigNumber, Contract, ContractFactory } from "ethers";
import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import axios from "axios";
import { setBalance } from "@nomicfoundation/hardhat-network-helpers";
async function forward(seconds: any) {
  const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;
  await waffle.provider.send("evm_setNextBlockTimestamp", [
    lastTimestamp + seconds,
  ]);
  await waffle.provider.send("evm_mine", []);
}

describe("Mint Pool test", () => {
  let deployer: SignerWithAddress;
  let user1: SignerWithAddress;
  let buyAndBurn: SignerWithAddress;
  let abi: any;
  let erc20Abi: any;
  let WinWin: ContractFactory;
  let winToken: Contract;
  let WinStakingPool: ContractFactory;
  let winStakingPool: Contract;
  let StakingPool: ContractFactory;
  let mintStakingPool: Contract;
  let MintStrategy: ContractFactory;
  let mintStrategy: Contract;
  let PrizePool: ContractFactory;
  let winPrizePool: Contract;
  let mintPrizePool: Contract;
  let rewardToken: Contract;
  let tokenSupply: BigNumber;

  const routerAddress = "0x98bf93ebf5c380C0e6Ae8e192A7e2AE08edAcc02";
  const MINTAddress = "0x207e6b4529840A4fd518f73c68bc9c19B2A15944";
  const mintStakingAddress = "0xbbc56bfdefb90e2f3e67e00e75bef0cd1ed2231e";
  const WPLSAddress = "0xA1077a294dDE1B09bB078844df40758a5D0f9a27";

  let routerInstance: any;
  let mintInstance: any;
  let WPLSInstance: any;

  beforeEach(async () => {
    [deployer, user1, buyAndBurn] = await hre.ethers.getSigners();
    // Set Ether balances
    const initialBalance = ethers.utils.parseEther("10000000000"); // Set initial balance to 1000 ETH

    await setBalance(deployer.address, initialBalance);
    await setBalance(user1.address, initialBalance);
    await setBalance(buyAndBurn.address, initialBalance);
    if (!abi) {
      erc20Abi = await hre.artifacts.readArtifact(
        "@openzeppelin/contracts/token/ERC20/IERC20.sol:IERC20"
      );
      abi = await axios.get(
        `https://api.etherscan.io/api?module=contract&action=getabi&address=0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D&apikey=${process.env.ETHERSCAN_API_KEY}`
      );

      const path = [WPLSAddress, MINTAddress];

      routerInstance = new ethers.Contract(
        routerAddress,
        abi.data.result,
        deployer
      );
      const options = { value: ethers.utils.parseEther("10000000.0") };
      await routerInstance.swapExactETHForTokens(
        0,
        path,
        user1.address,
        "10000000000000",
        options
      );
      mintInstance = new ethers.Contract(MINTAddress, erc20Abi.abi, user1);
      WPLSInstance = new ethers.Contract(WPLSAddress, erc20Abi.abi, user1);
    }

    tokenSupply = BigNumber.from("100000000000000");
    WinWin = await ethers.getContractFactory("WinToken");
    winToken = await WinWin.deploy(tokenSupply);
    const block = await hre.ethers.provider.getBlock("latest");
    const totalRewards: BigNumber = BigNumber.from("10000000000000000000");

    WinStakingPool = await ethers.getContractFactory(
      "WinStakingPool",
      deployer
    );

    winStakingPool = await WinStakingPool.deploy(
      winToken.address,
      block.timestamp,
      totalRewards
    );

    await winToken.transfer(winStakingPool.address, totalRewards);

    rewardToken = await WinWin.connect(deployer).deploy(tokenSupply);
    rewardToken.deployed();

    StakingPool = await ethers.getContractFactory("YieldStakingPool", deployer);
    mintStakingPool = await StakingPool.deploy(MINTAddress);
    mintStakingPool.deployed();

    const lastTimestamp = (await waffle.provider.getBlock("latest")).timestamp;

    PrizePool = await ethers.getContractFactory("PrizePool", deployer);

    const prizeDistribution = [6000, 900, 600, 300, 100, 2100];

    mintPrizePool = await PrizePool.deploy(
      lastTimestamp + 100,
      mintStakingPool.address,
      prizeDistribution
    );

    winPrizePool = await PrizePool.deploy(
      lastTimestamp + 100,
      winStakingPool.address,
      prizeDistribution
    );

    await mintStakingPool.setPrizePoolAddress(mintPrizePool.address);

    await winStakingPool.setPrizePoolAddress(winPrizePool.address);

    await winPrizePool.addRewardToken(WPLSAddress);

    await mintPrizePool.addRewardToken(WPLSAddress);

    const distributionAddresses = [
      mintPrizePool.address,
      user1.address, // for testing setting it to user1
      winPrizePool.address,
      winStakingPool.address,
      buyAndBurn.address,
    ];

    const distributionShares = [6000, 3000, 600, 300, 100];

    MintStrategy = await ethers.getContractFactory("MINTRAStrategy", deployer);
    mintStrategy = await MintStrategy.deploy(
      MINTAddress,
      mintStakingAddress,
      distributionAddresses,
      distributionShares
    );

    mintStrategy.deployed();

    await mintStakingPool
      .connect(deployer)
      .modifyStrategyAddress(mintStrategy.address);

    await mintInstance
      .connect(user1)
      .approve(mintStakingPool.address, "1000000000000000000000000");
  });

  describe("Mint strategy test", function () {
    describe("Restricted functions test", () => {
      it("Can not 'Deposit' as deployer has no access", async function () {
        await expect(
          mintStrategy.connect(deployer).deposit(1000)
        ).to.be.revertedWith("Not WinMINTStaking");
      });

      it("Can not 'Withdraw' as deployer has no access", async function () {
        await expect(
          mintStrategy.connect(deployer).withdraw(1000)
        ).to.be.revertedWith("Not WinMINTStaking");
      });

      it("Successfully 'Distributed rewards", async function () {
        const mintTokenValue = BigInt(100000000000000000);
        const transferAmount: BigNumber = ethers.utils.parseEther("1");

        await user1.sendTransaction({
          to: mintStrategy.address,
          value: transferAmount,
        });

        await mintInstance
          .connect(user1)
          .approve(mintStrategy.address, mintTokenValue);

        await mintStrategy.connect(user1).deposit(mintTokenValue);

        await mintStakingPool.addReward(WPLSAddress, mintStrategy.address);

        await winStakingPool.addReward(WPLSAddress, mintStrategy.address);

        const distributionAddress = [
          mintPrizePool.address,
          mintStakingPool.address,
          winPrizePool.address,
          winStakingPool.address,
          buyAndBurn.address,
        ];

        await mintStrategy
          .connect(deployer)
          .changeDistributionAddresses(distributionAddress);

        const mintStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
          mintStakingPool.address
        );

        const mintPrizePoolPLSBalance = await WPLSInstance.balanceOf(
          mintPrizePool.address
        );

        const winPrizePoolPLSBalance = await WPLSInstance.balanceOf(
          winPrizePool.address
        );

        const winStakingWPLSBalance = await WPLSInstance.balanceOf(
          winStakingPool.address
        );

        const buyAndBurnPLSBalance = await buyAndBurn.getBalance();

        await forward(268000);

        await mintStrategy.connect(deployer).claimAndDistributeRewards();

        const currentStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
          mintStakingPool.address
        );

        const mintStakingPoolPercentage =
          await mintStrategy.getMINTStakingPercent();

        const totalPercent = await mintStrategy.TOTAL_PERCENT();

        expect(
          currentStakingPoolWPLSBalance.sub(mintStakingPoolWPLSBalance)
        ).to.be.equal(
          transferAmount.mul(mintStakingPoolPercentage).div(totalPercent)
        );

        const currentMintPrizePoolPLSBalance = await WPLSInstance.balanceOf(
          mintPrizePool.address
        );

        const mintPrizePoolPercentage =
          await mintStrategy.getMINTPrizePoolPercent();

        expect(
          currentMintPrizePoolPLSBalance.sub(mintPrizePoolPLSBalance)
        ).to.be.equal(
          transferAmount.mul(mintPrizePoolPercentage).div(totalPercent)
        );

        const currentWinPrizePoolPLSBalance = await WPLSInstance.balanceOf(
          winPrizePool.address
        );

        const winPrizePoolPercentage =
          await mintStrategy.getWinPrizePoolPercent();

        expect(
          currentWinPrizePoolPLSBalance.sub(winPrizePoolPLSBalance)
        ).to.be.equal(
          transferAmount.mul(winPrizePoolPercentage).div(totalPercent)
        );

        const currentWinStakingPLSBalance = await WPLSInstance.balanceOf(
          winStakingPool.address
        );

        const winStakingPercentage = await mintStrategy.getWinStakingPercent();

        expect(
          currentWinStakingPLSBalance.sub(winStakingWPLSBalance)
        ).to.be.equal(
          transferAmount.mul(winStakingPercentage).div(totalPercent)
        );

        const currentBuyAndBurnPLSBalance = await buyAndBurn.getBalance();
        const buyAndBurnPercentage = await mintStrategy.getBuyAndBurnPercent();

        expect(
          currentBuyAndBurnPLSBalance.sub(buyAndBurnPLSBalance)
        ).to.be.equal(
          transferAmount.mul(buyAndBurnPercentage).div(totalPercent)
        );
      });

      it("Can't distribute. Already distributed rewards for this day.", async function () {
        const mintTokenValue = BigInt(100000000000000000);
        const transferAmount: BigNumber = ethers.utils.parseEther("1");

        await user1.sendTransaction({
          to: mintStrategy.address,
          value: transferAmount,
        });

        await mintInstance
          .connect(user1)
          .approve(mintStrategy.address, mintTokenValue);

        await mintStrategy.connect(user1).deposit(mintTokenValue);

        await mintStakingPool.addReward(WPLSAddress, mintStrategy.address);

        await winStakingPool.addReward(WPLSAddress, mintStrategy.address);

        const distributionAddress = [
          mintPrizePool.address,
          mintStakingPool.address,
          winPrizePool.address,
          winStakingPool.address,
          buyAndBurn.address,
        ];

        await mintStrategy
          .connect(deployer)
          .changeDistributionAddresses(distributionAddress);

        await forward(268000);

        await mintStrategy.connect(deployer).claimAndDistributeRewards();
        await expect(
          mintStrategy.connect(deployer).claimAndDistributeRewards()
        ).to.be.revertedWith("Wait till one-day since last claimed time");
      });

      it("Can not change addresses. Only deployer has the permission", async function () {
        const distributionAddress = [
          mintPrizePool.address,
          mintStakingPool.address,
          winPrizePool.address,
          winStakingPool.address,
          buyAndBurn.address,
        ];
        await expect(
          mintStrategy
            .connect(user1)
            .changeDistributionAddresses(distributionAddress)
        ).to.be.revertedWith("Ownable: caller is not the owner");
      });

      it("Successfully changed address.", async function () {
        let distributionAddress = [
          user1.address,
          mintStakingPool.address,
          user1.address,
          user1.address,
          user1.address,
        ];
        await mintStrategy
          .connect(deployer)
          .changeDistributionAddresses(distributionAddress);

        expect(await mintStrategy.getWinMINTStakingAddress()).to.equal(
          mintStakingPool.address
        );

        expect(await mintStrategy.getWinStakingAddress()).to.equal(
          user1.address
        );

        expect(await mintStrategy.getWinPrizePoolAddress()).to.equal(
          user1.address
        );

        expect(await mintStrategy.getBuyAndBurnAddress()).to.equal(
          user1.address
        );

        expect(await mintStrategy.getWinPrizePoolAddress()).to.equal(
          user1.address
        );
        distributionAddress = [
          mintPrizePool.address,
          user1.address,
          mintStakingPool.address,
          winPrizePool.address,
          buyAndBurn.address,
        ];
        await mintStrategy
          .connect(deployer)
          .changeDistributionAddresses(distributionAddress);
      });

      it("Can not change shares. Only deployer has the permission.", async function () {
        const distributionShares = [7000, 2000, 700, 200, 100];

        await expect(
          mintStrategy
            .connect(user1)
            .updateDistributionPercentages(distributionShares)
        ).to.be.revertedWith("Ownable: caller is not the owner");
      });

      it("Distribution shares sum should be equal to 100%", async function () {
        const distributionShares = [7000, 2000, 700, 200, 50];
        await expect(
          mintStrategy.updateDistributionPercentages(distributionShares)
        ).to.be.revertedWith("Sum of shares is not 10000.");
      });

      it("Successfully updated distribution shares.", async function () {
        let distributionShares = [7000, 2000, 700, 200, 100];
        await mintStrategy.updateDistributionPercentages(distributionShares);
        expect(await mintStrategy.getMINTPrizePoolPercent()).to.equal(7000);
        expect(await mintStrategy.getMINTStakingPercent()).to.equal(2000);
        expect(await mintStrategy.getWinPrizePoolPercent()).to.equal(700);
        expect(await mintStrategy.getWinStakingPercent()).to.equal(200);
        expect(await mintStrategy.getBuyAndBurnPercent()).to.equal(100);

        distributionShares = [7100, 2000, 700, 200, 0];
        await mintStrategy.updateDistributionPercentages(distributionShares);

        expect(await mintStrategy.getMINTPrizePoolPercent()).to.equal(7100);
        expect(await mintStrategy.getMINTStakingPercent()).to.equal(2000);
        expect(await mintStrategy.getWinPrizePoolPercent()).to.equal(700);
        expect(await mintStrategy.getWinStakingPercent()).to.equal(200);
        expect(await mintStrategy.getBuyAndBurnPercent()).to.equal(0);

        // reverting the change
        distributionShares = [6000, 3000, 600, 300, 100];
        await mintStrategy.updateDistributionPercentages(distributionShares);
      });

      it("Can not send stuck tokens. Only deployer has the permission.", async function () {
        await expect(
          mintStrategy
            .connect(user1)
            .inCaseTokensGetStuck(MINTAddress, 7000, user1.address)
        ).to.be.revertedWith("Ownable: caller is not the owner");
      });

      it("Owner can not send MINT Tokens.", async function () {
        await expect(
          mintStrategy.inCaseTokensGetStuck(MINTAddress, 7000, user1.address)
        ).to.be.revertedWith("Can not send MINT tokens");
      });

      it("Recover tokens and transfer to deployer", async function () {
        const tokenSupply = 50000000;
        const transferAmount = 2000;
        rewardToken = await WinWin.connect(deployer).deploy(tokenSupply);
        rewardToken.deployed();

        await rewardToken
          .connect(deployer)
          .transfer(mintStrategy.address, transferAmount);

        const contractBalance: BigNumber = await rewardToken
          .connect(deployer)
          .balanceOf(mintStrategy.address);

        const deployerPreviousBalance: BigNumber = await rewardToken
          .connect(deployer)
          .balanceOf(deployer.address);

        await mintStrategy
          .connect(deployer)
          .inCaseTokensGetStuck(
            rewardToken.address,
            transferAmount,
            deployer.address
          );

        const deployerBalance: BigNumber = await rewardToken
          .connect(deployer)
          .balanceOf(deployer.address);

        expect(deployerPreviousBalance.add(contractBalance)).to.equal(
          deployerBalance
        );
      });
    });

    describe("Deposit and withdraw functionality test", () => {
      it("can not deposit 0", async function () {
        await expect(mintStrategy.connect(user1).deposit(0)).to.be.revertedWith(
          "_wantAmt <= 0"
        );
      });

      it("Successful 'Deposit'", async function () {
        const mintTokenValue = BigInt(100000000000000000);
        const user1MINTBalance = await mintInstance.balanceOf(user1.address);

        await mintInstance
          .connect(user1)
          .approve(mintStrategy.address, mintTokenValue);

        await mintStrategy.connect(user1).deposit(mintTokenValue);

        const user1MINTBalanceAfterDeposit = await mintInstance.balanceOf(
          user1.address
        );

        expect(await mintStrategy.getWantLockedTotal()).to.equal(
          mintTokenValue
        );
        // let us consider user1 address as MINT staking contract of WinWin.
        expect(user1MINTBalanceAfterDeposit).to.equal(
          BigInt(user1MINTBalance) - BigInt(mintTokenValue)
        );
      });

      it("Successful 'Withdraw'", async function () {
        const mintTokenDepositValue = BigInt(100000000000000000);
        const mintTokenWithdrawValue = BigInt(10000000000000000);

        await mintInstance
          .connect(user1)
          .approve(mintStrategy.address, mintTokenDepositValue);

        await mintStrategy.connect(user1).deposit(mintTokenDepositValue);

        const lockedTotalAfterDeposit = await mintStrategy.getWantLockedTotal();

        const user1MINTBalance = await mintInstance.balanceOf(user1.address);

        await mintStrategy.connect(user1).withdraw(mintTokenWithdrawValue);

        const lockedTotalAfterWithdraw =
          await mintStrategy.getWantLockedTotal();

        const user1MINTBalanceAfterWithdraw = await mintInstance.balanceOf(
          user1.address
        );

        expect(lockedTotalAfterDeposit).to.equal(
          BigInt(lockedTotalAfterWithdraw) + BigInt(mintTokenWithdrawValue)
        );

        // let us consider user1 address as MINT staking contract of WinWin.
        expect(user1MINTBalanceAfterWithdraw).to.equal(
          BigInt(user1MINTBalance) + BigInt(mintTokenWithdrawValue)
        );
      });

      it("Successful 'Withdraw'", async function () {
        const mintTokenDepositValue = BigInt(100000000000000000);

        await mintInstance
          .connect(user1)
          .approve(mintStrategy.address, mintTokenDepositValue);

        await mintStrategy.connect(user1).deposit(mintTokenDepositValue);

        await expect(
          mintStrategy.connect(user1).withdraw(0)
        ).to.be.revertedWith("_wantAmt <= 0");
      });
    });
  });

  describe("Mint strategy integration test", function () {
    it("can not set zero address as strategy address", async () => {
      await expect(
        mintStakingPool
          .connect(deployer)
          .modifyStrategyAddress("0x0000000000000000000000000000000000000000")
      ).to.be.revertedWith("Not valid address");
    });
    it("New strategy address can not be same as current strategy address", async () => {
      await expect(
        mintStakingPool
          .connect(deployer)
          .modifyStrategyAddress(mintStrategy.address)
      ).to.be.revertedWith("This is current strategy address.");
    });
    it("Successful 'Stake'", async function () {
      const mintTokenValue = BigInt(100000000000000000);

      const user1MINTBalance = await mintInstance.balanceOf(user1.address);

      await mintInstance
        .connect(user1)
        .approve(mintStakingPool.address, mintTokenValue);

      const distributionAddress = [
        mintPrizePool.address,
        mintStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];

      await mintStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      await mintStakingPool.connect(user1).stake(mintTokenValue, [], [], true);

      const user1MINTBalanceAfterDeposit = await mintInstance.balanceOf(
        user1.address
      );
      expect(user1MINTBalanceAfterDeposit).to.equal(
        BigInt(user1MINTBalance) - BigInt(mintTokenValue)
      );
    });
    it("Successful 'Unstake'", async function () {
      const mintTokenStakeValue = BigInt(100000000000000000);
      const mintTokenUnstakeValue = 1000000;
      const user1MINTBalance = await mintInstance.balanceOf(user1.address);
      await mintInstance
        .connect(user1)
        .approve(mintStakingPool.address, mintTokenStakeValue);

      const distributionAddress = [
        mintPrizePool.address,
        mintStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];

      await mintStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      await mintStakingPool
        .connect(user1)
        .stake(mintTokenStakeValue, [], [], true);
      await mintStakingPool.connect(user1).unstake(mintTokenUnstakeValue);
      const user1MINTBalanceAfterWithdraw = await mintInstance.balanceOf(
        user1.address
      );
      expect(user1MINTBalanceAfterWithdraw).to.equal(
        BigInt(user1MINTBalance) -
          BigInt(mintTokenStakeValue) +
          BigInt(mintTokenUnstakeValue)
      );
    });
  });
  describe("Automation Test", () => {
    it("Successfully 'Distributed rewards' when staking", async function () {
      const mintTokenValue = BigInt(100000000000000000);
      const transferAmount: BigNumber = ethers.utils.parseEther("1");

      await user1.sendTransaction({
        to: mintStrategy.address,
        value: transferAmount,
      });

      await mintInstance
        .connect(user1)
        .approve(mintStrategy.address, mintTokenValue);

      await mintStrategy.connect(user1).deposit(mintTokenValue);

      await mintStakingPool.addReward(WPLSAddress, mintStrategy.address);

      await winStakingPool.addReward(WPLSAddress, mintStrategy.address);

      const distributionAddress = [
        mintPrizePool.address,
        mintStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];

      await mintStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      const mintStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
        mintStakingPool.address
      );

      const mintPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        mintPrizePool.address
      );

      const winPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        winPrizePool.address
      );

      const winStakingWPLSBalance = await WPLSInstance.balanceOf(
        winStakingPool.address
      );

      const buyAndBurnPLSBalance = await buyAndBurn.getBalance();

      await forward(86400);

      await mintStakingPool.connect(user1).stake(mintTokenValue, [], [], true);

      const currentStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
        mintStakingPool.address
      );

      const mintStakingPoolPercentage =
        await mintStrategy.getMINTStakingPercent();

      const totalPercent = await mintStrategy.TOTAL_PERCENT();

      expect(
        currentStakingPoolWPLSBalance.sub(mintStakingPoolWPLSBalance)
      ).to.be.equal(
        transferAmount.mul(mintStakingPoolPercentage).div(totalPercent)
      );

      const currentMintPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        mintPrizePool.address
      );

      const mintPrizePoolPercentage =
        await mintStrategy.getMINTPrizePoolPercent();

      expect(
        currentMintPrizePoolPLSBalance.sub(mintPrizePoolPLSBalance)
      ).to.be.equal(
        transferAmount.mul(mintPrizePoolPercentage).div(totalPercent)
      );

      const currentWinPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPercentage =
        await mintStrategy.getWinPrizePoolPercent();

      expect(
        currentWinPrizePoolPLSBalance.sub(winPrizePoolPLSBalance)
      ).to.be.equal(
        transferAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      const currentWinStakingPLSBalance = await WPLSInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingPercentage = await mintStrategy.getWinStakingPercent();

      expect(
        currentWinStakingPLSBalance.sub(winStakingWPLSBalance)
      ).to.be.equal(transferAmount.mul(winStakingPercentage).div(totalPercent));

      const currentBuyAndBurnPLSBalance = await buyAndBurn.getBalance();
      const buyAndBurnPercentage = await mintStrategy.getBuyAndBurnPercent();

      expect(currentBuyAndBurnPLSBalance.sub(buyAndBurnPLSBalance)).to.be.equal(
        transferAmount.mul(buyAndBurnPercentage).div(totalPercent)
      );
    });
    it("Successfully 'Distributed rewards' when unstaking", async function () {
      const mintTokenValue = BigInt(100000000000000000);
      const transferAmount: BigNumber = ethers.utils.parseEther("1");

      await user1.sendTransaction({
        to: mintStrategy.address,
        value: transferAmount,
      });

      await mintInstance
        .connect(user1)
        .approve(mintStrategy.address, mintTokenValue);

      await mintStrategy.connect(user1).deposit(mintTokenValue);

      await mintStakingPool.addReward(WPLSAddress, mintStrategy.address);

      await winStakingPool.addReward(WPLSAddress, mintStrategy.address);

      const distributionAddress = [
        mintPrizePool.address,
        mintStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];

      await mintStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      const mintStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
        mintStakingPool.address
      );

      const mintPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        mintPrizePool.address
      );

      const winPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        winPrizePool.address
      );

      const winStakingWPLSBalance = await WPLSInstance.balanceOf(
        winStakingPool.address
      );

      const buyAndBurnPLSBalance = await buyAndBurn.getBalance();

      await mintStakingPool.connect(user1).stake(mintTokenValue, [], [], true);
      await forward(86400);

      await mintStakingPool.connect(user1).unstake(mintTokenValue);

      const currentStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
        mintStakingPool.address
      );

      const mintStakingPoolPercentage =
        await mintStrategy.getMINTStakingPercent();

      const totalPercent = await mintStrategy.TOTAL_PERCENT();

      expect(
        currentStakingPoolWPLSBalance.sub(mintStakingPoolWPLSBalance)
      ).to.be.equal(
        transferAmount.mul(mintStakingPoolPercentage).div(totalPercent)
      );

      const currentMintPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        mintPrizePool.address
      );

      const mintPrizePoolPercentage =
        await mintStrategy.getMINTPrizePoolPercent();

      expect(
        currentMintPrizePoolPLSBalance.sub(mintPrizePoolPLSBalance)
      ).to.be.equal(
        transferAmount.mul(mintPrizePoolPercentage).div(totalPercent)
      );

      const currentWinPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPercentage =
        await mintStrategy.getWinPrizePoolPercent();

      expect(
        currentWinPrizePoolPLSBalance.sub(winPrizePoolPLSBalance)
      ).to.be.equal(
        transferAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      const currentWinStakingPLSBalance = await WPLSInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingPercentage = await mintStrategy.getWinStakingPercent();

      expect(
        currentWinStakingPLSBalance.sub(winStakingWPLSBalance)
      ).to.be.equal(transferAmount.mul(winStakingPercentage).div(totalPercent));

      const currentBuyAndBurnPLSBalance = await buyAndBurn.getBalance();
      const buyAndBurnPercentage = await mintStrategy.getBuyAndBurnPercent();

      expect(currentBuyAndBurnPLSBalance.sub(buyAndBurnPLSBalance)).to.be.equal(
        transferAmount.mul(buyAndBurnPercentage).div(totalPercent)
      );
    });
    it("Successfully 'Distributed rewards' when called claimAndDistributeRewards()", async function () {
      const mintTokenValue = BigInt(100000000000000000);
      const transferAmount: BigNumber = ethers.utils.parseEther("1");

      await user1.sendTransaction({
        to: mintStrategy.address,
        value: transferAmount,
      });

      await mintInstance
        .connect(user1)
        .approve(mintStrategy.address, mintTokenValue);

      await mintStrategy.connect(user1).deposit(mintTokenValue);

      await mintStakingPool.addReward(WPLSAddress, mintStrategy.address);

      await winStakingPool.addReward(WPLSAddress, mintStrategy.address);

      const distributionAddress = [
        mintPrizePool.address,
        mintStakingPool.address,
        winPrizePool.address,
        winStakingPool.address,
        buyAndBurn.address,
      ];

      await mintStrategy
        .connect(deployer)
        .changeDistributionAddresses(distributionAddress);

      const PrizeCycleTimeBefore =
        await mintStrategy.currentPrizeCycleStartTime();

      const mintStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
        mintStakingPool.address
      );

      const mintPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        mintPrizePool.address
      );

      const winPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        winPrizePool.address
      );

      const winStakingWPLSBalance = await WPLSInstance.balanceOf(
        winStakingPool.address
      );

      const buyAndBurnPLSBalance = await buyAndBurn.getBalance();

      await forward(86400);

      await mintStrategy.connect(deployer).claimAndDistributeRewards();

      const currentStakingPoolWPLSBalance = await WPLSInstance.balanceOf(
        mintStakingPool.address
      );

      const PrizeCycleTimeAfter =
        await mintStrategy.currentPrizeCycleStartTime();

      const mintStakingPoolPercentage =
        await mintStrategy.getMINTStakingPercent();

      const totalPercent = await mintStrategy.TOTAL_PERCENT();

      expect(
        currentStakingPoolWPLSBalance.sub(mintStakingPoolWPLSBalance)
      ).to.be.equal(
        transferAmount.mul(mintStakingPoolPercentage).div(totalPercent)
      );

      expect(PrizeCycleTimeAfter.sub(PrizeCycleTimeBefore)).to.be.equal(86400);

      const currentMintPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        mintPrizePool.address
      );

      const mintPrizePoolPercentage =
        await mintStrategy.getMINTPrizePoolPercent();

      expect(
        currentMintPrizePoolPLSBalance.sub(mintPrizePoolPLSBalance)
      ).to.be.equal(
        transferAmount.mul(mintPrizePoolPercentage).div(totalPercent)
      );

      const currentWinPrizePoolPLSBalance = await WPLSInstance.balanceOf(
        winPrizePool.address
      );

      const winPrizePoolPercentage =
        await mintStrategy.getWinPrizePoolPercent();

      expect(
        currentWinPrizePoolPLSBalance.sub(winPrizePoolPLSBalance)
      ).to.be.equal(
        transferAmount.mul(winPrizePoolPercentage).div(totalPercent)
      );

      const currentWinStakingPLSBalance = await WPLSInstance.balanceOf(
        winStakingPool.address
      );

      const winStakingPercentage = await mintStrategy.getWinStakingPercent();

      expect(
        currentWinStakingPLSBalance.sub(winStakingWPLSBalance)
      ).to.be.equal(transferAmount.mul(winStakingPercentage).div(totalPercent));

      const currentBuyAndBurnPLSBalance = await buyAndBurn.getBalance();
      const buyAndBurnPercentage = await mintStrategy.getBuyAndBurnPercent();

      expect(currentBuyAndBurnPLSBalance.sub(buyAndBurnPLSBalance)).to.be.equal(
        transferAmount.mul(buyAndBurnPercentage).div(totalPercent)
      );
    });
  });
});
