![WinWin Finance](https://assets.zyrosite.com/cdn-cgi/image/format=auto,w=400,fit=crop/YBg1aNoBvrFVk5Dm/web_logo-YZ9NGR3bVGH7JM90.png)

## Table of Content

- [Project Description](#project-description)
- [System Requirements](#system-requirements)
- [Prerequisites](#prerequisites)
- [Technologies Used](#technologies-used)
- [Folder Structure](#directory-layout)
- [Install and Run](#install-and-run)

## Project Description

```
WinWin is a DeFi savings account on the Pulsechain protocol that allows users to compound yield savings and win crypto prizes. WinWin will give everyone a fair chance of regularly winning prizes without risking their own tokens, all while generating an APY that compounds automatically.

The user can access the application via web-browser, and he must have the supported crypto wallet installed. This interface, built with Next.js, relies on the Wagmi and Ethers.js library to communicate with the smart contracts through any supported crypto wallet. This means that the data reflected on the front-end application is fetched from the Pulse Chain blockchain. Each action performed by the user (Staking, Buying, investing in pools) creates a transaction on Pulse Chain, which will require connected wallet confirmation and pay a small fee, and this transaction will permanently modify the state of the blockchain.

```

<!-- <img src="./public/assets/svg/landing_ss.png"> -->

## Architecture

**Functions of StakingPool SC**

```mermaid
flowchart LR
StakingPool --Stake tokens--> `stake`
StakingPool --Withdraw tokens--> `unstake`
StakingPool --Claim the rewards--> `claim`
StakingPool --get rewards amount with reward token address--> `getClaimableRewards`
StakingPool --Transfer token to contract and sets the Reward Rate-->`notifyRewardAmount`
```

**Functions of PrizePool SC**

```mermaid
flowchart LR
PrizePool --Gets tickets for PrizePool--> `getTickets`
PrizePool --burn tickets--> `burnTickets`
PrizePool --Claim prizes according to TWAB--> `claimPrizes`
PrizePool --Claim winning of user--> `claimWinning`
PrizePool --get rewards amount with reward token address--> `getClaimableRewards`
PrizePool --add prizes--> `addPrizes`
```

**Sequence Diagram for workflow of StakingPool**

```mermaid
sequenceDiagram
User->>Token: approve to StakingPool
User->>StakingPool: `stake`
StakingPool->>Strategy: `_deposit`
Strategy->>YieldGeneration: invest
StakingPool->>PrizePool: `getTickets`
User->>StakingPool: `unstake`
StakingPool->>Strategy: `_withdraw`
Strategy->>YieldGeneration: withdraw
StakingPool->>PrizePool: `burnTickets`
Strategy->>YieldGeneration: Claim Yield
User->>StakingPool: `claim`
```

**Sequence Diagram for workflow of Win StakingPool**

```mermaid
sequenceDiagram
User->>Token: approve to StakingPool
User->>StakingPool: `stake`
StakingPool->>PrizePool: `getTickets`
User->>StakingPool: `unstake`
StakingPool->>PrizePool: `burnTickets`
User->>StakingPool: `claim`
```

**Sequence Diagram for workflow of Strategy**

```mermaid
sequenceDiagram
StakingPool->>Strategy: `deposit`
StakingPool->>Strategy: `withdraw`
Strategy->>YieldGeneration: `claim yield`
Strategy->>Strategy: `claimAndDistributeRewards`
Strategy->>StakingPool: `notifyRewardAmount`
Strategy->>PrizePool: `addPrizes`
Strategy->>WinStakingPool: `notifyRewardAmount`
Strategy->>WinPrizePool: `addPrizes`

```

## System Requirements

    # Node.js ^18.0.0 .
    # MacOS, Windows (including WSL), and Linux are supported.

## Prerequisites

    # Download the Node js and setup your environment
    # Check your node version
    $ node -v
    # Check package manager version
    $ yarn -v (or) npm -v

## Technologies Used

- Solidity
- OpenZeppelin
- Hardhat
- TypeScript

## Directory layout

    .
    ├── contracts               # Smart contracts
    ├── scripts                 # Deployment scripts for smart contracts
    ├── test                    # Test files
    └── README.md

## Install and Setup

### Clone

```
git clone http://gitlab.rapidinnovation.tech/root/blockchain-solidity-winwin.git

```

### Installation

Install project's dependencies:

```
cd blockchain-solidity-winwin

yarn install

```

### Set up .env

create a new .env file by copying it's content from env.example and filling in your secrets

```
cp .env.example .env

```

## Building the projects

### compile

Compile the contracts:

```
yarn compile

```

### Clean

Delete the smart contract artifacts, the coverage reports and the Hardhat cache:

```
yarn clean

```

### Testing

Run the tests:

```
yarn test

```

Output:
![Testcases Output](public/testcases.png)

### Fuzz Testing

Run the fuzz tests:

```
yarn fuzz-test

```

Output:

![Fuzz Testcases Output](public/fuzz-testcases.png)

### Coverage

Check Coverage of testcases:

```
yarn coverage

```

Total Coverage:
![Coverage Output](public/coverage.png)

### Deployment

Deploy the contracts locally:

```
yarn deploy-local

```

### Contract-size

To check contract's size :

```
yarn contract-size

```

Output:
![Contract-size Output](public/contract-size.png)

### Prettier

To run prettier :

```
yarn prettier

```
