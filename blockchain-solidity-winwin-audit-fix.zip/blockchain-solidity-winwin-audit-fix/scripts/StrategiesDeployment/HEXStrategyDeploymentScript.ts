// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// You can also run a script with `npx hardhat run <script>`. If you do that, Hardhat
// will compile your contracts, add the Hardhat Runtime Environment's members to the
// global scope, and execute the script.
import { ethers } from "hardhat";

async function main() {
  //Update these addresses to the correct ones
  const HEXTokenAddress = "0x2b591e99afE9f32eAA6214f7B7629768c40Eeb39";
  const HEXPrizePoolAddress = "0x40bcdCFe90acC644DE2Bf5C8563958A9f18c15Cf";
  const WinHEXStakingAddress = "0x2476449757F2324fbfd2dAbCDEF1d3d07ce7E1A5";
  const WinPrizePoolAddress = "0x4042707E6cCe53e6E902c756d37669Cd297a825B";
  const WinStakingAddress = "0x4611781A849ec0D094261a3b920EC9BE39bd94f2";
  const BuyAndBurnAddress = "0x13d190d8986Df9823Eb2F774D11BCa90c44C5092";
  let distributionAddress = [
    HEXPrizePoolAddress,
    WinHEXStakingAddress,
    WinPrizePoolAddress,
    WinStakingAddress,
    BuyAndBurnAddress,
  ];

  let distributionShares = [6000, 3000, 600, 300, 100];
  const Strategy = await ethers.getContractFactory("HEXStrategy");
  const strategyContract = await Strategy.deploy(
    HEXTokenAddress,
    distributionAddress,
    distributionShares
  );

  await strategyContract.deployed();

  console.log("Strategy contract address: ", strategyContract.address);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
