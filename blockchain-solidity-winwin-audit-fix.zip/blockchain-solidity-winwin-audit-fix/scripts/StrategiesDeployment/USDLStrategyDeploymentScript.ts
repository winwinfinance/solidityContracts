// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// You can also run a script with `npx hardhat run <script>`. If you do that, Hardhat
// will compile your contracts, add the Hardhat Runtime Environment's members to the
// global scope, and execute the script.
import { ethers } from "hardhat";

async function main() {
  const USDLAddress = "0x7D18EDA38B4B028B6aAdFbF5decbe76990046612",
    llstabiltyPoolAddress = "0x2c275aB15C15d577C83167e02487f4B8bD21E907",
    LOANAddress = "0x4F7fCdb511a25099F870EE57c77f7DB2561EC9B6",
    WinUSDLStakingAddress = "0x4042707E6cCe53e6E902c756d37669Cd297a825B",
    USDLPrizePoolAddress = "0x40bcdCFe90acC644DE2Bf5C8563958A9f18c15Cf",
    WinPrizePoolAddress = "0x4042707E6cCe53e6E902c756d37669Cd297a825B",
    WinStakingAddress = "0x4611781A849ec0D094261a3b920EC9BE39bd94f2",
    BuyAndBurnAddress = "0x13d190d8986Df9823Eb2F774D11BCa90c44C5092";

  let distributionAddress = [
    USDLPrizePoolAddress,
    WinUSDLStakingAddress,
    WinPrizePoolAddress,
    WinStakingAddress,
    BuyAndBurnAddress,
  ];

  let distributionShares = [6000, 3000, 600, 300, 100];

  const Strategy = await ethers.getContractFactory("USDLStrategy");
  const strategyContract = await Strategy.deploy(
    LOANAddress,
    USDLAddress,
    llstabiltyPoolAddress,
    distributionAddress,
    distributionShares
  );

  await strategyContract.deployed();

  console.log("Strategy contract address: ", strategyContract.address);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
