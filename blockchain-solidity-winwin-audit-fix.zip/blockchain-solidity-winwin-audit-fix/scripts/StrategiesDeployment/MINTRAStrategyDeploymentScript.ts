// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// You can also run a script with `npx hardhat run <script>`. If you do that, Hardhat
// will compile your contracts, add the Hardhat Runtime Environment's members to the
// global scope, and execute the script.
import { ethers } from "hardhat";

async function main() {
  //Update these addresses to the correct one
  const MINTAddress = "0x5Bf359ef13Fa31c93f4Fb286A5a3af76eb88E877";
  const mintStakingAddress = "0x70D4186d11Edd70897B515dfbECC25819099162c";
  const WinMINTStakingAddress = "0xE621DA0965bE828BC34A367f55fC70E43C261924";
  const MintPrizePoolAddress = "0xfafBA35285f883160F7f7bdEe5c57181F5b2BC87";
  const WinPrizePoolAddress = "0xC1fecC4099D2BEDf49F385F9216E5d3b068a8E27";
  const WinStakingAddress = "0x4a33E4D9d0E9b94313C63F0b66656f1d47E894C6";
  const BuyAndBurnAddress = "0x5e8C6563d53DBD2DdCbfcAf6AA243bC7bDb0c1B1";

  let distributionAddress = [
    MintPrizePoolAddress,
    WinMINTStakingAddress,
    WinPrizePoolAddress,
    WinStakingAddress,
    BuyAndBurnAddress,
  ];

  let distributionShares = [6000, 3000, 600, 300, 100];

  const Strategy = await ethers.getContractFactory("MINTRAStrategy");
  const strategyContract = await Strategy.deploy(
    MINTAddress,
    mintStakingAddress,
    distributionAddress,
    distributionShares
  );

  await strategyContract.deployed();

  console.log("Strategy contract address: ", strategyContract.address);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
