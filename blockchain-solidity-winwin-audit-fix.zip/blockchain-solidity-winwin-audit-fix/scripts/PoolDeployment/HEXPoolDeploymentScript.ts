// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// You can also run a script with `npx hardhat run <script>`. If you do that, Hardhat
// will compile your contracts, add the Hardhat Runtime Environment's members to the
// global scope, and execute the script.
import hre from "hardhat";

async function main() {
  //Change stake token address to token address of which you want to deploy staking pool.
  const stakeTokenAddress = "0x2b591e99afE9f32eAA6214f7B7629768c40Eeb39";

  const HEXStakingPool = await hre.ethers.getContractFactory("HexStakingPool");

  const hexStakingPool = await HEXStakingPool.deploy(stakeTokenAddress);

  await hexStakingPool.deployed();

  console.log(
    `HEX staking pool deployed for ${stakeTokenAddress} token: `,
    hexStakingPool.address
  );
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
