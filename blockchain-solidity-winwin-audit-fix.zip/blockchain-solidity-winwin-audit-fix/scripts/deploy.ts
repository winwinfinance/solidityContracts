import { SignerWithAddress } from "@nomiclabs/hardhat-ethers/signers";
import hre, { ethers } from "hardhat";

async function main() {
  let deployer: SignerWithAddress;
  [deployer] = await ethers.getSigners();
  const totalSupply = 5000000000;
  const startTimestampForWinRewards = 1679034952;
  const totalWinRewards = ethers.utils.parseEther("1000");
  const MINTAddress = "0xd967edbc442185182A6bdF24f697D5f3599aC354";
  const LOANAddress = "0x4F7fCdb511a25099F870EE57c77f7DB2561EC9B6";
  const USDLAddress = "0x7D18EDA38B4B028B6aAdFbF5decbe76990046612";
  const HEXAddress = "0x2b591e99afE9f32eAA6214f7B7629768c40Eeb39";
  const WPLSAddress = "0x8a810ea8b121d08342e9e7696f4a9915cbe494b7";

  const LiquidityLoansLOANStakingAddress =
    "0x2476449757f2324fBFD2Da7Fb621d3d07cE7e1a5";

  const LiquidLoansUSDLStakingAddress =
    "0x2c275aB15C15d577C83167e02487f4B8bD21E907";

  const originalMintStakingAddress =
    "0xf33A1c1496F3f2207EA98f60Ef09faF6484AAc77";

  const dummyBuyAndBurnAddress = "0x13d190d8986Df9823Eb2F774D11BCa90c44C5092";

  const WinToken = await hre.ethers.getContractFactory("WinToken");
  const winToken = await WinToken.deploy(totalSupply);

  await winToken.deployed();

  console.log("WinToken contract address: ", winToken.address);

  const WinStakingPool = await hre.ethers.getContractFactory("WinStakingPool");
  const winStakingPool = await WinStakingPool.deploy(
    "0xc172ae1795460c2C4567Df955175c405d07833BB",
    "1679024952",
    totalWinRewards
  );
  await winStakingPool.deployed();

  console.log("Win Staking Pool contract address: ", winStakingPool.address);

  //Win Prize Pool

  const PrizePool = await hre.ethers.getContractFactory("PrizePool");

  let prizeDistribution = [6000, 900, 600, 300, 100, 2100];

  const winPrizePool = await PrizePool.deploy(
    startTimestampForWinRewards,
    winStakingPool.address,
    prizeDistribution
  );

  await winPrizePool.deployed();

  console.log("Win Prize Pool contract address: ", winPrizePool.address);

  await winStakingPool.setPrizePoolAddress(winPrizePool.address);

  //LOAN Staking contract

  const LoanStakingPool = await hre.ethers.getContractFactory(
    "YieldStakingPool"
  );

  const loanStakingPool = await LoanStakingPool.deploy(LOANAddress);

  await loanStakingPool.deployed();

  console.log("Loan Staking pool contract address: ", loanStakingPool.address);

  const loanPrizePool = await PrizePool.deploy(
    startTimestampForWinRewards,
    loanStakingPool.address,
    prizeDistribution
  );

  await loanPrizePool.deployed();

  console.log("Loan Prize Pool contract address: ", loanPrizePool.address);

  await loanStakingPool.setPrizePoolAddress(loanPrizePool.address);

  let distributionAddress = [
    loanPrizePool.address,
    loanStakingPool.address,
    winPrizePool.address,
    winStakingPool.address,
    dummyBuyAndBurnAddress,
  ];

  let distributionShares = [6000, 3000, 600, 300, 100];

  const LoanStrategy = await hre.ethers.getContractFactory("LOANStrategy");

  const loanStrategy = await LoanStrategy.deploy(
    LOANAddress,
    USDLAddress,
    LiquidityLoansLOANStakingAddress,
    distributionAddress,
    distributionShares
  );

  await loanStrategy.deployed();

  console.log("Loan startegy contract address", loanStrategy.address);

  //Setting strategy in loan staking pool
  await loanStakingPool.modifyStrategyAddress(loanStrategy.address);

  //Mint Pool

  const MintStakingPool = await hre.ethers.getContractFactory(
    "YieldStakingPool"
  );

  const mintStakingPool = await MintStakingPool.deploy(MINTAddress);

  await mintStakingPool.deployed();

  console.log("Mint Staking pool contract address: ", mintStakingPool.address);

  const mintPrizePool = await PrizePool.deploy(
    startTimestampForWinRewards,
    mintStakingPool.address,
    prizeDistribution
  );

  await mintPrizePool.deployed();

  console.log("Mint Prize Pool contract address: ", mintPrizePool.address);

  await mintStakingPool.setPrizePoolAddress(mintPrizePool.address);

  distributionAddress = [
    mintPrizePool.address,
    mintStakingPool.address,
    winPrizePool.address,
    winStakingPool.address,
    dummyBuyAndBurnAddress,
  ];

  const MintStrategy = await hre.ethers.getContractFactory("MINTRAStrategy");

  const mintStrategy = await MintStrategy.deploy(
    MINTAddress,
    originalMintStakingAddress,
    distributionAddress,
    distributionShares
  );

  await mintStrategy.deployed();

  console.log("Mint Strategy contract address", mintStrategy.address);

  //Setting strategy in loan staking pool
  await mintStakingPool.modifyStrategyAddress(mintStrategy.address);

  //USDL Pool

  const USDLStakingPool = await hre.ethers.getContractFactory(
    "YieldStakingPool"
  );

  const usdlStakingPool = await USDLStakingPool.deploy(USDLAddress);

  await usdlStakingPool.deployed();

  console.log("USDL Staking pool contract address: ", usdlStakingPool.address);

  const usdlPrizePool = await PrizePool.deploy(
    startTimestampForWinRewards,
    usdlStakingPool.address,
    prizeDistribution
  );

  await usdlPrizePool.deployed();

  console.log("USDL Prize Pool contract address: ", usdlPrizePool.address);

  await usdlStakingPool.setPrizePoolAddress(usdlPrizePool.address);

  distributionAddress = [
    usdlPrizePool.address,
    usdlStakingPool.address,
    winPrizePool.address,
    winStakingPool.address,
    dummyBuyAndBurnAddress,
  ];

  const USDLStrategy = await hre.ethers.getContractFactory("USDLStrategy");

  const usdlStrategy = await USDLStrategy.deploy(
    LOANAddress,
    USDLAddress,
    LiquidLoansUSDLStakingAddress,
    distributionAddress,
    distributionShares
  );

  await usdlStrategy.deployed();

  console.log("USDL Strategy contract address", usdlStrategy.address);

  //Setting strategy in usdl staking pool
  await usdlStakingPool.modifyStrategyAddress(usdlStrategy.address);

  //HEX Pool
  const HEXStakingPool = await hre.ethers.getContractFactory("HexStakingPool");

  const hexStakingPool = await HEXStakingPool.deploy(HEXAddress);

  await hexStakingPool.deployed();

  console.log("HEX Staking pool contract address: ", hexStakingPool.address);

  const hexPrizePool = await PrizePool.deploy(
    startTimestampForWinRewards,
    hexStakingPool.address,
    prizeDistribution
  );

  await hexPrizePool.deployed();

  console.log("HEX Prize Pool contract address: ", hexPrizePool.address);

  await hexStakingPool.setPrizePoolAddress(hexPrizePool.address);

  distributionAddress = [
    hexPrizePool.address,
    hexStakingPool.address,
    winPrizePool.address,
    winStakingPool.address,
    dummyBuyAndBurnAddress,
  ];

  const HEXStrategy = await hre.ethers.getContractFactory("HEXStrategy");

  const hexStrategy = await HEXStrategy.deploy(
    HEXAddress,
    distributionAddress,
    distributionShares
  );

  await hexStrategy.deployed();

  console.log("HEX Strategy contract address", hexStrategy.address);

  //Setting strategy in hex staking pool
  await hexStakingPool.modifyStrategyAddress(hexStrategy.address);

  // Add reward tokens and some rewards

  await winStakingPool.addReward(LOANAddress, deployer.address);
  await winStakingPool.addReward(USDLAddress, deployer.address);
  await winStakingPool.addReward(HEXAddress, deployer.address);
  await winStakingPool.addReward(WPLSAddress, deployer.address);

  await winPrizePool.addRewardToken(LOANAddress);
  await winPrizePool.addRewardToken(USDLAddress);
  await winPrizePool.addRewardToken(HEXAddress);
  await winPrizePool.addRewardToken(WPLSAddress);

  //Hex pool
  //Staking pool only has hex and it;s already added during deployment

  await hexPrizePool.addRewardToken(HEXAddress);

  //LOAN pool

  await loanStakingPool.addReward(USDLAddress, deployer.address);
  await loanStakingPool.addReward(WPLSAddress, deployer.address);

  await loanPrizePool.addRewardToken(USDLAddress);
  await loanPrizePool.addRewardToken(WPLSAddress);

  //USDL Pool

  await usdlStakingPool.addReward(LOANAddress, deployer.address);

  await usdlPrizePool.addRewardToken(LOANAddress);

  //Mint pool

  await mintStakingPool.addReward(WPLSAddress, deployer.address);

  await mintPrizePool.addRewardToken(WPLSAddress);

  const erc20Abi = await hre.artifacts.readArtifact(
    "@openzeppelin/contracts/token/ERC20/IERC20.sol:IERC20"
  );

  const winTokenInstance = new ethers.Contract(
    "0xc172ae1795460c2C4567Df955175c405d07833BB",
    erc20Abi.abi,
    deployer
  );

  await winTokenInstance.transfer(winStakingPool.address, totalWinRewards);

  //Approving all the strategy for their reward tokens in winStakingPool.

  await winStakingPool.approveRewardDistributor(
    WPLSAddress,
    loanStrategy.address,
    true
  );
  await winStakingPool.approveRewardDistributor(
    USDLAddress,
    loanStrategy.address,
    true
  );

  await winStakingPool.approveRewardDistributor(
    WPLSAddress,
    mintStrategy.address,
    true
  );

  await winStakingPool.approveRewardDistributor(
    LOANAddress,
    usdlStrategy.address,
    true
  );

  await winStakingPool.approveRewardDistributor(
    HEXAddress,
    hexStrategy.address,
    true
  );

  //Approving loan staking pool

  await loanStakingPool.approveRewardDistributor(
    WPLSAddress,
    loanStrategy.address,
    true
  );
  await loanStakingPool.approveRewardDistributor(
    USDLAddress,
    loanStrategy.address,
    true
  );

  //Mint Staking Pool

  await mintStakingPool.approveRewardDistributor(
    WPLSAddress,
    mintStrategy.address,
    true
  );

  //USDL Staking pool

  await usdlStakingPool.approveRewardDistributor(
    LOANAddress,
    usdlStrategy.address,
    true
  );

  //Hex staking pool

  await hexStakingPool.approveRewardDistributor(
    HEXAddress,
    hexStrategy.address,
    true
  );
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
