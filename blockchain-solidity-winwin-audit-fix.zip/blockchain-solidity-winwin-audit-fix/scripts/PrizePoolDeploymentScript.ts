// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// You can also run a script with `npx hardhat run <script>`. If you do that, Hardhat
// will compile your contracts, add the Hardhat Runtime Environment's members to the
// global scope, and execute the script.
import hre from "hardhat";

async function main() {
  //Change these values accordingly to staking pool for which you want to deploy prize pool.
  const startTimestampForWinRewards = 1678078680;
  const StakingPoolAddress = "0xb159e481D2A3489F736B4B72eb9b29239Fe0D1DA";
  const prizePool = await hre.ethers.getContractFactory("PrizePool");

  let prizeDistribution = [6000, 900, 600, 300, 100, 2100];

  const PrizePool = await prizePool.deploy(
    startTimestampForWinRewards,
    StakingPoolAddress,
    prizeDistribution
  );
  await PrizePool.deployed();
  console.log("Prize Pool contract address: ", PrizePool.address);
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
